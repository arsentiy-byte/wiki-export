# Книги > Bazis-a: сервис продажи квартир > Основная информация > Документация и проектная среда

# Документация и проектная среда

Ссылка на проект:

https://intra.rocketfirm.com/clients/deals/deal-view/?id=2817

Jira:

https://jira.rocketfirm.com/secure/RapidBoard.jspa?rapidView=243

Figma:

https://www.figma.com/file/GVbcYGJSIEBvKcClQLeSqL/Bazis-A-(prototype)?node-id=1%3A16500

GitLab:

backend + api

https://gitlab.com/rocketfirm/basis-a/basis-api

frontend

[https://gitlab.com/rocketfirm/basis-a/basis-a](https://gitlab.com/rocketfirm/basis-a/basis-a)

Документация API swannger (наше АПИ)

 https://bazis-api.rocketfirm.net/api/documentation

Тестовый сайт:

https://bazis-a.rocketfirm.digital/

Тестовая админка:

 https://bazis-api.rocketfirm.digital/admin

Боевой сайт Базиса с квартирами (не наш сайт):

https://test.bazis.kz/flats-crm

Тестовый сайт Базиса с квартирами (не наш сайт):

https://demo.bazis.kz/flats-crm

Ссылка на пользовательский ЭЦП:

https://bazis-a.rocketfirm.digital/sigex

Ссылка на администраторский ЭЦП:

https://bazis-api.rocketfirm.digital/admin/signed-documents

Репозиторий для сервиса ЭЦП

https://gitlab.com/rocketfirm/basis-a/basis-digital-signature репозиторий для сервиса

Прод:

https://lk01.bazis.kz

Прод админка:

https://lk02.bazis.kz/admin/login

CRM test:

https://demo.uco.kz/crmc/#!

CRM prod:

https://bazis-online.kz/crmc/#!

сервер приложений

ssh rk@89.107.99.10 -p 48035

сервер бд

ssh rk@89.107.99.10 - p 48036

Внутренний ip CRM 192.168.7.22

Прод БД:

1\. 192.168.7.33; /var/lib/pgsql/12/data/;

2\. admin\_bazis

3\. Файлы сайта и файлы Базы данных находятся на разных серверах. Файлы базы указал в пункте 1, а файлы сайта (Фронтенда и бэкенда) находятся на севрере 192.168.7.32 в папках /var/www/sites/bazis-a и /var/www/bazis-api/