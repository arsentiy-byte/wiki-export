# Книги > Mattermost > Функциональность > Пересылка сообщений

# Пересылка сообщений

Согласно официальной документации mattermost:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/dU9image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/dU9image.png)

Иными словами, пересылать сообщения можно только внутри приватных чатов (то есть "цитирование") и из публичного чата. Всё.   
  
Для обхода этого ограничения рекомендую пользоваться скриншотерами:  
\- Linux: flameshot  
\- Windows: Ножницы  
\- MacOS: cmd+shift+4