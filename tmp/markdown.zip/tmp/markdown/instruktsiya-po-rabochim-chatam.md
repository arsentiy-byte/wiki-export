# Книги > Рабочие чаты > Инструкция по рабочим чатам

# Инструкция по рабочим чатам

1. Название чата должно быть в формате Prod: Название проекта 
2. В чате должна быть аватарка — логотип проекта, бренда или тематически подходящая иконка
3. По умолчанию создатель чата добавляет в администраторы:  
    — по г. Нур-Султан: [Настю Медведскую](https://intra.rocketfirm.com/users/profile/34/), [Олега Качалина](https://intra.rocketfirm.com/users/profile/7/), [Романа Надеина](https://intra.rocketfirm.com/users/profile/14/) и [Полину Сигачеву](https://intra.rocketfirm.com/users/profile/?id=454)  
    — по г. Алматы: [Олега Качалина](https://intra.rocketfirm.com/users/profile/7/), [Романа Надеина](https://intra.rocketfirm.com/users/profile/14/)

1. Для технических проектов добавляем ботов:  
    Гитлаб — [t.me/rocket\_gitlab\_bot  
    ](https://t.me/rocket_gitlab_bot)Проверка кронзадач — t.me/rocket\_healthchecks\_bot
2. В чате должны быть закреплены все ссылки на проект

##### **Пример**: 

**Jira:** [jira.rocketfirm.com/secure/RapidBoard.jspa?rapidView=204&amp;projectKey=BGS](https://wiki.rocketfirm.com/jira.rocketfirm.com/secure/RapidBoard.jspa?rapidView=204&projectKey=BGS)

**Figma:** [figma.com/file/CGJrYtnauef4gywU9xn0Qi/BI-Group-—-800-schools?node-id=8%3A117  
  
](https://www.figma.com/file/CGJrYtnauef4gywU9xn0Qi/BI-Group-%E2%80%94-800-schools?node-id=8%3A117)**Проект в интре:** [intra.rocketfirm.com/clients/deals/deal-view/?id=2937](https://wiki.rocketfirm.com/intra.rocketfirm.com/clients/deals/deal-view/?id=2937)

**Верстка сайта**: [markup.rocketfirm.net/800mektep](https://wiki.rocketfirm.com/markup.rocketfirm.net/800mektep)

**Админка тестовая:** [bigroup-school.rocketfirm.net/admin](https://wiki.rocketfirm.com/bigroup-school.rocketfirm.net/admin) 

**Продакшен:** [800mektep.kz/ru](http://800mektep.kz/ru)

1. Пароли от тестовой админки разработчики и тестировщики должны брать в сервисе [pass.rocketfirm.com/#/lock](https://pass.rocketfirm.com/#/lock). Про работу с сервисом читайте тут — [wiki.rocketfirm.com/books/bezopasnost-paroley/page/bezopasnost-paroley](https://wiki.rocketfirm.com/wiki.rocketfirm.com/books/bezopasnost-paroley/page/bezopasnost-paroley)
2. В рабочем чате ежедневно пишем стендапы (разработчики, тестировщики, дизайнеры)  
    Что это и как их писать: [intra.rocketfirm.com/library/designers/1365-stendapy-vo-vrema-karantina](https://wiki.rocketfirm.com/intra.rocketfirm.com/library/designers/1365-stendapy-vo-vrema-karantina)