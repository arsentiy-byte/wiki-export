# Книги > HR-вопросы для интервью > Flutter разработчик

# Flutter разработчик

### Общие вопросы по Flutter и Dart

#### Junior

1. **Что такое Flutter и для чего он используется?**
    
    
    - **Ответ:** Flutter — это UI-фреймворк от Google для создания кроссплатформенных приложений на Android, iOS, вебе и настольных платформах из одного кода.
2. **Какие основные компоненты есть в Flutter?**
    
    
    - **Ответ:** Основные компоненты включают виджеты (widgets), которые можно разделить на StatelessWidget и StatefulWidget.
3. **Что такое Dart?**
    
    
    - **Ответ:** Dart — это язык программирования, разработанный Google, используемый для написания приложений на Flutter.

#### Middle

1. **Какие виджеты используются для создания пользовательского интерфейса в Flutter?**
    
    
    - **Ответ:** Виджеты можно разделить на базовые (например, Text, Image, Container) и более сложные (например, ListView, GridView).
2. **Что такое State и как он используется в Flutter?**
    
    
    - **Ответ:** State — это объект, который содержит данные, влияющие на внешний вид и поведение виджета. StatefulWidget создает State объект, который может быть изменен в течение времени, вызывая перерисовку виджета.
3. **Объясните, что такое hot reload и hot restart в Flutter.**
    
    
    - **Ответ:** Hot reload обновляет только измененные части кода и сохраняет текущее состояние приложения. Hot restart перезапускает все приложение заново, сбрасывая все состояния.

### Работа с виджетами и навигация

#### Junior

1. **Как создать простой StatelessWidget в Flutter?**
    
    
    - **Ответ:** Пример кода: `class MyWidget extends StatelessWidget {  @override  Widget build(BuildContext context) {    return Text('Hello, Flutter!');  }}`
2. **Что такое Scaffold в Flutter?**
    
    
    - **Ответ:** Scaffold — это базовый макетный виджет, который предоставляет структуру для приложения, включая AppBar, Drawer, FloatingActionButton и другие.

#### Middle

1. **Как реализовать навигацию между экранами в Flutter?**
    
    
    - **Ответ:** Для навигации используется Navigator, примеры методов — push и pop. Пример кода: `Navigator.push(  context,  MaterialPageRoute(builder: (context) => SecondScreen()),);`
2. **Как работает виджет FutureBuilder?**
    
    
    - **Ответ:** FutureBuilder используется для асинхронных операций, таких как получение данных из сети. Он принимает Future и строит виджет на основе его состояния.

### Работа с состоянием

#### Junior

1. **Как обновить состояние виджета в Flutter?**
    
    
    - **Ответ:** Используйте setState в StatefulWidget для обновления состояния. Пример кода: `setState(() {  _counter++;});`
2. **Чем отличается StatelessWidget от StatefulWidget?**
    
    
    - **Ответ:** StatelessWidget не имеет состояния и не может быть изменен после создания, тогда как StatefulWidget имеет состояние, которое можно изменять.

#### Middle

1. **Что такое Provider и как его использовать?**
    
    
    - **Ответ:** Provider — это пакет для управления состоянием, который обеспечивает доступ к состоянию через контекст. Пример использования: `ChangeNotifierProvider(  create: (context) => MyModel(),  child: MyApp(),);`
2. **Объясните концепцию InheritedWidget и его применение.**
    
    
    - **Ответ:** InheritedWidget позволяет передавать данные вниз по дереву виджетов. Он используется для создания контекста, доступного для всех виджетов в дереве.

### Асинхронное программирование

#### Junior

1. **Как работать с Future в Dart?**
    
    
    - **Ответ:** Future представляет собой значение, которое будет доступно в будущем. Для работы с Future используется async/await. Пример: `Future fetchData() async {  return 'data';}`
2. **Что такое async и await в Dart?**
    
    
    - **Ответ:** async указывает, что функция является асинхронной и возвращает Future. await приостанавливает выполнение функции до завершения Future.

#### Middle

1. **Какой метод используется для выполнения кода в параллельных изолятах (isolates)?**
    
    
    - **Ответ:** Для выполнения кода в изолятах используется функция `Isolate.spawn`. Пример: `Isolate.spawn(entryPoint, message);`
2. **Как использовать Stream в Dart и Flutter?**
    
    
    - **Ответ:** Stream используется для работы с асинхронными последовательностями данных. Для подписки на Stream используется StreamBuilder или метод listen. Пример: `Stream counterStream = Stream.periodic(Duration(seconds: 1), (i) => i);counterStream.listen((data) {  print(data);});`

### Работа с сетью и хранение данных

#### Junior

1. **Как выполнить HTTP-запрос в Flutter?**
    
    
    - **Ответ:** Для выполнения HTTP-запросов используется пакет `http`. Пример кода: `final response = await http.get(Uri.parse('https://example.com'));`
2. **Как сохранить данные локально в Flutter?**
    
    
    - **Ответ:** Для хранения данных локально можно использовать пакет `shared_preferences`. Пример кода: `SharedPreferences prefs = await SharedPreferences.getInstance();await prefs.setString('key', 'value');`

#### Middle

1. **Что такое JSON сериализация и десериализация в Dart?**
    
    
    - **Ответ:** Сериализация — это преобразование объектов в JSON-строку, десериализация — обратно в объект. Пример: `String jsonString = jsonEncode(myObject);MyObject myObject = jsonDecode(jsonString);`
2. **Как реализовать работу с WebSocket в Flutter?**
    
    
    - **Ответ:** Для работы с WebSocket используется пакет `web_socket_channel`. Пример: `final channel = IOWebSocketChannel.connect('ws://example.com');channel.stream.listen((message) {  print(message);});`

### Продвинутые вопросы

#### Middle

1. **Как работает система анимаций в Flutter?**
    
    
    - **Ответ:** Система анимаций включает в себя такие классы, как Animation, AnimationController, и Tween. Используются для создания анимаций путем изменения значений с течением времени.
2. **Объясните, как работают ключи (Keys) в Flutter и для чего они используются.**
    
    
    - **Ответ:** Ключи используются для сохранения состояния виджетов при перестроении дерева виджетов. Есть два основных типа ключей: ValueKey и UniqueKey.

### Тестирование и отладка

#### Junior

1. **Как написать простой тест для виджета в Flutter?**
    - **Ответ:** Используйте пакет `flutter_test`. Пример кода: `testWidgets('MyWidget has a title and message', (WidgetTester tester) async {  await tester.pumpWidget(MyWidget());  final titleFinder = find.text('Title');  expect(titleFinder, findsOneWidget);});`

#### Middle

1. **Что такое golden tests в Flutter?**
    
    
    - **Ответ:** Golden tests проверяют визуальное представление виджетов, сравнивая их с эталонными изображениями.
2. **Как использовать DevTools для отладки приложений на Flutter?**
    
    
    - **Ответ:** DevTools предоставляет инструменты для отладки, включая инспектор виджетов, графики производительности и анализатор памяти.

### Работа с данными и сетью

#### Junior

1. **Как получить данные из REST API в Flutter?**
    
    
    - **Ответ:** Используйте пакет `http` для выполнения GET-запросов. Пример: `final response = await http.get(Uri.parse('https://example.com/data'));if (response.statusCode == 200) {  // Parse the JSON  final data = jsonDecode(response.body);} else {  throw Exception('Failed to load data');}`
2. **Как сохранить и получить данные с помощью SharedPreferences?**
    
    
    - **Ответ:** Используйте пакет `shared_preferences`. Пример: `SharedPreferences prefs = await SharedPreferences.getInstance();await prefs.setString('key', 'value');String value = prefs.getString('key') ?? 'default';`

#### Middle

1. **Как работать с SQLite в Flutter?**
    
    
    - **Ответ:** Используйте пакет `sqflite` для работы с базой данных SQLite. Пример: `final database = openDatabase(  'my_database.db',  onCreate: (db, version) {    return db.execute(      'CREATE TABLE my_table(id INTEGER PRIMARY KEY, name TEXT)',    );  },  version: 1,);`
2. **Как обрабатывать ошибки сети в Flutter?**
    
    
    - **Ответ:** Обрабатывайте ошибки с помощью try-catch блоков и проверяйте статусы HTTP-ответов. Пример: `try {  final response = await http.get(Uri.parse('https://example.com/data'));  if (response.statusCode == 200) {    // Handle successful response  } else {    // Handle error response  }} catch (e) {  // Handle network errors}`

### Навигация и маршрутизация

#### Junior

1. **Как реализовать базовую навигацию между экранами в Flutter?**
    
    
    - **Ответ:** Используйте Navigator и MaterialPageRoute. Пример: `Navigator.push(  context,  MaterialPageRoute(builder: (context) => SecondScreen()),);`
2. **Как вернуться на предыдущий экран в Flutter?**
    
    
    - **Ответ:** Используйте метод Navigator.pop(). Пример: `Navigator.pop(context);`

#### Middle

1. **Как использовать named routes в Flutter?**
    
    
    - **Ответ:** Определите маршруты в MaterialApp и используйте Navigator.pushNamed() для навигации. Пример: d`MaterialApp(  initialRoute: '/',  routes: {    '/': (context) => HomeScreen(),    '/second': (context) => SecondScreen(),  },);Navigator.pushNamed(context, '/second');`
2. **Как реализовать переходы с анимацией между экранами в Flutter?**
    
    
    - **Ответ:** Используйте PageRouteBuilder и определите анимацию. Пример: `Navigator.push(  context,  PageRouteBuilder(    pageBuilder: (context, animation, secondaryAnimation) => SecondScreen(),    transitionsBuilder: (context, animation, secondaryAnimation, child) {      const begin = Offset(1.0, 0.0);      const end = Offset.zero;      const curve = Curves.ease;      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));      var offsetAnimation = animation.drive(tween);      return SlideTransition(position: offsetAnimation, child: child);    },  ),);`

### Производительность и оптимизация

#### Junior

1. **Как оптимизировать рендеринг виджетов в Flutter?**
    
    
    - **Ответ:** Избегайте излишнего использования setState, используйте const конструкторы, где это возможно, и минимизируйте количество виджетов в дереве.
2. **Что такое Lazy Loading и как его реализовать в списках в Flutter?**
    
    
    - **Ответ:** Lazy Loading загружает данные по мере необходимости, например, при прокрутке списка. Используйте ListView.builder и добавляйте данные по мере прокрутки. Пример: `ListView.builder(  itemCount: items.length,  itemBuilder: (context, index) {    if (index == items.length - 1) {      // Load more data    }    return ListTile(title: Text(items[index]));  },);`

#### Middle

1. **Как профилировать и улучшать производительность Flutter-приложений?**
    
    
    - **Ответ:** Используйте Flutter DevTools для профилирования производительности, анализируйте и устраняйте bottleneck'и, оптимизируйте рендеринг и работу с памятью.
2. **Как управлять асинхронными операциями для предотвращения замедлений в UI?**
    
    
    - **Ответ:** Используйте Isolates для тяжелых вычислений, которые не должны блокировать основной поток. Пример: `Isolate.spawn(computeFunction, data);`

### Деплой и CI/CD

#### Junior

1. **Как создать релизную сборку Flutter-приложения для Android?**
    
    
    - **Ответ:** Выполните команды: `flutter build apk --release`
2. **Как создать релизную сборку Flutter-приложения для iOS?**
    
    
    - **Ответ:** Выполните команды: `flutter build ios --release`

#### Middle

1. **Как настроить CI/CD для Flutter-приложения с использованием GitHub Actions?**
    
    
    - **Ответ:** Создайте `.github/workflows/main.yml` с настройками для сборки и тестирования приложения. Пример: `name: Flutter CIon: [push, pull_request]jobs:  build:    runs-on: ubuntu-latest    steps:    - uses: actions/checkout@v2    - uses: subosito/flutter-action@v2      with:        flutter-version: '2.0.0'    - run: flutter pub get    - run: flutter build apk --release`
2. **Как использовать Firebase для автоматического деплоя приложений?**
    
    
    - **Ответ:** Настройте Firebase App Distribution и используйте команды `firebase appdistribution:distribute`. Пример для Android: `firebase appdistribution:distribute build/app/outputs/flutter-apk/app-release.apk --app `

### Подготовка к релизу и загрузка в магазины

#### Junior

1. **Как подготовить иконку приложения для Flutter?**
    
    
    - **Ответ:** Используйте пакет `flutter_launcher_icons`. Добавьте настройки в `pubspec.yaml` и выполните: `flutter pub run flutter_launcher_icons:main`
2. **Как настроить файл AndroidManifest.xml для релиза?**
    
    
    - **Ответ:** Убедитесь, что в манифесте указаны необходимые разрешения и метаданные, такие как package name, версия и пр.

#### Middle

1. **Как настроить App Store Connect и загрузить приложение на iOS?**
    
    
    - **Ответ:** Используйте Xcode для архивации и загрузки приложения в App Store Connect. Подготовьте скриншоты, описание и заполните все необходимые поля для публикации.
2. **Как подписать APK для релиза на Google Play?**
    
    
    - **Ответ:** Создайте ключевой магазин и подпишите приложение с помощью keytool и jarsigner. Пример: `keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias`Затем используйте jarsigner: `jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my-release-key.jks app-release-unsigned.apk my-key-alias`И завершите выравниванием: `zipalign -v 4 app-release-unsigned.apk app-release.apk`