# Книги > Magnolia crm > User manual > Magnolia Accreditation Beginner Level 102

# Magnolia Accreditation Beginner Level 102

[![Снимок экрана 2022-02-25 в 11.41.59.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/snimok-ekrana-2022-02-25-v-11-41-59.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/snimok-ekrana-2022-02-25-v-11-41-59.png)

[Pdf Magnolia Accreditation Beginner Level 102](https://disk.yandex.kz/i/Prjrv4YKsXL1gg "Pdf Magnolia Accreditation Beginner Level 102")