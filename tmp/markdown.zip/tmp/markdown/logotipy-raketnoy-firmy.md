# Книги > Логотипы «Ракетной фирмы» > Логотипы «Ракетной фирмы»

# Логотипы «Ракетной фирмы»

Логотип можно использовать в презентациях, документах и дизайн-макетах. В случае с дизайн-макетами разрешается перекрашивать логотип под стиль сайта. Во всех остальных случаях логотип должен быть оригинальным (черный плюс красный) или белым.

Все варианты ниже — в формате png, без фона.

[![image-1627643110200.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/scaled-1680-/image-1627643110200.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/image-1627643110200.png)

[![image-1627643198409.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/scaled-1680-/image-1627643198409.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/image-1627643198409.png)