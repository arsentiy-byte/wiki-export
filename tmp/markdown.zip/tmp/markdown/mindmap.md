# Книги > Qalam > Mindmap

# Mindmap

[qalam.world (1-й этап).png](https://wiki.rocketfirm.com/attachments/6)