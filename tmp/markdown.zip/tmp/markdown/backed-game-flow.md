# Книги > Caps Arena > Backed game flow

# Backed game flow

### Старт игры и поиск противника

1. `POST /game/find`  
    Параметр `cap_set_id`  
    Блокируются фишки. Если противник не найден, то фишки разблокируются.
2. Вызывается событие `info.find.gamer`  
    Канал: `find.gamer.{id}`  
    Оно сообщает что начат поиск игрока.
3. На сервере job в течении N минут ищет соперника. N - указан в .env   
    `FIND_GAMER_WAIT_SECONDS` - если не указан в .env, то берется 120 сек. В течении этого времени ищется соперник в Redis  
    `FIND_GAMER_SLEEP_SECONDS` - если не указан в .env, то берется 5 сек. Это перирод, с которым опрашивается Redis  
    \- Если соперник не найден вызывается событие `failure.find.gamer` Канал: `find.gamer.{id}`  
    \- Если соперник найден, то обоим игрокам приходит событие `success.find.gamer` Канал: `find.gamer.{id}`  
    В вебсокете всем игрокам приходит key для подтверждения игры  
    На сервере запускается новый job, который 10 секунд ждёт подтверждения от обоих игроков.

2\. АПИ POST /game/find/cancel  
Параметр cap\_set\_id  
Отклонить игру.  
Вызывается до момента пока игрок не найден.

```
3. АПИ POST /game/confirm
Параметры: key, is_confirm, cap_set_id
   key берется с события success.find.gamer
   is_confirm 1 или 0 (подтвердить или отказать)

3.1. На сервере крутится job 10 сек, который ждет подтверждения от всех игроков

3.2. Если один из игроков не подтвердил игру или отказал, то вызывается событие failure.dice.game Канал: find.gamer.{id}
   Приходит статус:
       1 => 'Вы отказали', (Приходит тому кто отказал).
       2 => 'Вы не подтвердили', (Приходит тому кто не подтвердил).
       3 => 'Оппонент отказал', (Приходит тому кто подтвердил, но оппонент отказал).
       4 => 'Оппонент не подтвердил', (Приходит тому кто подтвердил, но оппонент не подтвердил).

3.3. Создается job по созданию игры в БД
   Вызывается для каждого игрока событие create.game Канал: find.gamer.{id}
   Возвращается game_id

3.4. Удаляются из redis данные по поиску по данной игре и по данным игрокам




//На данный момент все игроки подписаны на новый канал игры и будут работать чисто с ним


4.0. Вызывается событие game.before.dice Канал: game.{id}
    Информирует какое первоначальное количество фишек у всех игроков, кто первый ходит.
    Возвращаются данные:
    'game_id' => $this->gameId,
    'first_move_id' => $this->firstMoveId,
    'cap_set_id' => $this->capSetId,
    'users_caps' => $this->usersCapsArray,
    'users' => [
            [
                'id' => $this->id,
                'name' => $this->name,
                'avatar' => $this->getAvatarPath(),
            ]
    ]


4. АПИ POST /game/dice
Параметры: game_id

4.1. Вызывается событие game.dice Канал: game.{id}
   Возвращаются данные:
   'gameId' - id самой игры.
   'movedPlayer' - id игрока, который бросил кубик.
   'diceValue' - значение брошенного кубика.
   'wilMovePlayer' - id игрока, который будет следующий ходить (null если все походили).

5. АПИ POST /game/positions

5.1 Вызывается событие game.positions Канал: game.{id}
    Возвращаются данные:
    'gameId' => $this->gameId,
    'users' =>
            'id' => $this->id,
            'user_id' => $this->user_id,
            'move_position' => $this->move_position,
    Необходимо событие для очередности ходов в игре

6. АПИ POST /game/move
Параметры: game_id

6.1 Вызывается событие game.move Канал: game.{id}
    Возвращаются данные:
    'game_users' => GamesUsersResource::collection($this->gameUsers),
    'game_users_caps_opened' => GamesUsersCapsTableResource::collection($this->gameUsersCapsOpened),
    'game_users_caps_others' => GamesUsersCapsTableResource::collection($this->gameUsersCapsOthers),
    'next_move_user_id' => $this->nextMoveUserId,
    'current_move_user_id' => $this->currentMoveUserId,
    'count_current_move' => $this->countCurrentMove

    public const STATUSES = [
        1 => 'В колоде',
        2 => 'Разбросаны, закрыты',
        3 => 'Разбросаны, открыты'
    ]

    Когда фишек не остается на поле, то next_move_user_id = null. Игра окончена, сменяются владельцы фишек, фишки разблокированы.

7. АПИ GET /game/{game_id}/statistic
Статистика по игре




```