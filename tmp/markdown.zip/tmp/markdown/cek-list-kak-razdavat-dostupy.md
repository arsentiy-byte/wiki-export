# Книги > PPC > Полезная информация > Чек-лист: как раздавать доступы

# Чек-лист: как раздавать доступы

### [Ссылка на документ](https://docs.google.com/document/d/1IklXgYEKFCkgF6V5ZM45k6yU2QKuqsnRjiMS_B7_9NA/edit)