# Книги > Shared > Как использовать Kibana

# Как использовать Kibana

0\) Получаем доступ в Kibana. Для этого пишем [мне](https://t.me/HyperColored) или [Асель](https://t.me/aseelosun) в телеграм. От вас потребуется только адрес внутренней почты и название проекта, доступ к логам которого нужен. Мы в ответ пришлём логин и пароль.

1\) Переходите по ссылке [https://kibana.rocketfirm.com](https://kibana.rocketfirm.com)

 Если вы выполнили п.0, то у вас уже есть логин и пароль - логинитесь.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/image.png)

2\) Если у вас есть права больше чем на один проект - откроется такое окошко:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/vE2image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/vE2image.png)

В нём будут перечислены пространства всех проектов, к которым у вас есть доступ. В пространстве проекта будут находиться логи фронта и бэка для каждой из сред (dev/prod).

Выбираете нужное пространство. Если у вас есть права только на одно пространство, то оно откроется сразу.

3\) Вы оказываетесь на главной странице пространства:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/8BPimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/8BPimage.png)

Здесь вам доступно:

\- меню с разделами (слева сверху), которые вам доступны (сейчас это будет только Analytics)

\- выбор пространства (квадрат сразу справа от меню)

\- большие плашки с названиями разделов, которые вам доступны. Учётке на скриншоте доступен только раздел Analytics. Удобно, если не хочется вообще залезать в меню.

4\) Чтобы посмотреть логи, вам нужно кликнуть на плашку Analytics, а затем на плашку Discover. Аналогично делается из меню.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/GISimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/GISimage.png)

5\) Откроется окошко, в котором вам будут доступны логи по всем объектам (фронт, бэк, прод/дев) пространства.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/aboimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/aboimage.png)

Важный момент - по умолчанию фильтр отображает только логи за последние 15 минут. Чтобы изменить временной интервал, нажмите на значок календаря справа сверху. Чуть ниже расскажу, как изменить временной интервал для пространства по умолчанию.

Слева сверху, прямо под значком меню, доступен выбор объекта, логи которого доступны (фронт/бэк, дев/прод). На скриншоте это синяя плашка dev-back-report.

6\) **Экспериментируйте!** Кибана позволяет фильтровать результаты по определённому полю, задавать сложные фильтры с логическими условиями и даже сварит вам кофе (нет).

7\) Как изменить временной интервал при просмотре логов, отображаемый по умолчанию (дефолтное значение - последние 15 минут для всех пространств).

 Клик по кнопке меню &gt; Stack Management. Далее выбирайте Advanced settings в разделе меню Kibana, откроется окошко с настройками.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/JYfimage.png) ](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/JYfimage.png)[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/SReimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/SReimage.png)

Пролистните раздел General до конца (до начала следующего раздела), увидите такую настройку:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/EPfimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/EPfimage.png)

По умолчанию там будет блок, как на скриншоте с пометкой Default. Измените значение с 15m на удобное для вас, например на 24h как в моем примере. Система предложит вам сохранить настройку - сохраняйте. При желании значение этой настройки можно сбросить до дефолтного значения.