# Книги > Magnolia crm > User manual > Ответы на тест

# Ответы на тест

[![Снимок экрана 2022-02-25 в 10.33.07.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/snimok-ekrana-2022-02-25-v-10-33-07.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/snimok-ekrana-2022-02-25-v-10-33-07.png)

Тут мои наработки по тесту [https://docs.google.com/document/d/1MGnuINjGDk\_H9imJySmvtytsuyrCcjTV7IkHhFAYI5E/edit?usp=sharing](https://docs.google.com/document/d/1MGnuINjGDk_H9imJySmvtytsuyrCcjTV7IkHhFAYI5E/edit?usp=sharing "https://docs.google.com/document/d/1MGnuINjGDk_H9imJySmvtytsuyrCcjTV7IkHhFAYI5E/edit?usp=sharing")