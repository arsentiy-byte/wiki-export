# Книги > Единый стандарт кода (PHP, Laravel) > Документирование

# Документирование

#### Базовый стандарт для оформления документации в коде  


Код ДОЛЖЕН быть оформлен согласно правилам, указанным в стандарте [PSR-19](https://github.com/php-fig/fig-standards/blob/master/proposed/phpdoc-tags.md).

#### Дублирование типов в docblock

Указание типов аргументов с помощью `@param` и `@return`, дублирующее сигнатуру метода *НЕДОПУСТИМО*, кроме случаев:

- Наличия комментария к параметру, или результату.
- Аннотации используются сторонними средствами: psalm, phan, phpstan, и т.д.

```php
// Правильно
public function incrementProductPriceByName(string $productName, float $price): bool
{
// ...

// Неправильно
/**
 * @param string $productName
 * @param float  $price
 * @return bool
 */
public function incrementProductPriceByName(string $productName, float $price): bool
{
// ...
```

```php
// Правильно
/** 
 * @param array{scheme:string,host:string,path:string} $parsedUrl
 * @phan-param array{scheme:string,host:string,path:string} $parsedUrl
 * @psalm-param array{scheme:string,host:string,path:string} $parsedUrl  
*/
public function showUrl(string $label, array $parsedUrl, string $host): string
{
```

Указание типов свойств с помощью `@var`, дублирующее тип свойства НЕДОПУСТИМО, кроме случаев наличия комментария к свойству (php 7.4+).

```php
// Правильно ( $productNames
 */
public function incrementProductPricesByNames(array $productNames, float $price): bool
{
// ...

// Неправильно
/**
 * @param array $productNames
 */
public function incrementProductPricesByNames(array $productNames, float $price): bool
{
// ...
```

#### Неопределенные типы аргументов и возвращаемых результатов

В случае, если аргумент (или возвращаемый результат) метода может быть разных типов НЕОБХОДИМО перечислить все допустимые типы в docblock или напрямую в описании типов.

```php
// Правильно
/**
 * @param string|int $stringOrIntArgument
 * @return float|string|object
 */
public function method(string|int $stringOrIntArgument): float|string|object
{
// ...

// Правильно
/**
 * @param string|int $stringOrIntArgument
 * @return float|string|object
 */
public function method(mixed $stringOrIntArgument): mixed
{
// ...
```

```php
// Неправильно
/**
 * @param mixed $stringOrIntArgument
 * @return mixed
 */
public function method(mixed $stringOrIntArgument): mixed
{
// ...
```

#### Тип переменных

Если ожидаемый тип переменной явно не определен НЕОБХОДИМО определить его с помощью однострочного docblock комментария. Так же необходимо указывать ожидаемый тип, если IDE не может его определить, или определяет не корректно.

```php
$rows = [
    [
        'id'        => 1,
        'createdAt' => new \DateTimeImmutable(),
    ],
    [
        'id'        => 2,
        'createdAt' => new \DateTimeImmutable(),
    ],
    // ...
];

foreach ($rows as $row) {
    /** @var int $id */
    $id = $row['id'];
    /** @var \DateTimeImmutable $createdAt */
    $createdAt = $row['createdAt'];
    // ...
}
```

#### Свойства

Свойства класса ДОЛЖНЫ содержать либо декларацию типа, либо docblock для всех возможных типов значений, которое они могут содержать. ДОПУСТИМО указывать декларацию типа и docblock только в случаях, когда dockblock уточняет декларацию, либо при наличии комментария.

```php
/** @var array|null */
private $names;

/** @var int|null */
private $count;

/** @var array|null */
private ?array $names;

private ?int $count;

```

#### Методы и функции

Docblock для методов и функций ДОЛЖНЫ быть многострочными.

```php
// Неправильно
/** @param string[] $userNames */
public function saveUserNames(array $userNames): void

// Правильно
/**
 * @param string[] $userNames
 */
public function saveUserNames(array $userNames): void
```