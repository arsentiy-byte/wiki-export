# Книги > PHP > ElasticSearch. Основы > Лимиты

# Лимиты

Лимитировать количество результатов можно с помощью size, по умолчанию возвращаются все результаты поиска. Так же имеется параметр from, ссылка на [документацию](https://www.elastic.co/guide/en/elasticsearch/reference/6.8/search-request-from-size.html)

```JSON
GET /_search
{
    "from" : 0, "size" : 10,
    "query" : {
        "term" : { "user" : "kimchy" }
    }
}
```