# Книги > PHP > Laravel cookbook > Очистить кэш

# Очистить кэш

```bash
php artisan optimize:clear
```

[https://www.linkedin.com/pulse/how-clear-cache-laravel-using-artisan-command-mohsin-khan](https://www.linkedin.com/pulse/how-clear-cache-laravel-using-artisan-command-mohsin-khan)