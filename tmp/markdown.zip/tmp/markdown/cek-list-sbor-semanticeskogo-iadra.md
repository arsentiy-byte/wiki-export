# Книги > PPC > Полезная информация > Чек-лист: сбор семантического ядра

# Чек-лист: сбор семантического ядра

### [Ссылка на документ](https://docs.google.com/document/d/1Qp6UsQ1k5Pk9w2dknRgollP66uXiwBt9o8vrqwTgyt8/edit)