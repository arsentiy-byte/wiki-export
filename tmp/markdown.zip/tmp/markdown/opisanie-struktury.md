# Книги > PHP > Swagger > Описание структуры

# Описание структуры

---

Swagger это мощный инструмент для документирования API, который широко используется разработчиками по всему миру. Он имеет открытый исходный код и огромное количество пакетов и расширений. Для Yii2 в composer есть пакет для [zircote/swagger-php](https://github.com/zircote/swagger-php), который позволяет автоматически генерировать документацию на основании комментариев в коде, для Laravel так же есть пакет [DarkaOnLine / L5-Swagger](https://github.com/DarkaOnLine/L5-Swagger).

Документация хранится в формате json или yaml. Стандартная структура файла выглядит следующим образом.

##### Раздел *info* - описание проекта

```YAML
openapi: 3.0.0
info:
  title: Pinmates API
  description: Golf App
  version: 1.0.0

```

##### Раздел *servers* - адрес сервера, может быть несколько (прод и тест)

```YAML
servers:
  - url: https://pinmates.rocketfirm.net/api.php/v1
    description: Stage (test) server

```

##### Раздел *tags* - теги запросов или категории, удобны для компоновки endpoit-ов в группы

```YAML
tags:
  -
    name: Categories
    description: 'API Endpoints of Categories'

```

##### Раздел *paths* - основной раздел с описанием запросов

```YAML
paths:
  /auth/login/:
    post:
      tags:
        - auth
      summary: 'Пользователь. Вход'
      description: '#### Вход в приложение по номеру телефона и паролю'
      security:
        - bearerAuth: []
      requestBody:
        $ref: '#/components/requestBodies/Login'
      responses:
        '200':
          description: Вход успешно выполнен
          content:
            application/json:
              schema:
                type: object
                properties:
                  success:
                    type: boolean
                    default: true
                  message:
                    type: string
                    default: 'success'
                  data:
                    type: object
                    properties:
                      token:
                        type: string
                      phone:
                        type: string
        '404':
          description: Not found.
```

Раздел Paths состоит из:

- endpoint
- метод
- название
- описание
- параметры для GET запросов (описание параметров можно найти в официальной документации)
- тело запроса для POST запросов (описание тела запросов можно найти в официальной документации)
- ответы (описание ответов все там же) 
    - код ответа
    - описание
    - структура ответа

##### Раздел *components* - необязательный, но полезный раздел, которые позволяет сократить код и избежать повторений.

В нем описаны компоненты. Чаще всего к компонентам относятся:

- модели данных *- components/schemas*
- тела POST запросов - *components/requestBodies*
- тип авторизации - *components/securitySchemes,* поддерживается несколько видов, включая Basic Auth, Bearer Token и OAuth2

```YAML
components:
  schemas:
    Country:
      type: object
      properties:
        id:
          type: integer
          format: int64
        title:
          type: string
      xml:
        name: Country
    City:
      type: object
      properties:
        id:
          type: integer
          format: int64
        title:
          type: string
      xml:
        name: City
  requestBodies:
    Login:
      content:
        application/json:
          schema:
            type: object
            properties:
              phone:
                type: string
              password:
                type: string
  securitySchemes:
    bearerAuth:
      type: http
      description: 'Токен авторизации'
      scheme: bearer
```