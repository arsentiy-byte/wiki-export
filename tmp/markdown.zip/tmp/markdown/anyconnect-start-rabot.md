# Книги > Работа с HH > Загрузка страницы вакансий в hh > AnyConnect старт работ

# AnyConnect старт работ

подключаемся к vpn AnyConnect (инструкция по установки и подключению [тут](https://wiki.rocketfirm.com/books/rabota-s-hh/chapter/anyconnect))

используем доступы из Pass, Полина или Ярослав

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXd5_4KkjaCUo3HW064Om2XXAKBtDrAx0j_jzaRc4hZkVvsvgVUPaQrK1sBYeDX6q13CFVI7rfd9o-jr2b9kURh9jZsvVn4Y6tO0yQqZe8dWFZ6TqCw9aa-FPDqDrYxucpZj71uAraR8_o5rNBEek5Dn5rc?key=GoCkmrK5QxgH0NrMeVt1uA)  


Требуется подтвреждение на телефоне через приложение Multifactor? соответствено просим соответствующего человека подтвердить вход

Переходим на https://hh.kz/ или той страны в которую грузим https://hh.ru/ и тд  
Авторизуемся под доступами Полины на сайте

В поиске ицем нужную компанию и переходим на главную страницу

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXcvBxdxQfIf2p6GZJCNlqZSa3UyF1KA8dXaocCPMUYOft3ApKWUSXJzKQfh4d4zCfeSIhzhYf_bC3St5KkaXaHPJL8I7akb5vmAs2F5O5aLszipkqXGDr7yowFPGIyUGidFmwKtCsO4ZMabjI8chIGGpnU?key=GoCkmrK5QxgH0NrMeVt1uA)

Выбираем и перходим к шаблону вакансии

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXcy5-cMjhP21qkHge2CrZg9OzZguUTspj-RwkZ3WCrAfKemP76H7FG65hSDL0VqE8vxlq3tnIpy3WOS8PpJnA61kPV2Hg0aeqdedLeS8Af4aCWQlAaX4PKlG37atldPFpnPI1znDL77m6mlpNvNbm1evUM?key=GoCkmrK5QxgH0NrMeVt1uA)

ниже конструктор для код ![](https://lh7-us.googleusercontent.com/docsz/AD_4nXc6qbcFHErG2YCe5AZQrxv-IKSb-AEPnjjkILlstaCqfMMOfNvKIkeROgckZdTXXksAhW8lUcBDjGvYRACo5BcVTQI7He6KRCaN593cHxAV-ogWOIcE0Yl8mW7eGhKQD74i1JGe3CnpEKloUjWjeO5JemU9?key=GoCkmrK5QxgH0NrMeVt1uA)