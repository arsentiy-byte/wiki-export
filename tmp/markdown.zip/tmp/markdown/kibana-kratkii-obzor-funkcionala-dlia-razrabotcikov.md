# Книги > Shared > Kibana > Kibana - краткий обзор функционала для разработчиков

# Kibana - краткий обзор функционала для разработчиков

##### ELK-стек

ELK-стек -- это:

- Elasticsearch (хранение и поиск данных)
- Logstash (конвеер для обработки, фильтрации и нормализации логов)
- Kibana (интерфейс для удобного поиска и администрирования)

![](https://lh7-us.googleusercontent.com/iGqwDQbd0yZA_je0NRlEIpByl4sPZUe_fspMm0ZkAPM9ui4pAXCVdlRSv7qLzWhh39JbC6hXDUHfpGlnGRtulUhBqSWHaOOXunldfUifVA4EP-8eQtvnVpVimiNbohvpanb7m1MgyXcntVRKrkayV1Q)

альтернативный инструмент - Grafana является более универсальным инструментом и может интегрироваться с различными источниками данных и системами мониторинга.

другие альтернативные инструменты - Tableau, Microsoft Power BI, Looker, Metabase, Qlik Sense

##### Поиск среди логов

Для поиска среди записей необходимо использовать несложный язык запросов KQL ([статья](https://www.elastic.co/guide/en/kibana/current/kuery-query.html))

![](https://lh7-us.googleusercontent.com/FrVEoQTbq8dZ0lQhDMKQQ7t9Ph2ZirP8uxGBVvV6QflYzvhtvaX32NEefZoI_p4tH24SPNJuyUe9HZ5iFLiNXgZvmWzS5dYmeo4hqnyBIfMUSAnhLZGjsGaecOb1XPOBYFEkdPJCD3UoKnx_imBcPwY)

 Фильтры можно легко сохранять

![](https://lh7-us.googleusercontent.com/QP0hJgq8jw-Gwtkkk7FV1vZ-y6nOXQ0w6gIBqC7Qz-nBr7kJGcZyTXoRZdGcVMvjCpJ_5PEgLo3sJsv_R2PeHegqhOi5g7wvgPJwcKvIC4Lp9_rsu-h2xFnN8b5nZ_B39DEXVTAuquOmtllRUFLCOW4)

##### Визуализация

Kibana обладает мощным инструментарием по визуализации данных, более того различные варианты визуализации можно собирать в дашборды и делиться ими с коллегами ([пример 25 дашбордов ](https://logit.io/blog/post/the-top-kibana-dashboards-and-visualisations/))

[![dashboard.webp](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/dashboard.webp)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/dashboard.webp)

Kibana Graph генерирует визуальное отображение зависимостей между сущностями

![](https://lh7-us.googleusercontent.com/JstErhSkCXc92PHvc5e1ZHQr3UZcX9FuVOUHlj7SJNki7ACEwwjudfVIEjXI5jY-w8EhP6jXx7QTs_utnWuC8OU1LY8p4CnK8eMHMNAxbxofQDqg_PONumPA5-OmyQfb2Ldi6qRjQfL_GRDmyi7RMBk)

##### Application Performance Monitoring

[APM](https://www.elastic.co/observability/application-performance-monitoring) "Application Performance Monitoring" мониторинг производительности приложения — это часть Elastic Stack, предоставляющая инструменты для мониторинга производительности и анализа работы приложений.

В Kibana APM можно настроить для визуализации данных, таких как трейсы (трассировки запросов), метрики производительности, ошибки и другие аспекты работы приложения. Это позволяет разработчикам и операторам систем более эффективно мониторить и оптимизировать производительность приложений.

![](https://lh7-us.googleusercontent.com/iiGPlyoYSlcuqtbNb4DvPKsrIpLGxS3ENJFBkpgmw3qQNVxZGnAKz4YmmvT2AUzuV0ZHLC4gkEjJkFORnVu6P6zBuUE8x6qPVF7Ja3wvEvIA39ZRvqJ-N0YwlLHGBrfcZtGECiXLQO29IUHZSMPW3bg)

Kibana - APM - Service Map это визуализация структуры взаимосвязей компонентов продукта

![](https://lh7-us.googleusercontent.com/O91yj-d-P-EcWMZ9WamI353acJk5ciTQisUeLklHhoMD4oPaHBW0iX37NLjXtglqUefPgpbj-PWD8EDG_UcsVJxUpR2dOswu1IoEE6zy5mnW44Ng4DkJFsESwTOWf0xZx5L9eiwACUPOU-D6fH312fY)

##### APM RUM

"APM RUM" (Real User Monitoring) - Это подход, при котором данные о производительности собираются непосредственно от конечных пользователей приложения, обеспечивая вам информацию о том, как приложение воспринимается пользователями в реальном времени. Это делает APM RUM более надёжным инструментом чем расширение браузера Lighthouse, который только имитирует поведение пользователя. 

![](https://lh7-us.googleusercontent.com/jlkegUmNoR7iUlo3oek0UsDxbxJgV_OwJy4juHle52SkpPSgTnbALOyOWM_8QOuuP1u15HL43c8WRaC1PM9bzl4rdk9ct3XYGBSsUnKwuxo7rg4tzEOa23tOgejqUivGe1kDJIgCVVQg18Grcg4Uupk)