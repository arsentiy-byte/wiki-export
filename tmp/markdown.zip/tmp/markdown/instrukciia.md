# Книги > DevOps > Обновление приложения сайта wiki.rocketfirm.com > Инструкция

# Инструкция

#### Перед обновлением приложения, нужно подготовить бэкапы файлов и базы даных:

- Бэкап файлов можно сделать любым способом по желанию: в файловом менеджере плеска создать архив из этой директорий, просто создать копию директорий или сделать то же самое через терминал:  
    
    - Бэкап файлов через Plesk панель: 
        - - открываем [https://makers.kz:8443/ ](https://makers.kz:8443/)
            - открываем файловый менеджер
            - выбираем папку wiki.rocketfirm.com (ставим галочку)

[![image-1667371203320.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-11/scaled-1680-/image-1667371203320.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-11/image-1667371203320.png)

- - - - далее можем использовать кнопки Copy или Archive
    - Бэкап файлов через терминал сервера: 
        - открываем сервер : ssh makers
        - переключаемя в учетную запись Plesk панели : su - makers.kz
        - переходим в директорию /var/www/vhosts/makers.kz/ : cd /var/www/vhosts/makers.kz/
        - выполняем копирование файлов сайта : cp -r wiki.rocketfirm.com wiki.rocketfirm.com\_YYYY-MM-DD (вместо YYYY-MM-DD указать текущую дату )
- бэкап базы в Plesk в plesk: 
    - Открываем список баз данных в plesk (https://makers.kz:8443/smb/database/list/domainId/1?all=), находим базу wiki\_rocketfirm и нажимаем на кнопку “Export Dump”

[![image-1655113589546.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-06/scaled-1680-/image-1655113589546.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-06/image-1655113589546.png)

- С github скачиваем на сервер последнее доступное обновление в tar.gz или zip https://github.com/BookStackApp/BookStack/releases/tag/v22.04.2, затем в удобной для себя папке разархивируем его, например в /tmp/
- Открываем сервер : ssh makers
- Переключаемя в учетную запись Plesk панели : su - makers.kz
- Переходим в директорию /var/www/vhosts/makers.kz/ : cd /var/www/vhosts/makers.kz/
- Копируем обновления в папку сайта : *cp -r /tmp/BookStack-version/\* wiki.rocketfirm.com/ (BookStack-version/ - папка, которая была в скачанном архиве)*
- Переходим в обновленную директорию wiki.rocketfirm.com : cd  *wiki.rocketfirm.com/*
- Выполняем обновление зависимостей с помощью composer : */opt/plesk/php/7.4/bin/php /usr/local/psa/var/modules/composer/composer.phar install --ignore-platform-reqs*
- Выполняем миграции в базу данных : */opt/plesk/php/7.4/bin/php artisan migrate --force*
- Чистим кэш : */opt/plesk/php/7.4/bin/php artisan optimize:clear*