# Книги > Работа с HH > Документация по HH > Брендированные страницы работодателей

# Брендированные страницы работодателей

Чтобы попасть на страницу редактирования шаблонов, нужно нажать на ссылку "шаблоны страницы работодателя" на странице https://hh.ru/admin/employertemplate.mvc?employerId=&lt;id работодателя&gt;  
Шаблоны можно создавать без создания структуры (если она не требуется для чего-то ещё - например, департаментов или общего списка вакансий на странице), тогда они будут действовать только для этого работодателя. Для работодателя, который состоит в структуре, но не является главным, есть возможность иметь свои шаблоны страницы, такие шаблоны будут действовать вместо общих шаблонов, заведённых в структуре. Свои шаблоны доступны по ссылке "Частные шаблоны страницы работодателя"; а по ссылке "Общие шаблоны страницы работодателя", соответственно, открываются общие шаблоны структуры.  
По ширине должно умещаться без скрола в 320 пикселей (можно верстать «резиново» для больших значений ширины). На сайте минимальная ширина содержимого 320 пикселей, максимальная — 1250 пикселей, поэтому брендированные страницы работодателей должны адаптироваться под разную ширину. В hh используются следующие брейкпоинты:  
@page-min-width: 320px;  
   
@breakpoint-xs-end: (@breakpoint-s-start - 1px);  
@breakpoint-s-start: 700px;  
@breakpoint-s-end: (@breakpoint-m-start - 1px);  
@breakpoint-m-start: 1020px;  
@breakpoint-m-end: (@breakpoint-l-start - 1px);  
@breakpoint-l-start: 1340px;  
   
@screen-lt-s: ~"(max-width: @{breakpoint-xs-end})";  
@screen-gt-xs: ~"(min-width: @{breakpoint-s-start})";  
@screen-s: ~"(min-width: @{breakpoint-s-start}) and (max-width: @{breakpoint-s-end})";  
@screen-lt-m: ~"(max-width: @{breakpoint-s-end})";  
@screen-gt-s: ~"(min-width: @{breakpoint-m-start})";  
@screen-m: ~"(min-width: @{breakpoint-m-start}) and (max-width: @{breakpoint-m-end})";  
@screen-gt-m: ~"(min-width: @{breakpoint-l-start})";  
   
@resolution-2x: ~"only screen and (-webkit-min-device-pixel-ratio: 2), only screen and (min-resolution: 192dpi)";