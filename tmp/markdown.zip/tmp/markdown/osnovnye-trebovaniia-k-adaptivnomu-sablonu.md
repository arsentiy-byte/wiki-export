# Книги > Работа с HH > Документация по HH > Основные требования к адаптивному шаблону:

# Основные требования к адаптивному шаблону:

• Внутри тега контент не должен дублироваться. Т.е. нельзя просто объединить старые теги, и показывать их в зависимости от текущего размера страницы.   
• Если в шаблоне есть тег &lt;hht:adaptive&gt; - он появляется на странице безусловно, и старые теги можно удалить  
• Фиксированная ширина контейнера с брендированным содержимым - 690px. Включен padding со значением 20px 40px 40px, имеется внешняя тень  
• При ширине страницы меньше чем 700px - контейнер становится 100% по ширине, отключается внешняя тень, padding устанавливается в 0 на каждой стороне  
• По ширине должно тянуться на 100% ширины контейнера и умещаться без скрола в 300px.  
• Тег &lt;hht:adaptive&gt; должен содержать внутри себя в глубине &lt;hht:vacancy-description/&gt; — placeholder, в который будет вставлен текст описания вакансии.

Пример нового шаблона:  
Адаптивный шаблон  
&lt;hht:adaptive&gt;  
 &lt;style type="text/css"&gt;  
 .my-super-company {  
 font-size: 14px;  
 width: 100%;  
 }  
 @media (min-width: 700px) {  
 .my-super-company\_\_title {  
 font-size: 16px;  
 }  
 }  
 @media (min-width: 1020px) {  
 .my-super-company\_\_title {  
 font-size: 18px;  
 width: 50%;  
 }  
 }  
 @media (min-width: 1340px) {  
 .my-super-company\_\_title {  
 font-size: 20px;  
 }  
 }  
 &lt;/style&gt;  
   
 &lt;script&gt;  
 // foo  
 &lt;/script&gt;  
 &lt;div class="my-super-company"&gt;  
 &lt;div class="my-super-company\_\_title"&gt;My Super Company&lt;/div&gt;  
 &lt;hht:vacancy-description/&gt;  
 &lt;/div&gt;  
&lt;/hht:adaptive&gt;