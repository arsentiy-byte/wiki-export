# Книги > MacOS > JetBrains

# JetBrains

IDE для разработки ПО.

### Установка

Качаем что хотим:

- AppCode - [https://www.jetbrains.com/ru-ru/objc/](https://www.jetbrains.com/ru-ru/objc/)
- PyCharm - [https://www.jetbrains.com/ru-ru/pycharm/](https://www.jetbrains.com/ru-ru/pycharm/)
- DataGrip - [https://www.jetbrains.com/ru-ru/datagrip/](https://www.jetbrains.com/ru-ru/datagrip/)
- GoLand - [https://www.jetbrains.com/ru-ru/go/](https://www.jetbrains.com/ru-ru/go/)
- IntelliJ IDEA - [https://www.jetbrains.com/ru-ru/idea/](https://www.jetbrains.com/ru-ru/idea/)
- WebStorm - [https://www.jetbrains.com/ru-ru/webstorm/](https://www.jetbrains.com/ru-ru/webstorm/)
- PhpStorm - [https://www.jetbrains.com/ru-ru/phpstorm/](https://www.jetbrains.com/ru-ru/phpstorm/)

Не все IDE бесплатные, можно получить ключ [https://support.stepik.org/hc/ru/articles/360010105180-Как-получить-лицензионный-ключ-от-JetBrains-](https://support.stepik.org/hc/ru/articles/360010105180-%D0%9A%D0%B0%D0%BA-%D0%BF%D0%BE%D0%BB%D1%83%D1%87%D0%B8%D1%82%D1%8C-%D0%BB%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D0%BE%D0%BD%D0%BD%D1%8B%D0%B9-%D0%BA%D0%BB%D1%8E%D1%87-%D0%BE%D1%82-JetBrains-)