# Книги > Archived > Подключение к базам данных в СУБД Postgres через Админер

# Подключение к базам данных в СУБД Postgres через Админер

На тестовом сервере кocketfirm.tech развернут админер, доступный по адресу [https://adminer.rocketfirm.tech/](https://adminer.rocketfirm.tech/)

Данный админер позволяет подключаться к СУБД postgres на rocketfirm.tech, rocketfirm.digital и другим сайтам (смотреть доступы в [Bitwarden](https://pass.rocketfirm.com/))

В [Bitwarden](https://pass.rocketfirm.com/) есть хранилища Rocketfirm.tech и rocketfirm.digital. В этих хранилищах сохранены пароли и доступы к админской учетной записи СУБД тестовых серверов, которые позволяют полноценно работать с СУБД без ограничений по доступам.

На текущий момент доступы к тестовым такие:

Для удобства названия учетных записей и их пароли тестовых серверов одинаковые:   
**login:** rocketman

**password(без пробелов):** $p%55Do&amp;#ixV

**rocketfirm.digital:**

[![image-1665375289387.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/scaled-1680-/image-1665375289387.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/image-1665375289387.png)

**rocketfirm.tech:**

[![image-1665375331286.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/scaled-1680-/image-1665375331286.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/image-1665375331286.png)

Для примера, вот окно для подключения к тестовому серверу Астаны:

[![image-1665375491683.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/scaled-1680-/image-1665375491683.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/image-1665375491683.png)

А здесь окно для подключения к тестовому серверу Алматы:

[![image-1665375540764.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/scaled-1680-/image-1665375540764.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/image-1665375540764.png)