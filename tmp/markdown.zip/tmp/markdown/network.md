# Книги > QA > DevTools > Network

# Network

На вкладке сеть можно увидеть:

- запросы, которые отправляет клиент и ответы от сервера
- процесс загрузки страницы и всех файлов, которые подгружаются
- сводную информацию

[![__2021-04-30__12.05.16.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/scaled-1680-/2021-04-30-12-05-16.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/2021-04-30-12-05-16.png)