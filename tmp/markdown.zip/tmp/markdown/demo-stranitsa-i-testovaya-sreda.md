# Книги > Magnolia crm > User manual > Demo страница и тестовая среда

# Demo страница и тестовая среда

[![Снимок экрана 2022-02-25 в 11.58.07.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/snimok-ekrana-2022-02-25-v-11-58-07.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/snimok-ekrana-2022-02-25-v-11-58-07.png)

URL:[ https://d21ml0rfmtsd1k.cloudfront.net/magnolia-sanofi-demo ](https://d21ml0rfmtsd1k.cloudfront.net/magnolia-sanofi-demo%20 "https://d21ml0rfmtsd1k.cloudfront.net/magnolia-sanofi-demo ")

логин: sanofi  
пасс: sanofi  


**Magnolia Training Environment:** [https://training.crescendo.io/author/.magnolia/admincentral](https://training.crescendo.io/author/.magnolia/admincentral) 

- ccce1 = YxffwqZ6M55TPp8Y 
- ccce2 = SwqfkZ4n35gGcrPE 
- ccce3 = K4KXqrRUussnE877 
- ccce4 = CKzsXgf8aFWJwm6p 
- ccce5 = uJ4DzK46SABgsvZJ 
- ccce6 = FV4Gp3JcF5aMRfT9 
- ccce7 = g3PEPnTpF5yYgtXg 
- ccce8 = 5df3WrhJ9UjJxbnf 
- ccce9 = dzAyjH5Mt5XmKecJ 