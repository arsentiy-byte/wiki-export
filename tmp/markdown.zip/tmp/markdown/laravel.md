# Книги > Единый стандарт кода (PHP, Laravel) > Laravel

# Laravel

#### Принцип единственной ответственности (Single responsibility principle)  


Каждый класс должен иметь только одну обязанность.

```php
// Плохо
public function update(Request $request): string
{
    $validated = $request->validate([
        'title' => 'required|max:255',
        'events' => 'required|array:date,type'
    ]);

    foreach ($request->events as $event) {
        $date = $this->carbon->parse($event['date'])->toString();

        $this->logger->log('Update event ' . $date . ' :: ' . $);
    }

    $this->event->updateGeneralEvent($request->validated());

    return back();
}
```

```
// Хорошо
public function update(UpdateRequest $request): string
{
    $this->logService->logEvents($request->events);

    $this->event->updateGeneralEvent($request->validated());

    return back();
}
```

#### Методы должны делать что-то одно  


Функция должна делать что-то одно и делать это хорошо.

```php
// Плохо
public function getFullNameAttribute(): string
{
    if (auth()->user() && auth()->user()->hasRole('client') && auth()->user()->isVerified()) {
        return 'Mr. ' . $this->first_name . ' ' . $this->middle_name . ' ' . $this->last_name;
    } else {
        return $this->first_name[0] . '. ' . $this->last_name;
    }
}
```

```php
// Хорошо
public function getFullNameAttribute(): string
{
    return $this->isVerifiedClient() ? $this->getFullNameLong() : $this->getFullNameShort();
}

public function isVerifiedClient(): bool
{
    return auth()->user() && auth()->user()->hasRole('client') && auth()->user()->isVerified();
}

public function getFullNameLong(): string
{
    return sprintf('Mr. %s %s %s', $this->first_name, $this->middle_name, $this->last_name);
}

public function getFullNameShort(): string
{
    return sprintf('%s %s', $this->first_name, $this->last_name)
}
```

#### Тонкие контроллеры, тонкие модели, а логику в хендлеры

```php
// Плохо
public function index()
{
    $clients = Client::verified()
        ->with(['orders' => function ($q) {
            $q->where('created_at', '>', Carbon::today()->subWeek());
        }])
        ->get();

    return view('index', ['clients' => $clients]);
}
```

```php
// Плохо
public function index()
{
    return view('index', ['clients' => $this->client->getWithNewOrders()]);
}

class Client extends Model
{
    public function getWithNewOrders(): Collection
    {
        return $this->verified()
            ->with(['orders' => function ($q) {
                $q->where('created_at', '>', Carbon::today()->subWeek());
            }])
            ->get();
    }
}
```

```php
// Хорошо
public function index(IndexHandler $handler)
{
    return view('index', ['clients' => $handler->handle()]);
}

final class IndexHandler
{
    public function handle(): Collection
    {
        return Client::query()
            ->where('verified', true)
            ->with(['orders' => function ($q) {
                $q->where('created_at', '>', Carbon::today()->subWeek());
            }])
            ->get();
    }
}
```

#### Валидация

Следуя принципам тонкого контроллера и SRP, выносите валидацию из контроллера в Request классы.

```php
// Плохо
public function store(Request $request)
{
    $request->validate([
        'title' => 'required|unique:posts|max:255',
        'body' => 'required',
        'publish_at' => 'nullable|date',
    ]);

    ...
}
```

```php
// Хорошо
public function store(PostRequest $request)
{
    ...
}

class PostRequest extends Request
{
    public function rules(): array
    {
        return [
            'title' => 'required|unique:posts|max:255',
            'body' => 'required',
            'publish_at' => 'nullable|date',
        ];
    }
}
```

#### Бизнес логика в хендлерах.

Контроллер должен выполнять только свои прямые обязанности, поэтому выносите весь бизнес логику в отдельные классы и сервис классы.

```php
// Плохо
public function store(Request $request)
{
    if ($request->hasFile('image')) {
        $request->file('image')->move(public_path('images') . 'temp');
    }
    
    ...
}
```

```php
// Хорошо
public function store(Request $request, UploadArticleImageHandler $handler): JsonResponse
{
    $handler->handle($request->file('image'));

    ...
}

final class UploadArticleImageHandler
{
    public function handle(File $image): void
    {
        $image->move(public_path('images') . 'temp');
    }
}
```

#### Не повторяйся (DRY)

Этот принцип призывает вас переиспользовать код везде, где это возможно. Если вы следуете принципу SRP, вы уже избегаете повторений, но Laravel позволяет вам также переиспользовать представления, части Eloquent запросов и т.д.

```php
// Плохо
public function getActive()
{
    return $this->where('verified', 1)->whereNotNull('deleted_at')->get();
}

public function getArticles()
{
    return $this->whereHas('user', function ($q) {
            $q->where('verified', 1)->whereNotNull('deleted_at');
        })->get();
}
```

```php
// Хорошо
public function scopeActive($q)
{
    return $q->where('verified', true)->whereNotNull('deleted_at');
}

public function getActive(): Collection
{
    return $this->active()->get();
}

public function getArticles(): Collection
{
    return $this->whereHas('user', function ($q) {
            $q->active();
        })->get();
}
```

#### Предпочитайте Eloquent конструктору запросов (query builder) и сырым запросам в БД. Предпочитайте работу с коллекциями работе с массивами

Eloquent позволяет писать максимально читаемый код, а изменять функционал приложения несоизмеримо легче. У Eloquent также есть ряд удобных и мощных инструментов. Вам может быть интересен [справочник перевода Eloquent запросов в SQL](https://github.com/alexeymezenin/eloquent-sql-reference)

```sql
SELECT *
FROM `articles`
WHERE EXISTS (SELECT *
              FROM `users`
              WHERE `articles`.`user_id` = `users`.`id`
              AND EXISTS (SELECT *
                          FROM `profiles`
                          WHERE `profiles`.`user_id` = `users`.`id`) 
              AND `users`.`deleted_at` IS NULL)
AND `verified` = '1'
AND `active` = '1'
ORDER BY `created_at` DESC
```

```php
Article::query()->has('user.profile')->verified()->latest()->get();
```

#### Используйте массовое заполнение (mass assignment)  


```php
// Плохо
$article = new Article;
$article->title = $request->title;
$article->content = $request->content;
$article->verified = $request->verified;

// Привязать статью к категории.
$article->category_id = $category->id;
$article->save();
```

```php
// Хорошо
$article = Article::query()->create([
  'title' => $dto->title,
  'content' => $dto->content,
  'verified' => $dto->verified,
  'category_id' => $dto->categoryId,
]);
```

#### Не выполняйте запросы в представлениях и используйте нетерпеливую загрузку (проблема N + 1)  


```php
// Плохо (будет выполнен 101 запрос в БД для 100 пользователей):
@foreach (User::all() as $user)
    {{ $user->profile->name }}
@endforeach
```

```php
// Хорошо (будет выполнено 2 запроса в БД для 100 пользователей):
$users = User::with('profile')->get();

@foreach ($users as $user)
    {{ $user->profile->name }}
@endforeach
```

#### Используйте метод chunk при работе с большим количеством данных

```
// Плохо
$users = $this->get();

foreach ($users as $user) {
    ...
}
```

```php
// Хорошо
$this->chunk(500, function ($users) {
    foreach ($users as $user) {
        ...
    }
});
```

#### Предпочитайте читаемые имена переменных и методов комментариям

```php
// Плохо
// Determine if there are any joins
if (count((array) $builder->getQuery()->joins) > 0)
```

```php
// Хорошо
if ($this->hasJoins())
```

#### Конфиги, языковые файлы и константы вместо текста в коде  


Непосредственно в коде не должно быть никакого текста.

```php
// Плохо
public function isNormal()
{
    return $article->type === 'normal';
}

return back()->with('message', 'Ваша статья была успешно добавлена');
```

```php
// Хорошо
public function isNormal(): bool
{
    return $article->type === Article::TYPE_NORMAL;
}

return back()->with('message', __('app.article_added'));
```

#### Используйте инструменты и практики принятые сообществом  


Laravel имеет встроенные инструменты для решения часто встречаемых задач. Предпочитайте пользоваться ими использованию сторонних пакетов и инструментов. Laravel разработчику, пришедшему в проект после вас, придется изучать и работать с новым для него инструментом, со всеми вытекающими последствиями. Получить помощь от сообщества будет также гораздо труднее. Не заставляйте клиента или работодателя платить за ваши велосипеды.

ЗадачаСтандартные инструментНестандартные инструментАвторизацияПолитикиEntrust, Sentinel и др. пакеты, собственное решениеРабота с JS, CSS и пр.Laravel Mix, ViteGrunt, Gulp, сторонние пакетыСреда разработкиLaravel Sail, HomesteadDockerРазворачивание приложенийLaravel ForgeDeployer и многие другиеТестированиеPhpunit, MockeryPhpspec, Peste2e тестированиеLaravel DuskCodeceptionРабота с БДEloquentSQL, построитель запросов, DoctrineШаблоныBladeTwigРабота с даннымиКоллекции LaravelМассивыВалидация формRequest классыСторонние пакеты, валидация в контроллереАутентификацияВстроенный функционалСторонние пакеты, собственное решениеАутентификация APILaravel Passport, Laravel SanctumСторонние пакеты, использующие JWT, OAuthСоздание APIВстроенный функционалDingo API и другие пакетыРабота со структурой БДМиграцииРабота с БД напрямуюЛокализацияВстроенный функционалСторонние пакетыОбмен данными в реальном времениLaravel Echo, PusherПакеты и работа с веб сокетами напрямуюГенерация тестовых данныхSeeder классы, фабрики моделей, FakerРучное заполнение и пакетыПланирование задачПланировщик задач LaravelСкрипты и сторонние пакетыБДMySQL, PostgreSQL, SQLite, SQL ServerMongoDb

#### Соблюдайте соглашения сообщества об именовании  


Следуйте [стандартам PSR](https://www.php-fig.org/psr/psr-12/) при написании кода.

Также, соблюдайте другие cоглашения об именовании:

ЧтоПравилоПринятоНе принятоКонтроллеред. ч.ArticleControllerArticlesControllerМаршрутымн. ч.articles/1article/1Имена маршрутовsnake\_caseusers.show\_activeusers.show-active, show-active-usersМодельед. ч.UserUsersОтношения hasOne и belongsToед. ч.articleCommentarticleComments, article\_commentВсе остальные отношениямн. ч.articleCommentsarticleComment, article\_commentsТаблицамн. ч.article\_commentsarticle\_comment, articleCommentsPivot таблицаимена моделей в алфавитном порядке в ед. ч.article\_useruser\_article, articles\_usersСтолбец в таблицеsnake\_case без имени моделиmeta\_titleMetaTitle; article\_meta\_titleСвойство моделиsnake\_case$model-&gt;created\_at$model-&gt;createdAtВнешний ключимя модели ед. ч. и \_idarticle\_idArticleId, id\_article, articles\_idПервичный ключ-idcustom\_idМиграция-2017\_01\_01\_000000\_create\_articles\_table2017\_01\_01\_000000\_articlesМетодcamelCasegetAllget\_allМетод в контроллере ресурсов[таблица](https://laravel.com/docs/master/controllers#resource-controllers)storesaveArticleМетод в тестеcamelCasetestGuestCannotSeeArticletest\_guest\_cannot\_see\_articleПеременныеcamelCase$articlesWithAuthor$articles\_with\_authorКоллекцияописательное, мн. ч.$activeUsers = User::active()-&gt;get()$active, $dataОбъектописательное, ед. ч.$activeUser = User::active()-&gt;first()$users, $objИндексы в конфиге и языковых файлахsnake\_casearticles\_enabledArticlesEnabled; articles-enabledПредставлениеkebab-caseshow-filtered.blade.phpshowFiltered.blade.php, show\_filtered.blade.phpКонфигурационный файлsnake\_casegoogle\_calendar.phpgoogleCalendar.php, google-calendar.phpКонтракт (интерфейс)прилагательное или существительноеAuthenticationInterfaceAuthenticatable, IAuthenticationТрейтприлагательноеNotifiableNotificationTraitTrait [(PSR)](https://www.php-fig.org/bylaws/psr-naming-conventions/)adjectiveNotifiableTraitNotificationEnumединственное числоUserTypeUserTypes, UserTypeEnumFormRequestsingularUpdateUserRequestUpdateUserFormRequest, UserFormRequest, UserRequestSeedersingularUserSeederUsersSeeder

#### Приоритет соглашений над конфигурацией

Пока вы следуете принятым соглашениям, вам не нужно добавлять в код дополнительную конфигурацию.

```php
// Плохо

// Название таблицы 'Customer'
// Первичный ключ 'customer_id'
class Customer extends Model
{
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $table = 'Customer';
    protected $primaryKey = 'customer_id';

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'role_customer', 'customer_id', 'role_id');
    }
}
```

```php
// Хорошо

// Название таблицы 'customers'
// Первичный ключ 'id'
class Customer extends Model
{
    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class);
    }
}
```

#### Используйте IoC вместо new Class или фасадов  


Внедрение классов через синтаксис new Class создает сильное сопряжение между частями приложения и усложняет тестирование. Используйте контейнер.

```php
// Плохо
$user = new UserService();
$user->create($request->validated());
```

```php
// Хорошо

public function __construct(
  private UserService $userService
) {
}

...

$this->userService->create($request->validated());
```

#### Не работайте с данными из файла .env напрямую

Передайте данные из `.env` файла в кофигурационный файл и используйте `config()` в приложении, чтобы использовать эти данными.

```php
// Плохо

$apiKey = env('API_KEY');
```

```php
// Хорошо

// config/api.php
'key' => env('API_KEY'),

// Используйте данные в приложении
$apiKey = config('api.key');
```

#### Не используйте DocBlock

DocBlock ухудшают читаемость кода. Вместо них используйте хорошие имена для методов и современный синтаксис PHP, например описание возвращаемых типов (return type hints).

```php
// Плохо

/**
 * Функция проверяет есть ли в строке символы, которые остутствуют в ASCII.
 *
 * @param string $string Строка, которую мы получаем с фронтенда и которая
 *                       может содержать символы, не входящие в ASCII.
 *                       Возвращает True, если таких символов в строке нет.
 *
 * @return bool
 * @author  Василий Иванов
 *
 * @license GPL
 */

public function checkString($string)
{
}
```

```php
// Хорошо

public function isValidAsciiString(string $string): bool
{
}
```