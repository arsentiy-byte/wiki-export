# Книги > Frontend > Frontend developer grades > Middle 2 : M2

# Middle 2 : M2

Middle 2: M2 – имеет представления о бизнес-процессах связанные с проектом и цену стоящих перед ним задач. Может выступать как старший разработчик и влиять на выбор технологий для эффективного решения задачи. Умеет более точно оценивать сроки и сложности задач, и следить за качеством проекта. Умеет ввести команду, и помогать коллегам решать сложные задачи, подсказывать или менторить.

# Architecture

  
1. Что такое архитектура приложения? И чем она важна?
2. Что такое клиент-серверная архитектура? Какие у него плюсы и минусы?
3. Что такое JWToken?
4. Что такое MVC?
5. Чем отличается MVVM от MVC?
6. Какие архитектуры существуют для контроля потока данных?
7. Что такое сервис ориентированная архитектура?
8. Что такое микрофронтенд?

### Ресурсы

1. Высокоуровневая архитектура фронтенда – [https://youtu.be/mWeq5Kh6tlM](https://youtu.be/mWeq5Kh6tlM)
2. Архитектура фронтенда – [https://youtu.be/Sl9AcJZ6YpQ](https://youtu.be/Sl9AcJZ6YpQ)

---

# WebGL APPs

  
1. Что такое WebGL?
2. Какие возможности у WebGL?
3. Что такое шейдеры?
4. На каком языке программирования пишутся шейдеры?
5. Что такое Three.js?
6. Что такое post-proccessing?
7. Как рендерится WebGL приложение на веб-странице?
8. Что такое Pixi.js?
9. В чем отличие Pixi.js от Three.js?

### Ресурсы

1. Туториалы по WebGL анимациям – [https://tympanus.net/codrops/category/tutorials/](https://tympanus.net/codrops/category/tutorials/)
2. Документация Three.js – [https://threejs.org/docs/index.html#manual/en/introduction/Creating-a-scene](https://threejs.org/docs/index.html#manual/en/introduction/Creating-a-scene)
3. Документация Pixi.js – [https://www.pixijs.com/tutorials](https://www.pixijs.com/tutorials)

---

# Design Patterns

  
1. Чем полезен паттерн DI?
2. Назовите способы реализации DI?
3. Как работает паттерн IoC?
4. В каких ситуациях можно использовать паттерн Singleton?
5. Что такое CQRS?
6. В каких ситуациях используется паттерн Facade?
7. В каких ситуациях используется паттерн Фабричный метод?
8. Для чего используется паттерн Controller?