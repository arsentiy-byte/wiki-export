# Книги > Загрузка презентаций nestle в систему veeva > Добавление слайдов в презентацию

# Добавление слайдов в презентацию

Найдите вашу презентацию в системе и зайдите в нее. После этого что б добавить наши слайды нажимаем на New CLM Presentation Slide в разделе CLM Presentation slides (Есть две кнопки, не путайте их)

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-05/scaled-1680-/9lDimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-05/9lDimage.png)

Появляется форма из 4ех полей, одна из которых уже заполнена. Ее нельзя менять.   
**Что заполнить в оставшихся:**   
**1.** Key Message – Написать название слайда слайда которое мы хотим добавить (не зря мы делали id, describe, name одинаковым. В самом имени слайда уже есть уникальный код, так что таким образом можно избежать с повторением id)  
**2.** Display Order – пишем на каком месте стоит наш слайд в презентации (порядок слайдов должен быть согласован с менеджером)  
**3.** External ID – пишем тоже самое что и в Key Message

После нажимаем Save или же Save &amp; New если нужно добавить еще слайдов

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-05/scaled-1680-/tvfimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-05/tvfimage.png)

В интерфейсе нашей презентации показывается какие слайды были добавлены (по желанию их можно редактировать или удалить)

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-05/scaled-1680-/ceximage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-05/ceximage.png)