# Книги > Archived > Деплой проекта nuxt+laravel в VIrtualBox

# Деплой проекта nuxt+laravel в VIrtualBox

В этой статье описаны действия, необходимые для развертывания проекта проекта nuxt+laravel на локальной виртуальной машине Ubuntu 20.04 на компьютере с MacOS или Windows.

### **Предварительная настройка**

#### В hosts файл на компьютере добавляем следующее(*macos/linux - /etc/hosts, windows - C:\\Windows\\System32\\drivers\\etc\\hosts ) ***(! ! ! Заменить iclinic названием своего проекта)*** :

127.0.0.1 backend.iclinic.local

#### На фронтенде этот домен указан в docker-compose.yml файле в поле extra\_hosts:

[![image-1664450614197.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1664450614197.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1664450614197.png)

172.17.0.1 - это айпи виртуальной машины, который доступен для обращений изнутри контейнеров(можно посмотреть с помощью команды “ip a | grep docker”)

[![image-1664450637725.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1664450637725.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1664450637725.png)

### **Установка docker и docker-compose:**

#### - Подключаемся к ВМ по ssh

&gt;&gt; ssh rocketman@localhost -p 9111

#### - Выполняем установку docker

*&gt;&gt; sudo apt-get remove docker docker-engine docker.io containerd runc || echo OK*

*&gt;&gt; sudo apt update &amp;&amp; sudo apt install -y ca-certificates curl gnupg lsb-release*

*&gt;&gt; sudo mkdir -p /etc/apt/keyrings*

*&gt;&gt; curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg*

*&gt;&gt; echo "deb \[arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg\] [*https://download.docker.com/linux/ubuntu*](https://download.docker.com/linux/ubuntu) $(lsb\_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list &gt; /dev/null*

*&gt;&gt; sudo apt-get update*

*&gt;&gt;  sudo apt-get -y install docker-ce docker-ce-cli containerd.io docker-compose-plugin*

*&gt;&gt; sudo wget https://github.com/docker/compose/releases/download/1.29.2/docker-compose-Linux-x86\_64 -O /usr/bin/docker-compose*

*&gt;&gt; sudo chmod +x /usr/bin/docker-compose*

#### Для работы с докером от учетной записи rocketman, необходимо учетную запись rocketman добавить в группу docker и переподключиться к серверу:

*&gt;&gt; sudo usermod -aG docker rocketman*

*&gt;&gt; exit*

*&gt;&gt; ssh rocketman@localhost -p 9111*

## **Клонирование репозиториев проекта на виртуальную машину:**

#### Для клонирования репозиториев на ВМ нужно:

#### *- Подключиться к серверу*

*&gt;&gt; ssh rocketman@localhost -p 9111*

#### - Установить пакет git

*&gt;&gt; sudo apt install -y git*

#### - Сгенерировать ключ и добавить его в гитлаб

&gt;&gt; ssh-keygen

&gt;&gt; cat ~/.ssh/id\_rsa.pub - вывод этой команыд нужно добавить в gitlab ssh-public-keys (*https://gitlab.com/-/profile/keys*)

#### - Создать и перейти в директорию /var/www/vhosts

&gt;&gt; sudo mkdir /var/www/vhosts -p &amp;&amp; sudo chown -R rocketman: /var/www/vhosts &amp;&amp; cd /var/www/vhosts

#### - Выполнить клонировение фронтенда и бэкенда***(! ! ! Заменить URL'ы на URL'ы репозиториев проекта)***


&gt;&gt; git clone -b develop git@gitlab.com:iclinic2/iclinic-back.git

&gt;&gt; git clone -b develop git@gitlab.com:iclinic2/iclinic-front.git

### **Запуск бэкенда**

#### На сервере запущен nginx для теста, его нужно остановить командой

*&gt;&gt; sudo systemctl disable --now nginx*

#### Далее разворачиваем бэкенд

*&gt;&gt; sudo apt install -y make*

*&gt;&gt; cd /var/www/vhosts/iclinic-back* ***(! ! ! Заменить **iclinic названием своего проекта**)***

*&gt;&gt; cp .env.example .env*

*&gt;&gt; make install*

### **Запуск фронтенда**

#### В нашем случае, когда на одной вирткалке у нас развернут и бэкенд, и фронтенд, необходимо увеличить ОЗУ примерно до 2Гб

#### Для этого:

\- открываем VirtualBox

\- выбираем нашу виртуальную машину

\- останавливаем ее

\- открываем настройки

\- переходим во вкладку System и указываем размер ОЗУ

#### Далее выполняем на терминале виртуальной машины:

*&gt;&gt; cd /var/www/vhosts/iclinic-front**(! ! ! Заменить iclinic названием своего проекта)***

#### в файл .env добавить строку***(! ! ! Заменить **iclinic названием своего проекта**)***:

baseUrl=http://backend.iclinic.local/api/v1

*&gt;&gt; echo "baseUrl=http://backend.iclinic.local/api/v1" &gt; .env*

*&gt;&gt; docker-compose build --no-cache &amp;&amp; docker-compose up -d*

### **Далее нужно настроить проброс портов на VirtualBox**

#### Для этого:

\- открываем VirtualBox

\- выбираем нашу виртуальную машину

\- переходим во вкладку Network

\- раскрываем галочку Advanced

\- нажимаем на кнопку Port Forwarding

\- добавляем порт для фронтенда

[![image-1664450671875.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1664450671875.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1664450671875.png)

Адрес админки [http://backend.iclinic.local](http://localhost/admin/login)/admin***(! ! ! Заменить **iclinic названием своего проекта**)*** или [http://localhost/admin](http://localhost/admin)

Адрес фронтенда [http://localhost:30003/](http://localhost:30003/)

Вот и конец. Мы развернули проект rocket-hybrid + laravel на локальной виртуальной машине. Отличие от отдельного развертывания только фронтенда или только бэкенда в том, что тут они корректно взаимодействую между собой и можно тестировать всю работу сайта в целом у себя на компьютере.