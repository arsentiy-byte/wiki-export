# Книги > Единый стандарт кода (PHP, Laravel) > Интеграция с внешними сервисами

# Интеграция с внешними сервисами

Пошаговая инструкция по интеграции с внешними сервисами.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/Bnqimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/Bnqimage.png)

**В примере показано интеграция с Jira:**

##### Предварительный шаг. Создание конфиг файла

Создаем файл в директории `config/jira.php`

```php
 env('JIRA_HOST', 'https://jira.example.com'),
    'timeout' => env('JIRA_TIMEOUT', 5),
    'username' => env('JIRA_USERNAME'),
    'password' => env('JIRA_PASSWORD'),
];

```

##### Первый шаг. Создание базового класса Response

Создаем класс в директории `app/Services/Api/Response.php`

```php
response->failed();
    }

    public function isSuccess(): bool
    {
        return $this->response->successful();
    }

    public function getStatus(): int
    {
        return $this->response->status();
    }

    public function getReason(): string
    {
        return $this->response->reason();
    }

    /**
     * @return array
     */
    public function getBody(): array
    {
        return $this->response->json();
    }

    /**
     * @throws RequestException
     */
    public function throw(): void
    {
        $this->response->throw();
    }

    protected function body(string $key, mixed $default = null): mixed
    {
        return $this->response->json($key, $default);
    }

    protected function header(string $header): string
    {
        return $this->response->header($header);
    }
}

```

##### Второй шаг. Создание базового класса Client

Создаем класс в директории `app/Services/Api/Client.php`

```php
http = Http::timeout($this->timeout);
    }

    public function withToken(string $token): void
    {
        $this->http->withToken($token);
    }

    public function withBasicAuth(string $username, string $password): void
    {
        $this->http->withBasicAuth($username, $password);
    }

    /**
     * @param array $query
     * @throws ConnectionException
     */
    public function get(string $uri, array $query = []): PromiseInterface|Response
    {
        return $this->http->get($this->getUri($uri), $query);
    }

    /**
     * @param array $payload
     * @param array $query
     * @throws ConnectionException
     */
    public function post(string $uri, array $payload = [], array $query = []): PromiseInterface|Response
    {
        return $this->http->post(URL::query($this->getUri($uri), $query), $payload);
    }

    /**
     * @param array $payload
     * @param array $query
     * @throws ConnectionException
     */
    public function put(string $uri, array $payload = [], array $query = []): PromiseInterface|Response
    {
        return $this->http->put(URL::query($this->getUri($uri), $query), $payload);
    }

    /**
     * @param array $payload
     * @param array $query
     * @throws ConnectionException
     */
    public function delete(string $uri, array $payload = [], array $query = []): PromiseInterface|Response
    {
        return $this->http->delete(URL::query($this->getUri($uri), $query), $payload);
    }

    private function getUri(string $uri): string
    {
        return sprintf('%s%s', $this->host, $uri);
    }
}

```

##### Третий шаг. Создание класса для конфига Config

Создаем класс в директории `app/Services/Api/Jira/Config.php`

```php
http->withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ]);
    }

    public function withAuthCookie(string $cookie): void
    {
        $this->http->withHeader('Cookie', $cookie);
    }
}

```

##### Пятый шаг. Создание классов сущностей Entities

Создаем классы в директории `app/Services/Api/Jira/Entities`

```php
worklogs;
    }

    public function setWorklogs(?WorklogCollection $worklogs): void
    {
        $this->worklogs = $worklogs;
    }
}

```

```php
fields?->assignee?->displayName,
            $issue->fields?->assignee?->emailAddress,
            $issue->fields?->status?->name,
            $issue->fields?->project?->key,
            $issue->fields?->project?->name,
        );
    }
}

```

```php
fields?->assignee?->displayName,
            $issue->fields?->assignee?->emailAddress,
            $issue->fields?->status?->name,
            $issue->fields?->priority?->id,
            $issue->fields?->project?->key,
            $issue->fields?->project?->name,
            $issue->key,
            $issue->fields?->summary,
        );
    }
}

```

```php
fields?->assignee?->displayName,
            $issue->fields?->assignee?->emailAddress,
            $issue->fields?->status?->name,
            $issue->fields?->priority?->id,
            $issue->fields?->project?->key,
            $issue->fields?->project?->name,
            $issue->key,
            $issue->fields?->summary,
            $issue->getWorklogs()?->sumTimeSpentSeconds(),
        );
    }

    public function formatTimeSpentSeconds(): string
    {
        if (null === $this->timeSpentSeconds) {
            return '0m';
        }

        $hours = floor($this->timeSpentSeconds / 3600);
        $minutes = floor(($this->timeSpentSeconds % 3600) / 60);

        return sprintf('%dh %dm', $hours, $minutes);
    }
}

```

##### Седьмой шаг. Создание классов коллекции Collections

Создаем классы в директории `app/Services/Api/Jira/Collections`

```php
|IssueCollection $items
     */
    public static function make($items = []): self
    {
        $self = new self();

        foreach ($items as $item) {
            $self->add(DeveloperReportVO::fromEntity($item));
        }

        return $self;
    }

    public static function fromIssueCollection(IssueCollection $collection): self
    {
        return self::make($collection);
    }

    /**
     * @param DeveloperReportVO $item
     */
    public function add($item): self
    {
        if ( ! $item instanceof DeveloperReportVO) {
            throw new RuntimeException(sprintf('Item must be an instance of %s', DeveloperReportVO::class));
        }

        return parent::add($item);
    }
}

```

```php
 $items
     */
    public static function make($items = []): self
    {
        $self = new self();

        foreach ($items as $item) {
            $self->add(Issue::fromArray($item));
        }

        return $self;
    }

    /**
     * @param Issue $item
     */
    public function add($item): self
    {
        if ( ! $item instanceof Issue) {
            throw new RuntimeException(sprintf('Item must be an instance of %s', Issue::class));
        }

        return parent::add($item);
    }
}

```

```php
|IssueCollection $items
     */
    public static function make($items = []): self
    {
        $self = new self();

        foreach ($items as $item) {
            $self->add(WorkflowVO::fromEntity($item));
        }

        return $self;
    }

    public static function fromIssueCollection(IssueCollection $collection): self
    {
        return self::make($collection);
    }

    /**
     * @param WorkflowVO $item
     */
    public function add($item): self
    {
        if ( ! $item instanceof WorkflowVO) {
            throw new RuntimeException(sprintf('Item must be an instance of %s', WorkflowVO::class));
        }

        return parent::add($item);
    }
}

```

```php
 $items
     */
    public static function make($items = []): self
    {
        $self = new self();

        foreach ($items as $item) {
            $self->add(Worklog::fromArray($item));
        }

        return $self;
    }

    /**
     * @param Worklog $item
     */
    public function add($item): self
    {
        if ( ! $item instanceof Worklog) {
            throw new RuntimeException(sprintf('Item must be an instance of %s', Worklog::class));
        }

        return parent::add($item);
    }

    public function onlyToday(): self
    {
        return $this->filter(fn (Worklog $worklog) => $worklog->created?->isToday() ?? false);
    }

    public function sumTimeSpentSeconds(): int
    {
        return $this->sum(fn (Worklog $worklog) => $worklog->timeSpentSeconds ?? 0);
    }
}

```

```php
|IssueCollection $items
     */
    public static function make($items = []): self
    {
        $self = new self();

        foreach ($items as $item) {
            $self->add(WorktimeVO::fromEntity($item));
        }

        return $self;
    }

    public static function fromIssueCollection(IssueCollection $collection): self
    {
        return self::make($collection);
    }

    /**
     * @param WorktimeVO $item
     */
    public function add($item): self
    {
        if ( ! $item instanceof WorktimeVO) {
            throw new RuntimeException(sprintf('Item must be an instance of %s', WorktimeVO::class));
        }

        return parent::add($item);
    }

    public function sumTimeSpentSeconds(): int
    {
        return $this->sum(fn (WorktimeVO $item) => $item->timeSpentSeconds ?? 0);
    }
}

```

##### Седьмой шаг. Создание классов запросов Requests

Создаем классы в директории `app/Services/Api/Jira/Requests`

```php
}
     */
    public function query(): array
    {
        return [
            'jql' => $this->jql,
            'startAt' => $this->startAt,
            'maxResults' => $this->maxResults,
            'fields' => $this->fields,
        ];
    }
}

```

##### Восьмой шаг. Создание классов ответов Responses

Создаем классы в директории `app/Services/Api/Jira/Responses`

```php
isFailed()) {
            return null;
        }

        $cookies = $this->header('Set-Cookie');

        foreach (explode(',', $cookies) as $cookie) {
            if (Str::contains($cookie, 'JSESSIONID')) {
                return Str::trim($cookie);
            }
        }

        return null;
    }
}

```

```php
isFailed()) {
            return null;
        }

        return IssueCollection::make($this->body('issues', []));
    }

    public function getExpand(): ?string
    {
        return $this->body('expand');
    }

    public function getStartAt(): ?int
    {
        if ($this->isFailed()) {
            return null;
        }

        $startAt = $this->body('startAt');

        return null !== $startAt ? (int)$startAt : null;
    }

    public function getMaxResults(): ?int
    {
        if ($this->isFailed()) {
            return null;
        }

        $maxResults = $this->body('maxResults');

        return null !== $maxResults ? (int)$maxResults : null;
    }

    public function getTotal(): ?int
    {
        if ($this->isFailed()) {
            return null;
        }

        $total = $this->body('total');

        return null !== $total ? (int)$total : null;
    }
}

```

```php
isFailed()) {
            return null;
        }

        $startAt = $this->body('startAt');

        return null !== $startAt ? (int)$startAt : null;
    }

    public function getMaxResults(): ?int
    {
        if ($this->isFailed()) {
            return null;
        }

        $maxResults = $this->body('maxResults');

        return null !== $maxResults ? (int)$maxResults : null;
    }

    public function getTotal(): ?int
    {
        if ($this->isFailed()) {
            return null;
        }

        $total = $this->body('total');

        return null !== $total ? (int)$total : null;
    }

    public function getWorklogs(): ?WorklogCollection
    {
        if ($this->isFailed()) {
            return null;
        }

        /** @var array|null $worklogs */
        $worklogs = $this->body('worklogs');

        return null !== $worklogs ? WorklogCollection::make($worklogs) : null;
    }
}

```

##### Девятый шаг. Создание классов ендпойнтов Endpoints

Создаем классы в директории `app/Services/Api/Jira/Endpoints`

```php
client->post('/rest/auth/1/session', [
            'username' => $request->username,
            'password' => $request->password,
        ]);

        return new LoginResponse($response);
    }
}

```

```php
client->get('/rest/api/2/search', $request->query());

        return new SearchResponse($response);
    }

    /**
     * @throws ConnectionException
     */
    public function worklog(int $issueId): WorklogResponse
    {
        $response = $this->client->get(sprintf('/rest/api/2/issue/%s/worklog', $issueId));

        return new WorklogResponse($response);
    }
}

```

##### Десятый шаг. Создание интерфейса контракта для реализации сервиса ServiceContract 

Создаем класс в директории `app/Services/Api/Jira/Contracts/ServiceContract.php`

```php

     */
    private array $endpoints = [];

    public function __construct(
        private readonly Config $config,
    ) {
        $this->client = new Client($this->config->host, $this->config->timout);
    }

    public function authenticate(): void
    {
        try {
            $response = $this->getAuthEndpoint()
                ->login(
                    new LoginRequest(
                        $this->config->username,
                        $this->config->password,
                    )
                );

            $response->throw();

            $this->client->withAuthCookie($response->getAuthCookie());
        } catch (ConnectionException $exception) {
            throw new RuntimeException(
                sprintf(
                    'Unable to connect to Jira with host %s: %s',
                    $this->config->host,
                    $exception->getMessage()
                ),
                Response::HTTP_INTERNAL_SERVER_ERROR,
                $exception,
            );
        } catch (RequestException $exception) {
            throw new RuntimeException(
                sprintf(
                    'Unable to authenticate to Jira with host %s: %s',
                    $this->config->host,
                    $exception->getMessage()
                ),
                $exception->getCode(),
                $exception,
            );
        }
    }

    public function getAuthEndpoint(): AuthEndpoint
    {
        return $this->getEndpoint(AuthEndpoint::class);
    }

    public function getIssueEndpoint(): IssueEndpoint
    {
        return $this->getEndpoint(IssueEndpoint::class);
    }

    /**
     * @param class-string $name
     */
    private function getEndpoint(string $name): mixed
    {
        if ( ! Arr::exists($this->endpoints, $name)) {
            Arr::set($this->endpoints, $name, new $name($this->client));
        }

        return Arr::get($this->endpoints, $name);
    }
}

```

##### Двенадцатый шаг. Создание сервис провайдера ServiceProvider

Создаем класс в директории `app/Services/Api/Jira/Providers/ServiceProvider.php`

```php
app->singleton(ServiceContract::class, function () use ($config): ServiceContract {
            $service = new Service($config);

            $service->authenticate();

            return $service;
        });
    }
}

```

##### Тринадцатый шаг. Регистрация сервис провайдера в проекте

Добавляем сервис провайдер класс в файл `bootstrap/providers.php`

```
make(ServiceContract::class);

/** @var SearchResponse $response */
$response = $service
    ->getIssueEndpoint()
    ->search(new SearchRequest(
        'PROJECT = DT',
        0,
        10,
        ['key', 'summary'],
    ));

/** @var IssueCollection|null $issues */
$issues = $response->getIssues();

```