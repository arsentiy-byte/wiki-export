# Книги > QA > Автоматизация тестирования > Настройка Docker локально для последующего включения автотестов в CI/CD

# Настройка Docker локально для последующего включения автотестов в CI/CD

Чтобы включить наши автотесты в сценарий пайплайна CI/CD необходимо вначале настроить запуск тестов docker-контейнере локально

Вначале необходимо [установить](https://www.docker.com/products/docker-desktop/) Docker и Docker Compose.

Может понадобится запустить 1 раз Docker после установки чтобы следующий шаг успешно отработал.

Проверяем что у нас установлены и доступные Docker и Docker Compose:

```
docker --version
```

```
docker-compose --version
```

Затем добавляем или актуализируем сожержание следуюших файлов в проекте:

##### **docker-compose.test.yml**

```
version: '3'

services:
  test:
    container_name: [project-name]-test
    build:
      context: .
      dockerfile: DockerfileTest
    environment:
      - COMPOSE_HTTP_TIMEOUT=300
    volumes:
      - .:/usr/src/app
      - /usr/src/app/node_modules
      - /usr/src/app/.output
```

##### **DockerfileTest**

```
FROM node:16-alpine
FROM mcr.microsoft.com/playwright:v1.34.3-focal

WORKDIR /usr/src/app

RUN apt-get update && apt-get -y install libnss3 libatk-bridge2.0-0 libdrm-dev libxkbcommon-dev libgbm-dev libasound-dev libatspi2.0-0 libxshmfence-dev

COPY ./.env.example ./.env

COPY . .
RUN yarn install --frozen-lockfile // флаг "--frozen-lockfile" необязательна и чаще всего требуется её убрать
ENV PATH /usr/src/app/node_modules/.bin:$PATH
RUN yarn build

ENV NUXT_HOST=0.0.0.0
ENV NUXT_PORT=3000

# RUN yarn test

CMD ["yarn", "test"]

```

**Примечание #1:**

Строка:

```
FROM mcr.microsoft.com/playwright:v1.34.3-focal
```

Содержит информацию о docker-контейнере собранном разработчиками фреймворка playwright. Необходимо учитывать что каждый из таких контейнеров в зависимости от версии фреймворка playwright поддерживает определённый диапазон версий node, что надо учитывать и проверять экспериментально.

Например для такой версии Docker-файла:

```
FROM node:16-alpine
FROM mcr.microsoft.com/playwright:v1.41.1-focal
...
```

Контейнер не собрётся по причине того что контейнер предоставляемый разработчиками для актуальной версия playwright 1.41.1 работает с версиями node от 20 и выше, но в примере мы указываем 16 версию.

История релизов версий Playwright в том числе с указанием когда была внедрена поддержка какой версии node можно посмотреть по [ссылке](https://playwright.dev/docs/release-notes)

Ознакомиться с содержимым последнего актуального Dockerfile для Playwright можно по [ссылке](https://github.com/microsoft/playwright/blob/main/utils/docker/Dockerfile.jammy)

С названиями всех контейнеров (к сожалению без подробного указания содержимого) можно по [ссылке ](https://mcr.microsoft.com/en-us/product/playwright/tags)

**Таблица с примером допустимых значенияй сочетаний весрий контейнеров и версий node:**

Docker-контейнерСовместимая версия node`mcr.microsoft.com/playwright:v1.34.3-focal``16-alpine``mcr.microsoft.com/playwright:v1.35.1-jammy``node:16-alpine и node:18-alpine`mcr.microsoft.com/playwright:v1.42.0-jammyFROM node:20-bookworm

С рекомендуемыми для последней актуальной версии playwright версиями node можно ознакомиться по [ссылке](https://playwright.dev/docs/docker)

**Примечание #2:**

В docker-файлах рекомендуется для имени проекта использовать переменную из env путём указания таким образом:

```
${APP_NAME}_tests
```

##### **playwright.config.ts**

```
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { PlaywrightTestConfig } from '@playwright/test'

const config: PlaywrightTestConfig = {
  webServer: {
    command: 'yarn serve:prod',
    port: 3000,
    timeout: 120 * 100000,
    reuseExistingServer: undefined,
  },
  reporter: [['html', { outputFolder: 'playwright-report', open: 'never' }]],
}

export default config

```

##### **package.json**

в раздел "scripts"

для проверки и обновления версии playwright:

```
"update-playwright": "npm outdated playwright && npm update playwright"
```

для запуска тестов одним воркером на chromium:

```
"test": "npx playwright test --browser=chromium --workers=1 --output=playwright-report", 
```

##### **Запуск**

тогда для запуска тестов в вашем проекте (и в контейнере) вы сможете запускать тесты не командой вида

```
npx playwright test
```

а просто:

```
yarn test
```

Все эти файлы необходимо создать и сохранить, запустить docker кликом по иконке desktop приложения или выполним команду в консоле:

```
docker
```

затем выполнить в терминале проекта команду для запуска docker-контейнера:

```
docker-compose -f docker-compose.test.yml up --force-recreate --build -d
```

После этого должен подняться docker-контейнер, в терминале которого можно запустить проект и автотесты:

```
yarn build && yarn test 
```

Если контейнер поднимается без ошибок и тесты внутри него исправно работают - можно пушить изменения перечисленных файлов в ветку develop и приглашать коллег devops для дальнейшей настройки пайплайна с автотестами на проекте.

В результате чего при каждом мердже в develop будут:

- будет поднимать контейнер в котором будет разворачиваться проект,
- в этом контейнере запускаться автотесты
- мердж будет принимать только если все тесты прошли успешно.