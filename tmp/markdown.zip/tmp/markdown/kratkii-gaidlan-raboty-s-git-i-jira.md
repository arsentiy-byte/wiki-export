# Книги > Archived > Краткий гайдлан работы с Git и Jira

# Краткий гайдлан работы с Git и Jira

[Jira](https://jira.rocketfirm.com/secure/Dashboard.jspa) - наш замечательный таск менеджер. Если у Вас нет доступа к нему, обратитесь к руководству.

К каждому проекту, заводится отдельная доска в jira.

В первую очередь, убедитесь какие задачи у Вас есть на текущий момент. Для этого зайдите в панель Kanban, и для удобства включите фильтр "Только мои задачи"

[![image-1634552712428.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634552712428.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634552712428.png)

Ознакомитесь с задачей кликнув по ней. После приступайте к работе и не забудьте перетащить карточку в нужную колонку, затем поставить таймер на ней.

[![image-1634552927917.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634552927917.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634552927917.png)

Далее идем в наш Gitlab, находим наш репозиторий, создаем отдельную ветку. *(для доступа к гитлабу, необходимо запросить доступ у тимлида или техлида)*

[![image-1634553166523.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634553166523.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634553166523.png)

Именуем ветку следующим образом:

[![image-1634553280405.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634553280405.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634553280405.png)

разберем название ветки feature-RSHP-54

первое слово feature - это добавление нового функционала, если мы исправляем баг, то изменим название на fix-RSHP-54.

второе слово RSHP-54, должен полностью соответствовать номеру карточки в джира

[![image-1634553471266.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634553471266.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634553471266.png)

Можно конечно упростить, и называть ветки просто номером карточки RSHP-54. Такой вариант тоже допустим.

Ветку мы создали, теперь можно начинать кодить.

*(Создать ветку можно также через терминал или GUI наподобие [Github Desktop](https://desktop.github.com/), что очень рекомендую)*

После того как закончим, отправляем **Merge Request**, и назначаем ответственного за слияние *(ведущего разработчика, или тимлида. И да, не забудьте остановить таймер в карточке jira, и переместить ее в актуальное место).*

[![image-1634555409809.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634555409809.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634555409809.png)

Напоследок, предупреждаем нашего ответственного (желательно в телеграм), и просим его ознакомится с нашем кодом.

Как только он сделает "код ревью", он либо пропустит МР, и мы работаем дальше, либо попросит переделать что нибудь в коде. Если замечания присутствуют, исправляем их и коммитим в нашу же текущую ветку.

*(Как только выполните свою работу, поставьте галочку там где у вас есть замечания)*

[![image-1634555823338.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634555823338.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634555823338.png)

Вот и все, как видите ничего сложного.

---

Теперь разберем работу в наших внутренних проектов (собственные шаблоны, фреймворки и библиотеки). Каждый разработчик может внести свою лепту в эти проекты, ничем не ограничиваясь. Это похоже на open source, только без fork или pull requests. Поэтому если есть желание стать контрибьютором, то мы только рады :)

Доска Jira тут отстуствует, поэтому используем возможности Gitlab.

По порядку:

1\) Заходим на страницу репозитория

2\) Открываем обсуждения (Issues), и выбираем проблему над которой хотим поработать

[![image-1634556989194.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634556989194.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634556989194.png)

2.1) Если интересующей проблемы нету, то можем создать свою :) Нажимаем кнопку на "Новое обсуждение".

[![image-1634557306615.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634557306615.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634557306615.png)

3\) Теперь выбираем Issue и создаем на ее основе ветку

[![image-1634557401299.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1634557401299.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1634557401299.png)

4\) Исправляем наше проблему, и как обычно делаем MR. Назначаем ответственного, и вуаля. Вы только что внесли огромный вклад в нашу компанию :3 И возможно в будущем, станете главным контрибьютором в крупных open source!

Спасибо за внимание!