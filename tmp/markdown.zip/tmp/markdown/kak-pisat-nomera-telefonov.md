# Книги > Как писать номера телефонов > Как писать номера телефонов

# Как писать номера телефонов

### Городские

#### Историческая ошибка

На постсоветском пространстве часто встречается подобный формат городского номера:

```
+7 (727) 123-45-67

```

Этот формат — результат тиражирования ошибки. Скобки считаются признаком местного номера, когда код набирать не требуется. Если, следуя здравому смыслу, убрать из номера необязательные цифры, получим:

```
+7 123-45-67

```

Вряд ли по такому номеру получится позвонить.

#### Как правильно

Википедия, в разделе о телефонных номерах, пишет о России: Thus, the correct way to write local number is, e.g., 8 AAAA BB-BB-BB or (8 AAAA) BB-BB-BB to indicate that area code dialing is optional. In current usage, *it is very common to see numbers (incorrectly) written as 8 (AAA) BBB-BB-BB*. This usage is wrong, as the parentheses are meant to indicate the part of number that may be omitted.

О Британии: Numbers for mobile phones and pagers are formatted as 07AAA BBBBBB and most other non-geographic numbers are 10 figures in length (excluding trunk digit '0') and formatted as 0AAA BBB BBBB.

О Штатах: The traditional formatting convention included the area code in parenthesis to indicate that dialing the area code for local calls was optional. Calling a number in a different area code required dialing that code first (i.e., NPA-NXX-XXXX) known as 10-digit dialing.

Как видно, в большой части мира скобки — признак локального номера телефона.

**Правильное написание** городского номера телефона вот такое:

```
(+7 727) 123-45-67

```

**Альтернативный вариант** — вовсе без скобок:

```
+7 727 123-45-67

```

Люди самостоятельно смогут отделить код оператора от номера телефона и решить самостоятельно, как набирать: с кодом или без.

### Мобильные

У мобильных телефонов в СНГ единственный верный формат:

```
+7 777 123-45-67
```