# Книги > Менеджерский > Для менеджеров (бонусы, KPI и грейды) > Базовый регламент

# Базовый регламент

[![Слайд1.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/slaid1.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/slaid1.jpeg)

[![Слайд2.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/QEfslaid2.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/QEfslaid2.jpeg)

[![Слайд3.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/41Nslaid3.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/41Nslaid3.jpeg)

[![Слайд4.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/qtCslaid4.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/qtCslaid4.jpeg)

[![Слайд5.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/Gcfslaid5.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/Gcfslaid5.jpeg)

[![Слайд6.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/RQQslaid6.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/RQQslaid6.jpeg)

[![Слайд7.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/iILslaid7.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/iILslaid7.jpeg)

[![Слайд8.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/hgQslaid8.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/hgQslaid8.jpeg)

[![Слайд9.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/0YGslaid9.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/0YGslaid9.jpeg)

[![Слайд10.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/X2Dslaid10.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/X2Dslaid10.jpeg)

[![Слайд11.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/58sslaid11.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/58sslaid11.jpeg)

[![Слайд12.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/jISslaid12.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/jISslaid12.jpeg)

[![Слайд13.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/Rtcslaid13.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/Rtcslaid13.jpeg)

[![Слайд14.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/LDNslaid14.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/LDNslaid14.jpeg)

[![Слайд15.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/MT0slaid15.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/MT0slaid15.jpeg)

[![Слайд16.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/s2Xslaid16.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/s2Xslaid16.jpeg)

[![Слайд17.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/slaid17.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/slaid17.jpeg)

[![Слайд18.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/slaid18.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/slaid18.jpeg)