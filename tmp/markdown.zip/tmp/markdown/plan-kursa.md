# Книги > Sitecore CMS > Guidelines_&_UserManual > План курса

# План курса

[![image-1642418406961.19.27.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642418406961-19-27.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642418406961-19-27.png)

**Сессия 1:** [1\_One-Sanofi-CMS-Training\_Webinar\_Session1\_03052021.pptx](https://disk.yandex.kz/i/F9QS9E2rSLp19g)

**Сессия 2:** [1\_One-Sanofi-CMS-Training\_Webinar\_Session2\_07052021.pptx](https://disk.yandex.kz/i/s8y35AdglBG3eg)