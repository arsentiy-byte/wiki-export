# Книги > DevOps > Настройка Kibana

# Настройка Kibana

##### **Перед началом настройки:**

Необходимо проверить у бэкэнд разработчика, внесли ли они доработки, как указано в статье:

[https://wiki.rocketfirm.com/books/backend/page/laravel-kibana](https://wiki.rocketfirm.com/books/php/page/laravel-kibana)

После этого необходимо добавить секцию с переменными среды в файл .env бэкэнда, как описано в той же статье.

Логинимся в Kibana под учётной записью, обладающей административными правами на управление объектами в Kibana, например под учёткой [**elastic**](https://pass.rocketfirm.com/#/vault?collectionId=63a6262d-5123-4108-bece-8773ae8c7e9d&itemId=af09ff9f-78d2-4da3-852f-26fb54f4f392&cipherId=af09ff9f-78d2-4da3-852f-26fb54f4f392), в пространство Default.

##### **Настройка:**

Настройка проекта с нуля состоит из следующих шагов:

- Создание пространства проекта (Space)
- Создание общей роли для проекта (Roles)
- Создание Data View для определенного индекса проекта

Создать Data View можно только после того, как в эластик придёт хотя бы один лог с тем индексом, для которого требуется настроить отображение.

**Создание пространства проекта:**

1\) В меню выбираем Stack Management &gt; Kibana &gt; Spaces:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/IPdimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/IPdimage.png)

2\) Выбираем Create space:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/gIpimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/gIpimage.png)

3\) Откроется окно с параметрами создания пространства, в нём указываем (перечислено только то что нужно заполнить):

**Name** - указываем код проекта в Jira **заглавными** буквами

**Description** - пишем, что это за проект, например "Проект Freedombroker" (без кавычек)

В секции Features указываем следующий набор разделов, которые необходимо оставить в интерфейсе пространства:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/Q4Eimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/Q4Eimage.png)

4\) Сохраняем.

**Создание общей роли для проекта:**

1\) В меню выбираем Stack Management &gt; Security &gt; Roles:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/UHaimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/UHaimage.png)

2\) Выбираем Create role:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/pyzimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pyzimage.png)

3\) Откроется окно с параметрами создания роли, в нём указываем (перечислено только то что нужно заполнить):

**Role name** - указываем код проекта в Jira **маленькими** буквами

В секции Index Privileges:

**Indices** - указываем код проекта в Jira **маленькими** буквами с **звёздочкой в конце**. Этот параметр привязан к переменной KIBANA\_LOGS\_INDEX, которую мы прописываем в енв. Например freedbro\*. Такая запись выдаст участникам роли доступ ко **всем** индексам, которые начинаются с freedbro. Если требуется выдать более узкие права, например, только на тестовые логи, то можно указать freedbro-dev\*.

**Privileges** - **назначаем read** и **view\_index\_metadata**

В секции Kibana нажимаем **Add Kibana privilege**, выбираем пространство, для которого настраивали роль, выбираем набор прав, аналогичный тем, что мы выдавали для отображения в пространстве:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/44kimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/44kimage.png)

4\) Сохраняем роль.

**Создание Data View для определенного индекса проекта:**

1\) В правом верхнем углу выбираем пространство, которое настраивали:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/cPeimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/cPeimage.png)

2\) Переходим в Stack Management &gt; Kibana &gt; Data Views:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/yccimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/yccimage.png)

Нажимаем "Create data view"

4\) Откроется окошко с настройками вьюхи:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/keZimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/keZimage.png)

Справа виден список всех доступных индексов, ищем в нём тот индекс, для которого настраиваем вью. Если нужного индекса нет, значит в elasticsearch ещё не пришёл ни один лог с таким индексом. В таком случае либо просим бэкэндера, чтобы он спровоцировал запись в лог, либо ждём пока бэк её сам сгенерирует.

Заполняем поля:

**Name** - такое же как индекс

**Index pattern** - такое же как индекс **со звёздочкой в конце**

**Timestamp field** - datetime

Пример:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/2HTimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/2HTimage.png)

Сохраняем вью.

Настройка завершена. Проверить, что всё ок, можно перейдя в Analytics &gt; Discover, находясь в том же пространстве, в котором создали вью.

Чтобы добавить вью к уже существующему пространству, в котором уже имеется вью, проделываем снова шаг "**Создание Data View для определенного индекса проекта**"

После создания выбрать нужный вью можно на странице Analytics &gt; Discover, пример:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/scaled-1680-/yz9image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/yz9image.png)