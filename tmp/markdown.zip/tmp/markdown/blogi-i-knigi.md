# Книги > Доп. материал > Блоги и книги

# Блоги и книги

### Блоги

#### «Советы» Бюро Горбунова: [http://artgorbunov.ru/bb/soviet/](http://artgorbunov.ru/bb/soviet/)

Ежедневная рубрика с рекомендациями об управлении проектами, переговорах, о дизайне и здравом смысле.  
  
Начинать знакомство лучше с менеджерских советов:

- [http://artgorbunov.ru/bb/soviet/kolan/](http://artgorbunov.ru/bb/soviet/kolan/) (управление)
- [http://artgorbunov.ru/bb/soviet/sinelnikov/](http://artgorbunov.ru/bb/soviet/sinelnikov/) (переговоры)

...а также с подборки советов про отношения с клиентами: [https://bureau.ru/bb/soviet/found/Взаимоотношения%20с%20клиентом](https://bureau.ru/bb/soviet/found/%D0%92%D0%B7%D0%B0%D0%B8%D0%BC%D0%BE%D0%BE%D1%82%D0%BD%D0%BE%D1%88%D0%B5%D0%BD%D0%B8%D1%8F%20%D1%81%20%D0%BA%D0%BB%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%BC)

---

### Книги об управлении

1. Управление для тех, кто не любит управлять (Девора Зак). Скачать в [формате ePub](https://dl.dropboxusercontent.com/u/3894988/Vault/books/management/Upravlenie_dlia_teh.epub) (для электронных книг и программ-читалок на смартфонах и планшетах), в [формате PDF](https://dl.dropboxusercontent.com/u/3894988/Vault/books/management/Upravlenie_dlia_teh.pdf) (для всех остальных случаев).
2. Управляя изменениями (Ицхак Адизес)
3. Есть менеджеры, которые говорят: «Я люблю руководить. Но я не выношу своих подчиненных!» Но если руководитель не любит работать с людьми, то значит, он неправильно выбрал профессию. Скачать: [epub](https://dl.dropboxusercontent.com/u/3894988/Vault/books/management/Upravlaya_izmeneniyami.epub), [pdf](https://dl.dropboxusercontent.com/u/3894988/Vault/books/management/Upravlaya_izmeneniyami.pdf).
4. [Руководство к своду знаний по управлению проектами (Руководство PMBOK) и Стандарт управления проектом. Седьмое издание](https://disk.yandex.kz/i/2ZRrN8dFhlkjZg)

### Книги о переговорах:

1. Переговоры с монстром, Игорь Рызов (о «тяжелых» клиентах)
2. Сначала скажите «нет», Джим Кемп. Скачать: [http://flibusta.is/b/284665](https://flibusta.is/b/284665)
3. Договориться можно обо всем, Гэвин Кеннеди
4. Психология влияния, Роберт Чалдини. Скачать: [epub](https://dl.dropboxusercontent.com/u/3894988/Vault/books/management/%D0%9F%D1%81%D0%B8%D1%85%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F%20%D0%B2%D0%BB%D0%B8%D1%8F%D0%BD%D0%B8%D1%8F.epub) (для читалок).
5. Работа с клиентом для редакторов, Максим Ильяхов. [https://yadi.sk/i/9Y065NKT3ZTifP](https://yadi.sk/i/9Y065NKT3ZTifP). Редактора можно заменить на название другой специальности, смысл сохранится.