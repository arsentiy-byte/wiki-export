# Книги > Доп. материал > План развития менеджера

# План развития менеджера

## Проекты и люди

*Профессионализм менеджера выражается не в том, что делает он сам, а в том, как он побуждает к работе других людей. В этом разделе плана обучения – софт-скилы, без которых в работе не обойтись*.

**Управление собой и временем**  
*Инструменты и статьи, направленные на повышение собственной эффективности.*

Таск-трекер: [TickTick](https://intra.rocketfirm.com/manage/post/upravlenie-zadacami-v-ticktick/) + [помодоро](https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D1%82%D0%BE%D0%B4_%D0%BF%D0%BE%D0%BC%D0%B8%D0%B4%D0%BE%D1%80%D0%B0) (встроен в приложение для мобильного)  
Максим Дорофеев, [техника пустого инбокса](http://mnogosdelal.ru/slidecasts/dovedenie-del-do-kontsa/) + книга ([скачать, fb2](https://yadi.sk/i/1wHW8TGQ3WacHj))  
Успеватель Василия Кислого ([статья](http://koptelov.org/uspevatel-vasiliya-kislogo-tajm-menedzhment-i-prochee/))  
Матрица Эйзенхауэра ([статья](https://4brain.ru/blog/%D0%BC%D0%B0%D1%82%D1%80%D0%B8%D1%86%D0%B0-%D1%8D%D0%B9%D0%B7%D0%B5%D0%BD%D1%85%D0%B0%D1%83%D1%8D%D1%80%D0%B0/))  
[RescueTime](https://www.rescuetime.com/) (собирает аналитику, сколько времени на какие сайты тратится)  
[Stay Focused](https://habrahabr.ru/post/152419/) (ставит лимит на соцсети, новостные сайты и развлекательные ресурсы)

**Управление проектами**  
*То, что напрямую касается работы. Инструменты и методы повышения эффективности профессиональной деятельности.*

Яндекс школа для менеджеров ([YouTube](https://www.youtube.com/channel/UCQmAuu6V3kSzdIfrszr5iKg))  
Основы PMBoK. [Курсера](https://www.coursera.org/specializations/project-management) + [конспект](https://medium.com/@salakhmir/%D0%BF%D1%80%D0%BE%D1%86%D0%B5%D1%81%D1%81%D1%8B-pmbok-5-%D0%B7%D0%B0-10-%D0%BC%D0%B8%D0%BD%D1%83%D1%82-4bb902a810a4)  
[Scrum, Agile, Waterfall](https://rb.ru/story/agile-scrum-kanban/) (что такое, когда применяется)  
Тайм-план проекта, диаграмма Ганта  
Вычисление сроков проекта по Бобуку-Бацеку ([статья](https://intra.rocketfirm.com/brains/post/521-metod-vycislenia-srokov-vypolnenia-proektov-po-bobuku-baceku/) в интре)  
[Критический путь проекта](https://blog.ganttpro.com/ru/metod-kriticheskogo-puti-critical-path-method-i-upravlenie-srokami-proekta/)  
SMART, [правила постановки задач](http://powerbranding.ru/marketing-strategy/smart-celi/)  
Почему нельзя прерывать коллег во время работы ([статья](https://intra.rocketfirm.com/process/post/643-nikogda-ne-otvlekaj-programmista/) в интре)  
Как не выбить разработчика из состояния потока ([статья](https://habr.com/company/it-grad/blog/304658/))  
«[Хьюстон, у нас проблемы](https://www.youtube.com/watch?v=XCK7DCi5yb8)» видеолекция Людвига Быстроновского  
Разобраться в разнице между «[делать](https://drive.google.com/open?id=0B_76bkWo_th7bnhQVlBMWDZveTA)» и «[сделать](https://drive.google.com/open?id=0B_76bkWo_th7TTJZSXp1ZmdtSm8)»

**Книги**  
Книга Джозеф Хигни «Основы управления проектами» ([скачать, epub](https://yadi.sk/i/SEPRnq8M3WaZEX))  
Том ДеМарко «Deadline: роман об управлении проектами» ([скачать, fb2](https://yadi.sk/i/tBY7JSEF3WaZRo))  
Элияху Голдратт «Цель: процесс непрерывного совершенствования» ([скачать, epub](https://yadi.sk/i/gGgsFf-M3WaaQ9))  
Дэн Кеннеди «Жесткий менеджмент» ([скачать, epub](https://yadi.sk/i/Who4oBvL3Waawo))

**Блоги**  
— [Сибирикса](https://blog.sibirix.ru/)  
— [Стратоплана](http://blog.stratoplan.ru/)  
— [Мегаплана](https://megaplan.ru/blog/)

Канал [сертифицированного тренера](https://www.youtube.com/user/sofonov/playlists) по ведению проектов

**Клиенты**  
[Взаимоотношения с клиентами](http://artgorbunov.ru/bb/soviet/found/%D0%B2%D0%B7%D0%B0%D0%B8%D0%BC%D0%BE%D0%BE%D1%82%D0%BD%D0%BE%D1%88%D0%B5%D0%BD%D0%B8%D1%8F+%D1%81+%D0%BA%D0%BB%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%BC) в «Советах» Бюро  
Рассылка Ильяхова о работе с клиентами ([статья](https://intra.rocketfirm.com/books/post/829-platnyj-kurs-ilahova-o-rabote-s-klientami/) в интре)

**Книги**  
Максим Батырев «45 татуировок менеджера» ([скачать, epub](https://yadi.sk/i/VmjmETaS3WabY7))  
Максим Батырев «45 татуировок продавана» ([скачать, epub](https://yadi.sk/i/plUqLMTs3Wabbx))  
Джим Кэмп «Сначала скажите НЕТ» ([скачать, epub](https://yadi.sk/d/ZiSA-GKb3WdTuZ))  
Гэвин Кеннеди «Договориться можно обо всем» ([скачать, epub](https://yadi.sk/i/WdnHgc_J3WevfC))  
Алексей Каптерев «Мастерство презентации» ([скачать, PDF](https://yadi.sk/i/wWnzCVdH3Wf25i))  
Дэвид Майстер «Советник, которому доверяют»

**Видео**  
Отношения с клиентами: принципы «[Ружьё всегда заряжено](https://vimeo.com/41189708)» и «Анду»  
Андрей Дьяков [о правилах общения](http://www.artlebedev.ru/seminars/o-pravilah-obsheniya-s-klientami/) с клиентами  
Радислав Гандапас [о публичных выступлениях](https://www.youtube.com/watch?v=ttfHC35yaIY&list=PLHkpyDUzliZetCetLzDKSaErUyubh6sUT)

**Английский язык**  
[Memrise](https://www.memrise.com/ru/) - словарный запас. Есть под Android и iOS  
[Puzzle English](https://puzzle-english.com/)

## **Профессиональные знания**

*Менеджер должен разбираться в том, с чем он работает – хотя бы на уровне поверхностного понимания. Здесь – о том, с чем работают твои коллеги.*

**Текст и письмо**  
[Конспект первого дня](http://vsevolodustinov.ru/blog/all/informacionny-stil-i-redaktura-teksta/) курса Ильяхова, видео и ссылки там же  
Базовая [рассылка Главреда](https://glvrd.ru/) ([конспект](https://intra.rocketfirm.com/text-and-copyright/post/738-bazovyj-kurs-glavreda-za-5-minut/) в интре)  
Ильяхов «Пиши, сокращай» ([скачать, pdf](https://yadi.sk/i/VMhX0uyU3WaaaC))  
Нора Галь «Слово живое и мёртвое» ([скачать, fb2](https://yadi.sk/i/oqXhr6Gr3WabV4))  
Будь [проще](https://vc.ru/33685-pravila-peregovorov-kak-pisat-elektronnye-pisma) – правила переписки по электронной почте  
Ильяхов, [гигиена текста](http://maximilyahov.ru/blog/all/hygiene/)

**Дизайн и продакт-менеджемент**  
Ководство ([на сайте студии](https://www.artlebedev.ru/kovodstvo/sections/) | [скачать, epub](https://yadi.sk/i/udZjXQkm3WawWw))  
No Flame No Game, продуктовый менеджмент (канал в [телеграм](https://t.me/proproduct))  
Дональд Норман «Дизайн привычных вещей» ([скачать, epub](https://yadi.sk/i/ORQgW_bY3WawLP))  
Фичи, которые можно не делать ([статья](https://intra.rocketfirm.com/design/post/744-vy-vypuskaete-90-fic-zra-ili-ne-vovrema/) в интре)  
Эркен Кагаров о предмете и фоне ([видеоролик](https://intra.rocketfirm.com/brains/post/604-erken-kagarov-o-predmete-i-fone/) в интре)

**Верстка**  
[HTML-Academy](https://htmlacademy.ru/) – пройти 300 бесплатных заданий основы  
Уроки WebDesign Master, [канал на YouTube](https://www.youtube.com/channel/UC7enHM_oJRYJOnyJrcRzwbg)  
[Bootstrap 4](https://getbootstrap.com/) (разобраться с принципами работы сетки)  
Что такое [SASS, SCSS](http://www.internet-technologies.ru/articles/v-chem-raznica-mezhdu-sass-i-scss.html)  
Что такое [React](https://getinstance.info/articles/react/react-basics/), Angular, React Native

**Код**  
[Codeacademy](https://www.codecademy.com/learn)  
[Хекслет](https://ru.hexlet.io/) (+ курс GitHub)  
Шпаргалка по Git ([статья](https://intra.rocketfirm.com/process/post/502-spargalka-po-git/))

**Реклама, SMM и SEO**  
Что такое GTM ([статья](https://intra.rocketfirm.com/seomedia/post/podklucenie-google-tag-manager/) в интре)  
Что такое программатики ([статья](https://intra.rocketfirm.com/tech/post/706-wtf-programmatic-the-programmatic-advertising-survival-guide/) в интре)  
Обучающий [курс по Google Analytics](https://support.google.com/analytics/answer/4553001?hl=ru)  
Обучающий [курс по Метрике](https://www.youtube.com/playlist?list=PLjEKjSpX1kHXiwpHpR_j44YFxXaq7GYrh)  
Курсы на [ppc.world](https://ppc.world/courses/)  
  
Чек-лист по SEO перед запуском проекта ([статья](https://intra.rocketfirm.com/seomedia/post/435-cek-list-po-seo-pered-zapuskom-proekta/) в интре)

**Книги и блоги**  
[WebPromoExpert](https://webpromoexperts.com.ua/)  
Devaka Talk, SEO (канал [телеграм](https://t.me/devakatalk))

**Сертификации**  
[Основы AdWords](https://academy.exceedlms.com/)  
[Яндекс.Директ](https://yandex.ru/adv/expert/exam/direct)  
[Яндекс.Метрика](https://yandex.ru/adv/expert/exam/metrika)  
[Google Analytics](https://academy.exceedlms.com/)

## **Инструменты**

*В блоке «инструменты» то, с чем желательно быть знакомым. Так же желательно на всякий случай иметь набор приложений на компьютере – чтобы не искать судорожно, когда они потребуются.*

**Текст**  
[Главред](https://glvrd.ru/) (проверка ошибок в тексте)  
Google Docs

**Дизайн и ментальные карты**  
Axure RP – прототипирование  
Adobe Photoshop – редактор  
Sketch – редактор  
xMind 8 – ментальные карты  
[Invis.io](http://invis.io/)– прототипирование

**Код**  
[SublimeText 3](https://www.sublimetext.com/) – удобный редактор кода

## **Кругозор**

*Не вошедшее ни в одну категорию выше. Полезно, но опционально.*  
«[Learn how to learn](https://medium.com/@salakhmir/learn-how-to-learn-%D0%BA%D0%BE%D0%BD%D1%81%D0%BF%D0%B5%D0%BA%D1%82-%D0%BA%D1%83%D1%80%D1%81%D0%B0-ca6f015cd8d7)» – как работает мозг, как заставить его работать лучше  
Джон Медина «Правила мозга» – в продолжение «Learn how to learn» ([скачать, epub](https://yadi.sk/i/wZbAvm293Wabzx))  
Скорость печати — [vse10.ru](https://vse10.ru/my/)  
Теория машинного обучения ([статья](https://intra.rocketfirm.com/tech/post/618-nagladnoe-vvedenie-v-teoriu-masinnogo-obucenia/) в интре)  
Про когнитивные искажения ([статья](https://intra.rocketfirm.com/brains/post/575-kognitivnye-iskazenia/) в интре)  
Об осознанном подходе к обучению и работе ([статья](https://intra.rocketfirm.com/brains/post/476-osoznannyj-podhod-k-rabote/) в интре)

Конспектирование изучаемого повышает запоминаемость материала. Рекомендую завести блог, в котором ты сможешь выкладывать конспекты (и перечитывать их после), рассказывать о собственном опыте. Самая удобная блог-платформа – [Medium](https://medium.com/). Не забывай делиться с коллегами в интре :-)

---

Автор материала — Виталий Тарасенко.  
Тайный советник — Роман Надеин.