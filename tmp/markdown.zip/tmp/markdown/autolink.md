# Книги > Mattermost > Плагины > Autolink

# Autolink

Плагин позволяет преобразовывать данные по определенному паттерну.  
Например, когда вы отправляете в чат номер задачи из jira TEST-1, он автоматически пробразует ее в ссылку на jira.  
  
Как настроить автозамену для jira:  
  
1\. Нам нужно:  
\_название\_ - кодое имя для правила, рекомендуется делать малекими буквами без пробелов  
\_код\_проекта\_ - код проекта из jira  
  
2\. Вызываем команды:

```
/autolink add _название_
/autolink set _название_ Pattern (_код_проекта_)(-)(?P\d+)
/autolink set _название_ Template [_код_проекта_-${jira_id}](https://jira.rocketfirm.com/browse/_код_проекта_-${jira_id})
/autolink set _название_ WordMatch true
/autolink set _название_ ProcessBotPosts true
/autolink enable _название_
```

Например, для проекта с кодом в jira RG лушче выбрать имя rg и ввести следущие команды:

```
/autolink add rg
/autolink set rg Pattern (RG)(-)(?P\d+)
/autolink set rg Template [RG-${jira_id}](https://jira.rocketfirm.com/browse/RG-${jira_id})
/autolink set rg WordMatch true
/autolink set rg ProcessBotPosts true
/autolink enable rg
```

Проверить, работает ли автозамена можно командой

```
/autolink test rg RG-1
```