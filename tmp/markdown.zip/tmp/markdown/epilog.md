# Книги > Magic slide: CLM-презентации. Работа с документами > Эпилог

# Эпилог

Таким образом, мы рассмотрели все этапы создания CLM презентации и документацию, которая встречается на этих этапах. Резюмируя все вышесказанное, представим краткую версию этапов и документации:   
1\. [Бриф](https://wiki.rocketfirm.com/books/magic-slide-clm-prezentacii-rabota-s-dokumentami/page/brif "Бриф") (получаем и согласуем ТЗ от клиента, результат – бриф);  
2\. [Смета](https://wiki.rocketfirm.com/books/magic-slide-clm-prezentacii-rabota-s-dokumentami/page/smeta "Смета") (оцениваем объем работ и согласуем с клиентом сумму оплаты, результат – смета, Заказ на закупку/Приложение);  
3\. [Запуск проекта](https://wiki.rocketfirm.com/books/magic-slide-clm-prezentacii-rabota-s-dokumentami/page/zapusk-proekta "Запуск Проекта") (запускаем проект в Интре и прикрепляем к нему всю необходимую документацию, результат – новый проект в Интре, новое приложение в Интре);   
4\. [ Закрытие проекта](https://wiki.rocketfirm.com/books/magic-slide-clm-prezentacii-rabota-s-dokumentami/page/zakrytie-proekta "Закрытие проекта") (после того, как проект выполнен, закрываем проект в Интре и выставляем счет на оплату клиенту, результат – новый счет в Интре, Счет на оплату, АВР, отчет.