# Книги > QJL :: Юношеская футбольная лига > Клуб

# Клуб

Техническое описание по ссылке – [https://jira.rocketfirm.com/secure/attachment/37638/Клуб%20-%20Команда.docx ](https://jira.rocketfirm.com/secure/attachment/37638/%D0%9A%D0%BB%D1%83%D0%B1%20-%20%D0%9A%D0%BE%D0%BC%D0%B0%D0%BD%D0%B4%D0%B0.docx)