# Книги > PHP > Swagger > Использование и тестирование

# Использование и тестирование

После того как документация написана ее нужно проверить и добавить в репозиторий. В GitLab есть встроенный интерфейс для просмотра документации в формате OpenAPI. GitLab позволяет только посмотреть описание входных и выходных параметром, проверить возвращаемые данные, к сожалению, нельзя из-за ограничений CORS-ов.  
Данный интерфейс выглядит так:

[![pasted image 0.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/pasted-image-0.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/pasted-image-0.png)

NOTE: для того чтобы gitlab воспринимал файл как документацию необходимо, чтобы он назывался swagger\_api.yaml.

Протестировать описанные endpoints и проверить возвращаемые данные можно на развернутом Swagger UI, который находится по адресу http://swagger.rocketfirm.net/. Для этого нужно добавить файл документации в папку data в папке поддомена, затем в адресной строке ввести путь к файлу.

[![pasted image 0 (1).png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/pasted-image-0-1.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/pasted-image-0-1.png)

Выбираем нужный сервер в разделе servers. Если в проекте есть авторизация, то заполняем данные для входа в разделе Authorize.

[![image-1628152203577.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/image-1628152203577.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/image-1628152203577.png)

После заполняем необходимые параметры, нажимаем "Try it out" и получаем ответ от сервера, который должен соответствовать описанным ответам.

[![image-1628152237183.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/image-1628152237183.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/image-1628152237183.png)