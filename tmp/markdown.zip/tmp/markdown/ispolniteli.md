# Книги > Настройка и работа в Jira > Исполнители

# Исполнители

По большей части, данный функционал определяет те или иные разрешения на доске и лишь частично позволяют автоматизировать вашу работу.   
  
Тем не менее, когда к вам в проект добавляется новый сотрудник, делать данную процедуру необходимо каждый раз, для того чтобы он мог работать в нашем проекте.

1\. Заходим в "Параметры проекта" (есть на предыдущей странице), и выбираем раздел "Пользователи и роли";

[![Снимок экрана 2023-08-17 в 15.25.22.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/scaled-1680-/snimok-ekrana-2023-08-17-v-15-25-22.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/snimok-ekrana-2023-08-17-v-15-25-22.png)

2\. Кликаем по кнопке "Добавить Пользователей к Роли";  
– Для разработчиков, дизайнеров и контент менеджеров выставляем роль "Developers"  
– Для тестировщиков, выставляем роль QA (в будущем, при переносе карточек в колонку "Тест", роль будет назначаться аввтоматически, что ускорит вашу работу)  
– Для менеджера (в случае, если вы уходите в отпуск или передадите проект), выбираем роль Manager;

[![Снимок экрана 2023-08-17 в 15.27.00.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/scaled-1680-/snimok-ekrana-2023-08-17-v-15-27-00.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/snimok-ekrana-2023-08-17-v-15-27-00.png)

3\. Готово.

[![Снимок экрана 2023-08-17 в 15.28.23.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/scaled-1680-/snimok-ekrana-2023-08-17-v-15-28-23.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/snimok-ekrana-2023-08-17-v-15-28-23.png)

\_\_\_  
  
После того, как вы оформили Jira и добавили в нее вашу команду, время работать с колонками – [https://wiki.rocketfirm.com/books/nastroika-i-rabota-v-jira/page/kolonki](https://wiki.rocketfirm.com/books/nastroika-i-rabota-v-jira/page/kolonki)