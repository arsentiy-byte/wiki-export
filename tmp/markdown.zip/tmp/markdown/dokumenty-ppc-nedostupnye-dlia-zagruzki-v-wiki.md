# Книги > PPC > Регламенты PPC > Документы PPC, недоступные для загрузки в Wiki

# Документы PPC, недоступные для загрузки в Wiki

- ### [Грейдирование PPC-специалиста](https://docs.google.com/spreadsheets/d/1X8vNFOak5GL5x7jP0a68v7Ck8TcnF2D3JFckllPMdmg/edit#gid=0)
- ### [Конструктор неймингов](https://docs.google.com/spreadsheets/d/14ciXfmEHG433xV_oawAUgTZq77EMW8tFfjAeqPKSWPI/edit#gid=0)
- ### [Расчет зарплаты PPC](https://docs.google.com/spreadsheets/d/1M2RA4MNhECho_8wjaHm2jiU0Ey1rbSLcwGdnaCU3D1Q/edit#gid)
- ### [Размеры проектов](https://docs.google.com/spreadsheets/d/1i_XtecDtxoB3wi42QGLEJQmDrsPzkxATQejK83k2dKg/edit)