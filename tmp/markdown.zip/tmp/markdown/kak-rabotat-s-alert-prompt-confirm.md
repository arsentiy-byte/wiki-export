# Книги > Автоматизация тестирования > Как работать с alert, prompt, confirm?

# Как работать с alert, prompt, confirm?

- **alert**
- **prompt**
- **confirm**

Все эти методы являются модальными: останавливают выполнение скриптов и не позволяют пользователю взаимодействовать с остальной частью страницы до тех пор, пока окно не будет закрыто.---

Всё что будет использоваться в статье:***Javascript*** - Основной язык.***Playwright*** - Основной фреймворк.  
**Что такое alert, prompt, confirm?**Ты что-то нажал и появилось вот это?[![Alert.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/scaled-1680-/alert.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/alert.png)Значит, перед тобой alert.У alert'а есть два друга : prompt и confirm.prompt'у часто одиноко и он хочет, поговорить, поэтому он будет у тебя что-то спрашивать или уточнять.[![prompt.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/scaled-1680-/prompt.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/prompt.png)confirm в целом парень проще, с ним можно согласиться или отказаться и ему норм. Будь как confirm.Выглядит он, кстати, вот так:[![confirm.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/scaled-1680-/confirm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-10/confirm.png)Для простоты я буду их далее называть Alert'ами.**Что делать, если при написании автотеста мы столкнулись с Alert'ами?**Обязательно нужно знать, что сами Alert'ы не имеют своего локатора, поэтому через Xpath их не найти.В таком случае есть метод Dialog ([ссылка на документацию](https://playwright.dev/docs/dialogs)).Возьмём как пример метод:dialog.accept ()Как видно выше, у всех Alert'ов есть кнопка "ОК".Этот метод позволяет нажать ок, а в случае с prompt'ом в скобку можно поместить ответ на вопрос.Просто нужно поместить текст в скобки и добавить кавычки. Получится вот так:  
```
dialog.accept('Сюда можно вставить абсолютно любой текст, желательно длинный. Чтобы увидеть, что он отправился.')
```

Также есть метод:dialog.dismiss()Который просто отменяет alert'ы.Есть момент, что придётся внимательно смотреть в область по центру экрана, так как, к сожалению, нет способа замедлить сам метод dialog. accept() или dialog. dismiss()Но есть метод немного проще. Вот, например, фрагмент кода:```JavaScript
const { chromium } = require('playwright'); 
(async () => { 
  const browser = await chromium.launch({ 
    headless: false 
  }); 
  const context = await browser.newContext(); 
  // Open new page 
  const page = await context.newPage(); 
  // Go to https://learn.javascript.ru/uibasic 
  await page.goto('https://learn.javascript.ru/uibasic'); 
  await page.waitForTimeout(3000); 
  // Click on the js activator'#rwuem4wosc a'
  page.once('dialog', dialog => { 
    setTimeout(function(){ 
      dialog.accept('Сюда можно вставить абсолютно любой текст, желательно длинный. Чтобы увидеть, что он отправился.'); 
    },12000) 
  }); 
  await page.waitForTimeout(3000); 
   
  await page.locator('#rwuem4wosc a').first().click(); 
  await page.waitForTimeout(3000); 
  // End of the script
  await context.close(); 
  await browser.close(); 
})();
```

Как видно, это обычный код на запуск prompt'a. И в этом случае необходимо смотреть внимательно в центр экрана при запуске теста.Это доставляет дискомфорт, поэтому упростить себе задачу можно, просто прописав console.log()И выйдет вот так:```JavaScript
  page.once('dialog', dialog => { 
    setTimeout(function(){ 
      dialog.accept('Сюда можно вставить абсолютно любой текст, желательно длинный. Чтобы увидеть, что он отправился.'); 
    },12000) 
      console.log("Ввёл текст в prompt")
  }); 
```

И всё. Сюда уже можно добавить кроссбраузерность и всё что угодно.