# Книги > MacOS > Microsoft Office 2019

# Microsoft Office 2019

Microsoft Office 2019 — текущая версия офисного пакета компании Microsoft, следующая за Microsoft Office 2016.

### Установка

Скачиваем [https://go.microsoft.com/fwlink/p/?linkid=525133](https://go.microsoft.com/fwlink/p/?linkid=525133)  
Делаем обычную установку.

Скачиваем [https://appstorrent.ru/index.php?do=download&amp;id=0](https://appstorrent.ru/index.php?do=download&id=0)  
И тоже устанавливаем.