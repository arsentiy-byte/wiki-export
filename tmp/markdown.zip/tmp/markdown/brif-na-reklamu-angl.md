# Книги > Менеджерский > Брифы > Бриф на рекламу (англ)

# Бриф на рекламу (англ)

1. Name of the company 

2. Address of the web page to be advertised  
      
    
3. Type of activity of your company  
      
    
4. Your contacts  
      
    
5. Your e-mail  
      
    
6. Goods or services to be advertised  
      
    
7. Describe advantages of your goods or services competitors  
      
    
8. Describe advantages of your company before competitors  
      
    
9. Who are your competitors?  
      
    
10. Will there be any discounts or promotions for the duration of the advertising campaign?  
      
    
11.  The purpose of advertising campaign:  
     - brand awareness;  
     - target cleek to your web page;  
     - iIncrease in customer inquiries (calls, e-mails etc.);  
     - other \_\_\_\_\_  
      
    
12. Which cities or regions would you like to advertise in?  
      
    
13. Describe your customer (age, gender, income level, etc)  
      
    
14. How much are you willing to invest in advertising monthly?  
      
    
15. When would you like to start an advertising campaign?  
      
    
16. Would you need a designer and/or copywriter to prepare layouts and texts for advertising campaigns?  
      
    
17. Which platforms would you like to advertise on?  
      
    
18. Have you had previous experience with advertising agencies? If “yes”, can you describe it? What you liked and what you didn't?  
      
    
19. Have you previously launched advertising campaigns for your products? If “yes”,can you describe it? What you liked and what you didn't?  
      
    
20. Do you have an automatic system for registering and processing orders? If “yes”, could you name the system.  
      
    
21.  Additional requests  
      
      
      
    

 

 

 

