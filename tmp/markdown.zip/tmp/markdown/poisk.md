# Книги > PHP > ElasticSearch. Основы > Поиск

# Поиск

##### Query

Поиск реализуется через query и API поиска

`GET /my-index-000001/_search`

Также можно искать по всем индексам сразу

`GET /_search`

Пример поиска на прямое вхождение строки, где «*user.id*» это название поля по которому мы ищем и «*kimchy*» это искомая строка.

```JSON
GET /my-index-000001/_search?from=40&size=20
{
  "query": {
    "term": {
      "user.id": "kimchy"
    }
  }
}
```

##### Multi match

В примере выше искомая строка ищется только в одном поле, для поиска по нескольким полям используется multi\_matсh

```JSON
GET /_search
{
  "query": {
    "multi_match" : {
      "query":    "this is a test", 
      "fields": [ "subject", "message"],
      "type": "phrase_prefix" 
    }
  }
}
```

Multi match принимает параметр type, описание и виды можно найти в официальной [документации](https://www.elastic.co/guide/en/elasticsearch/reference/7.14/query-dsl-multi-match-query.html#multi-match-types)

##### Fuzziness

В multi\_matсh так же есть параметр fuzziness, который отвечает за опечатки. Можно использовать значение автоматическое определение AUTO, а можно указать точное значение, см. [документацию](https://www.elastic.co/guide/en/elasticsearch/reference/7.14/common-options.html#fuzziness)

```JSON
GET /_search
{
  "query": {
    "multi_match" : {
      "query":    "this is a test", 
      "fields": [ "subject", "message"],
      "fuzziness": "AUTO" 
    }
  }
}
```

##### Bool

Можно объединять 2 запроса используя bool, тогда каждый запрос указывается внутри атрибута с уровнем приоритетности, можно посмотреть описание в [документации ](https://www.elastic.co/guide/en/elasticsearch/reference/7.14/query-dsl-bool-query.html#query-dsl-bool-query)

```JSON
POST _search
{
  "query": {
    "bool" : {
      "must" : {
        "term" : { "user.id" : "kimchy" }
      },
      "filter": {
        "term" : { "tags" : "production" }
      },
      "must_not" : {
        "range" : {
          "age" : { "gte" : 10, "lte" : 20 }
        }
      },
      "should" : [
        { "term" : { "tags" : "env1" } },
        { "term" : { "tags" : "deployed" } }
      ],
      "minimum_should_match" : 1,
      "boost" : 1.0
    }
  }
}
```