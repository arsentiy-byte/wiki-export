# Книги > Работа с HH > Загрузка страницы вакансий в hh > Конструктор для кода

# Конструктор для кода

ниже конструктор для кода

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXc6qbcFHErG2YCe5AZQrxv-IKSb-AEPnjjkILlstaCqfMMOfNvKIkeROgckZdTXXksAhW8lUcBDjGvYRACo5BcVTQI7He6KRCaN593cHxAV-ogWOIcE0Yl8mW7eGhKQD74i1JGe3CnpEKloUjWjeO5JemU9?key=GoCkmrK5QxgH0NrMeVt1uA)

Создаем в первую очередь шаблон

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXejjHKzYDCatpLB-h8vDTHbofTfCcK9t1modBHekCZnjN-06j5Lp4JxwCZECX3Fr-fXK6aIZJwAFfZBwNCKrAvPHP_3xl2UuSixbLN4ZdXLBjJ2oO36fKLBLOKhEdMAJTS87bELcwBLTupANctwl4dUcco?key=GoCkmrK5QxgH0NrMeVt1uA)

Шаблон автоматически создаст теги для кода между ними вставляем код страницы начиная с стилей и убрав теги html и body

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXc-_Vz1kdHGwpY_UGbHSJ02zHDM9oqCh_JKj1mGZO7cWC0QToUfQaIiza6jUaj1yY8l4kytjFJeBEecS9Hgd6WJm_U_Ha7AyAcKne9pZDwwwctAMfrArkAeKrfOjzMq1y5NUF2VdgxJMLZ0aA195VyoWj9g?key=GoCkmrK5QxgH0NrMeVt1uA)  
заполняем код

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXfCwznnPF0VZ90OCkkMnsCs5JnkIlHRW7XE8YHmLg0DpttP7DyNkIVGbV9quuIy0z6S8VdAULBgkKPDVMcJCVgHSXQWW07mtpkv0IL10bBvyDxofpCBBzWtObCFo9dtb9FxzP9F9IEYSd1hhd90NEJ9Vz9l?key=GoCkmrK5QxgH0NrMeVt1uA)  
загружаем картинки

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXemY3-Np19XuyYwv2e19Glzbp3q4vmtVBkoYCP9VrgdO9_iKLv5y_gD1lX3Kjw8eF95fZbEgQr1EMb4mn4vGBI6q1KSQafHlhOQVcM9EGlaGWWDeWdg4IJng7QE7n6AKqY8DuwFu80saF0gG_fkJW8y7_PI?key=GoCkmrK5QxgH0NrMeVt1uA)  
Далее нужно каждую картинку найти в коде и заменить на загруженную в систему, выделяем путь и жмем на картирку она автаматически заменит на новый путь

![](https://lh7-us.googleusercontent.com/docsz/AD_4nXfmA1kOQusNcOTYYZPfPXmrhf5yCpc_osAT_rN8YoG4wKuQh8zkmH_lixpFj6oJmPv9nNFiY_gosP20bQlcULHTs4bx98Aoy4M8KsDzNMZzDOOtK2aZouygWopfLDw7hEdMsBocGen7Ad0W8XpphZNR19rk?key=GoCkmrK5QxgH0NrMeVt1uA)  
Далее надо заменить сверстанный текст вакансии на **&lt;hht:vacancy-description/&gt;**

Жмем сохранить и проверяме ошибки и исправляем их, вакансия выбрана остается только активировать если на предпросмотре все в порядке