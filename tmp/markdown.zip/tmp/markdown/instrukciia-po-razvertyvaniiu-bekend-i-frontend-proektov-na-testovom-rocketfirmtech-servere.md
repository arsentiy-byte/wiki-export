# Книги > DevOps > Инструкция по развертыванию бэкенд и фронтенд проектов на тестовом rocketfirm.tech сервере

# Инструкция по развертыванию бэкенд и фронтенд проектов на тестовом rocketfirm.tech сервере

##### **Развертывание бэкенд-проекта на Laravel**

1. **Зайти на сервер и в папке /var/www/vhosts/ клонировать проект**: ```
    git clone -b develop gitlab_repo_ssh_link projectname-api.rocketfirm.tech
    ```
2. **Создать `.env` файл из .env.example**: ```
    cp .env.example .env
    ```
3. **Настроить переменные в `.env`**:   
     Указать URL:  
    ```
    APP_URL=https://projectname-api.rocketfirm.tech
    ```
    
    Настроить порты:  
    ```
    NGINX_HOST_PORT_HTTP=
    NGINX_HOST_PORT_HTTPS=
    DB_HOST_PORT=
    REDIS_HOST_PORT=
    ```
    
    Чтобы проверить доступность порта: ```
    netstat -lpnt | grep PORT
    ```
    
    Настроить параметры базы данных:  
    ```
    DB_DATABASE=
    DB_USERNAME=
    DB_PASSWORD=
    ```
    
    Прописать пароль для Redis:  
    ```
    REDIS_PASSWORD=
    ```
4. **Изменить `WORKER_UID`**:  
    ```
    bash uid.sh
    ```
5. **Отключить отслеживание изменений прав файлов Git:**  
    ```
    git config core.fileMode false
    ```
6. **Запуск проекта через Docker**:  
    ```
    docker-compose build --no-cache && docker-compose up -d
    ```
7. **Запуск миграций и настройка проекта**:  
    Зайти в контейнер:  
    ```
    docker-compose exec -u www-data php bash
    ```
    
    И выполнить команды:
    
    ```
    touch .bash_history
    composer install --ignore-platform-reqs
    php artisan storage:link
    php artisan key:generate
    php artisan migrate --seed
    php artisan make:filament-user
    php artisan shield:generate --all
    php artisan shield:super-admin
    ```

##### **Развертывание фронтенд-проекта на Nuxt**  
  


1. **В папке /var/www/vhosts/ Клонировать проект**:  
    ```
    git clone -b develop gitlab_repo_ssh_link projectname.rocketfirm.tech
    ```
2. **Создать `.env` файл из шаблона**:  
    ```
    cp env.example .env
    ```
3. **Настроить URL**:  
    ```
    BASE_URL=https://projectname-api.rocketfirm.tech
    ```
4. **Запуск проекта через Docker**:  
    ```
    docker-compose build --no-cache && docker-compose up -d
    ```

##### **Настройка Nginx**  
  


1. **Создать конфиг для бэкенда:** Файл `/etc/nginx/conf.d/projectname-api.rocketfirm.tech.conf`  
    ```
    server {
        server_name projectname-api.rocketfirm.tech;     #Change domain name
        root /var/www/vhosts/projectname-api.rocketfirm.tech/public;
    
        access_log  /var/log/nginx/projectname-api.rocketfirm.tech.access.log;     #change log file names
        error_log  /var/log/nginx/projectname-api.rocketfirm.tech.error.log;
    
        add_header X-Frame-Options "SAMEORIGIN";
        add_header Strict-Transport-Security "max-age=63072000; includeSubdomains;";
        index index.html index.htm index.php;
    
        location / {
            proxy_pass https://localhost:NGINX_HOST_PORT_HTTPS;   #Specify port
            proxy_set_header Host              $host;
            proxy_set_header X-Real-IP         $remote_addr;
            proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            add_header X-Robots-Tag "noindex, nofollow, nosnippet, noarchive";
        }
    
        location = /robots.txt {
            add_header Content-Type text/plain;
            return 200 "User-agent: *\nDisallow: /\n";
        }
    }
    
    ```
2. **Создать конфиг для фронтенда:** Файл `/etc/nginx/conf.d/projectname.rocketfirm.tech.conf````
    server {
        server_name projectname.rocketfirm.tech;    #Change domain name 
        listen 80;
    
        location / {
            proxy_pass http://127.0.0.1:NUXT_PORT;  #Specify port
            proxy_set_header Host              $host;
            proxy_set_header X-Real-IP         $remote_addr;
            proxy_set_header X-Forwarded-for   $remote_addr;
            add_header X-Robots-Tag "noindex, nofollow, nosnippet, noarchive";
        }
    
        location = /robots.txt {
            add_header Content-Type text/plain;
            return 200 "User-agent: *\nDisallow: /\n";
        }
    }
    
    ```
3. **Проверить конфигурацию Nginx**:  
    ```
    sudo nginx -t
    ```
4. **Перезапустить Nginx**:  
    ```
    sudo systemctl reload nginx
    sudo systemctl restart nginx
    ```

##### **Генерация SSL сертификата**  
  


1. **Сгенерировать SSL сертификат для доменов:**  
    ```
    sudo certbot --nginx
    ```

**После этого ваши проекты должны быть готовы к использованию!**