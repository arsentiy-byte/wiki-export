# Книги > Archived > ROCKETFRONT-REACTNATIVE (ЧЕРНОВИК) > Конфигурация нового проекта :: Импорт шрифтов

# Конфигурация нового проекта :: Импорт шрифтов

#### **Шаг 0**

Удалить старые шрифты

##### Android:

Просто удалите шрифты из каталога, созданного командой react-native link. Этот каталог находится в:  
android/app/src/main/assets/

##### IOS:

Удалите все шрифты, которые вы хотите удалить из файла Info.plist, открыв XCode

Удалите все шрифты, оставшиеся связанными в XCode в разделе Build Phases &gt; Copy Bundle Resources

#### **Шаг 1**

Скачать шрифты и положить в папку assets/fonts

#### **Шаг 2**

Запустить команду

```shell
$ npx react-native link; cd ios; pod install; cd ..
```