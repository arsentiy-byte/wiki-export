# Книги > Про задачи и оценки > Что почитать

# Что почитать

[Как научиться правильно определять сроки выполнения работы — отвечают эксперты](https://tproger.ru/experts/time-estimation/%20https://proglib.io/p/development-time%20https://vc.ru/flood/17944-time-cost)

[Как оценить время, необходимое на разработку](https://proglib.io/p/development-time)

[«Когда будет готово?»: как оценить время на выполнение сложных задач](https://vc.ru/flood/17944-time-cost)

[Оценка задач в Story Points](https://habr.com/ru/post/489500/)

[Оценка времени выполнения задачи](https://habr.com/ru/post/52472/)

Категория "классика":  
[Мифический человеко-месяц или как создаются программные системы](https://nsu.ru/xmlui/bitstream/handle/nsu/8870/Frederick_Brooks.pdf)