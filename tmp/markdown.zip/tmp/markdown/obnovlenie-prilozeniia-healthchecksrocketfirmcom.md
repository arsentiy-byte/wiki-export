# Книги > DevOps > Обновление приложения healthchecks.rocketfirm.com

# Обновление приложения healthchecks.rocketfirm.com

##### **Создание резервной копии базы данных:**

```
cp /var/www/vhosts/docker-hc/data/hc.sqlite /var/www/vhosts/hc_$(date +%F).sqlite
```

##### **Убедитесь, что в `docker-compose.yml` в папке /var/www/vhosts/docker-hc/ указан тэг `latest`:**

```
image: ghcr.io/linuxserver/healthchecks:latest
```

##### **Пулл последнего образа Docker:**

```
docker pull ghcr.io/linuxserver/healthchecks:latest
```

##### **Остановите и удалите существующий контейнер:**

```
docker stop healthchecks
docker rm healthchecks
```

##### **Пулл последнего образа через Docker Compose:**

```
cd /var/www/vhosts/docker-hc
docker-compose pull healthchecks
```

##### **Запустите контейнер в фоновом режиме:**

```
docker-compose up -d
```

##### **Удалите старые образы Docker:**

```
docker image prune
```

Теперь приложение должно быть обновлено до последней версии.