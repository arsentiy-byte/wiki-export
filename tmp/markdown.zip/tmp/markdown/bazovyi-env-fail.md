# Книги > PHP > Базовый шаблон Docker для Laravel > Базовый env-файл

# Базовый env-файл

Я приведу только некоторые моменты, которые должны **обязательно** быть заполнены в env-файле

**APP\_NAME**=&lt;Уникальное имя проета, без пробелов и спец-символов(\_ можно использовать)&gt;

**DB\_CONNECTION**=pgsql

**DB\_HOST**=&lt;APP\_NAME&gt;\_database

**DB\_PORT**=5432

**DB\_DATABASE**=postgres

**DB\_USERNAME**=postgres

**DB\_PASSWORD**=&lt;Произвольный пароль&gt;

**BROADCAST\_DRIVER**=redis

**CACHE\_DRIVER**=redis

**QUEUE\_CONNECTION**=redis

**SESSION\_DRIVER**=redis

**REDIS\_HOST**=&lt;APP\_NAME&gt;\_redis

**REDIS\_PASSWORD**=null

**REDIS\_PORT**=6379