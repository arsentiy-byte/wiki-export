# Книги > Archived > Live чат на Firebase > Добавление сообщений

# Добавление сообщений

**5.** **Добавление сообщений в чат. [Add data firestore](https://firebase.google.com/docs/firestore/manage-data/add-data)**

Далее выбор стоит за вами, использовать готовое решение для реализации функционала чата либо писать его самостоятельно. От этого процесс общения с firestore не изменится и в принципе его можно назвать уневерсальным. Единственно нужно учитывать что firestore работает по принципу создания коллекций и хранит в каждой из них какое то значение или группу значений. На нашем примере это будет выглядеть так:  
 Чаты =&gt;  
 Список комнат чатов (как именно их называть можно задавать в коде но если этого не сделать firestore сгенерирует id за вас) =&gt;  
 Сообщения которые есть в переписке =&gt;  
 Данные о конкретном сообщении (от кого, кому, текст, и т.д.,) структуру сообщений формируем сами, сейчас покажу как.  
  
Я использую готовое решение для RN - Gifted Chat. Здесь не буду останавливаться на функционале самого чата, затрону лишь его часть общения с базой, это отправка сообщений и слушатель событий для обновления чата в режиме Live.

```javascript
import { db } from '../../../../firebase';

const [messages, setMessages] = useState([]);
const [text, setText] = useState('');

const onSend = useCallback((messages = []) => {
    setMessages(previousMessages =>
      GiftedChat.append(previousMessages, messages),
    );
    const { _id, text, createdAt, user } = messages[0];
    db.collection('Chats').doc(`${gameChat.id}`).collection('messages').add({ _id, text, createdAt, user });
  }, []);

GiftedChat
          messagesContainerStyle={{paddingBottom: 20}}
          messages={messages}
          text={text}
          onInputTextChanged={!isActive ? null : setText}
          onSend={!isActive ? null : onSend}
          user={{
            _id: user.id,
            name: user.fullName,
            avatar: user.avatar,
          }}
/>
```

![](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-grps2etq.gif)![](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-dr8gs15n.gif "Click and drag to move")В коде что выше, структура сообщения формируется через Gifted chat но нам интересна часть кода где мы обращаемся к db для формирования запроса на создание нужных нам коллекций из данных которые мы туда передаем. Сначала создаем коллекцию чатов, затем используя id игры из нашего приложения (в вашем проекте может быть что то другое, у меня игры) мы формируем комнату под конкретную игру. Создаем внутри комнаты коллекцию messages и при помощи метода add добавляем наше сообщение и все последующие. Вот так выглядит структура в самом firestore в браузере, на картинках ниже

[![embedded-image-GCFbbvZn.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/embedded-image-gcfbbvzn.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-gcfbbvzn.png)

[![embedded-image-vZ0ehbKZ.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/embedded-image-vz0ehbkz.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-vz0ehbkz.png)

[![embedded-image-IcED3iNo.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/embedded-image-iced3ino.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-iced3ino.png)

Таким образом мы можем создавать чаты и манипулировать коллекциями как нам вздумается, всего одна строка кода, кто сазал что firebase это сложно?