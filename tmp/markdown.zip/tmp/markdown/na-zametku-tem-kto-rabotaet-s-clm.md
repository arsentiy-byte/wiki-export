# Книги > CLM для менеджера проектов > На заметку тем, кто работает с CLM

# На заметку тем, кто работает с CLM

**Полезность для менеджеров, работающих с презентациями.**

Если вдруг дизайнер занят, не может отвлечься или тому подобное, а вам нужно срочно выгрузить готовую презу в пдф, можно сделать это самостоятельно. Кто не знает, рассказываю способ:

1\. Для начала нужно сохранить скрины слайдов. Для этого выделяем все слайды разом и экспортируем в формате JPG. Экспорт в PDF или PNG приведёт к большому весу итогового файла.

Выбираем папку для сохранения и жмём "Сохранить".

[![скрин.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/skrin.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/skrin.jpeg)

[![142122098261e90488b49fe.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/142122098261e90488b49fe.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/142122098261e90488b49fe.jpeg)

2\. Открываем онлайн-конвертер, который может не только конвертировать отдельные файлы в PDF, но и собрать их сразу в один PDF-файл.  
[https://tools.pdf24.org/ru/merge-pdf](https://tools.pdf24.org/ru/merge-pdf)

Перетаскиваем наши слайды.  
В левой нижней части есть иконочка, выстраивающая файлы по порядку, но также можно переместить элементы вручную в любом порядке.

[![2.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/2.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/2.jpeg)

[![3.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/3.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/3.jpeg)

3\. Жмём "Создать ПДФ", чуточку ждём и можно "Скачать" результат (доступны и другие действия).

[![4.jpeg](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/4.jpeg)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/4.jpeg)

И Усё)