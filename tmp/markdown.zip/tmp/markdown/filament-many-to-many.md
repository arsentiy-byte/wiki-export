# Книги > PHP > Laravel > Filament: many-to-many

# Filament: many-to-many

Недавно столкнулся с тривиальной задачей "Сделать модуль со связкой". И так как в `filament` написан на базе `livewire`, у меня есть возможность сделать все по уму. То есть выборка, валидация все все все может быть динамичными.

### Контекст

Представьте, что есть база товаров (`Product`) и складов (`Stock`) и в пивотной таблице (`ProductStock`) нужно хранить количество товаров (`balance`) доступные в конкретном складе .

В проекте складов всего 2, поэтому я решил что, эти отношения должны редактироваться на странице карточки товара.


#### Описание моделей

В отрезке кода вы видите только методы, относящиеся к задаче.

Названия таблиц и внешних ключей заданы по правилу по умолчанию.

```php
class ProductStock extends Pivot
{
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function stock(): BelongsTo
    {
        return $this->belongsTo(Stock::class);
    }
}

class Product extends Model
{
    public function stocks(): BelongsToMany
    {
        return $this->belongsToMany(Stock::class)
            ->using(ProductStock::class)
            ->withPivot(['balance'])
            ->withTimestamps();
    }
}

class Stock extends Model
{
    public function products(): BelongsToMany
    {
        return $this->belongsToMany(Product::class)
            ->using(ProductStock::class)
            ->withPivot(['balance'])
            ->withTimestamps();
    }
}
```

#### Требования

- Важно чтоб в админке была валидация на уникальность отношении. И при попытке создать запись в `product_stock` с уже существующей парой (`product_id`, `stock_id`) должна выдаться ошибка на стороне админки, а не на стороне базы данных.
- Для того чтоб не держать в голове по какому складу у конкретного товара уже есть отношение, в выпадающем списке должны быть исключены существующие записи.
- Для удобства должна быть возможность изменить атрибут пивотной таблицы (product\_stock.balance). Без перепривязки (Detach -&gt; Attach).


### Решение

Начну с того, что решение, которое предлагает нам [документация](https://filamentphp.com/docs/2.x/admin/resources/relation-managers#attaching-and-detaching-records), не подходит. И в принципе `filament` еще не научился нормально работать с `BelongsToMany`.

Хорошо, что нам необязательно решать задачу идеально, и использовать именно many-to-many.

Предлагаю использовать one-to-many.

#### Добавим новое отношение

Новое отношение `productStocks` мне нужно только чтоб создать `RelationshipManager`.

```php
class Product extends Model
{
    public function stocks(): BelongsToMany
    {
        return $this->belongsToMany(Stock::class)
            ->using(ProductStock::class)
            ->withPivot(['balance'])
            ->withTimestamps();
    }
	
    public function productStocks(): HasMany
    {
        return $this->hasMany(ProductStock::class);
    }
}
```

#### Создаем `RelationshipManager`

В терминале вызываем команду для генераций (момент описания `ProductResource` решил пропустить):

`php artisan make:filament-relation-manager Product productStocks stock.address`

Я немножко подкорректировал и получилось вот это:

```php
class ProductStocksRelationManager extends RelationManager
{
    protected static string $relationship = 'productStocks';

    protected static ?string $recordTitleAttribute = 'stock.address';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('stock_id')
                    ->required()
                    ->integer(),

                Forms\Components\TextInput::make('balance')
                    ->required()
                    ->integer(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('stock.address')
                    ->label(trans('validation.attributes.address')),

                Tables\Columns\TextColumn::make('balance')
                    ->label(trans('validation.attributes.stock_balance'))
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }    
}
```

На данном этапе при созданий и редактирований записей в пивотной таблице появляется два числовых поля `stock_id` и `balance`, а `product_id` берется из открытой карточки.

[![ezgif.com-gif-maker.webp](https://wiki.rocketfirm.com/uploads/images/gallery/2023-03/ezgif-com-gif-maker.webp)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-03/ezgif-com-gif-maker.webp)

Отличное начало. Дальше остались только декоративные вещи.

#### Валидация

##### Наличие записи в таблице `stocks`

Здесь все очень просто

```php
public static function form(Form $form): Form
{
    return $form
        ->schema([
            Forms\Components\TextInput::make('stock_id')
                ->required()
                ->integer()
                ->exists('stocks', 'id'),

            Forms\Components\TextInput::make('balance')
                ->required()
                ->integer(),
        ]);
}
```

##### Уникальность

Нам нужно проверить чтоб при создании записи в таблице `product_stock` не было дубликатов по `product_id` и `stock_id`. Если по `stock_id` все понятно и просто берем из поля, то как быть с `product_id`? Как достать `id` товара у которого открыта страница редактирования?   
  
Берем из ссылки.  
  
Сперва нам нужно понять какие параметры доступны в Closure.

Покопавшись в коде, я узнал, что у всех компонентов формы в Closure передаются данные аргументы:

```php
protected function getDefaultEvaluationParameters(): array
{
    return array_merge(parent::getDefaultEvaluationParameters(), [
        'context' => $this->getContainer()->getContext(),
        'get' => $this->getGetCallback(),
        'livewire' => $this->getLivewire(),
        'model' => $this->getModel(),
        'record' => $this->getRecord(),
        'set' => $this->getSetCallback(),
        'state' => $this->shouldEvaluateWithState() ? $this->getState() : null,
    ]);
}
```

В данный момент параметр `$livewire` -- это объект нашего `RelationshipManager`. И в нем хранится запись товара которую мы открыли.

Как то так:

```php
public static function form(Form $form): Form
{
    return $form
        ->schema([
            Forms\Components\TextInput::make('stock_id')
                ->required()
                ->integer()
                ->exists('stocks', 'id')
                ->rule(
                	fn (RelationManager $livewire) => Rule::unique('product_stock', 'stock_id')
                  		->where('product_id', $livewire->ownerRecord->getKey())
                ),

            Forms\Components\TextInput::make('balance')
                ->required()
                ->integer(),
    ]);
}
```

Теперь у нас при попытке сделать какую-то грязь, в админке будут красивые сообщения ошибок:

[![r.webp](https://wiki.rocketfirm.com/uploads/images/gallery/2023-03/r.webp)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-03/r.webp)



#### Новая проблема

С такой валидацией при попытке отредактировать существующий запись в пивотной таблице, админка будет ругаться, что запись с такой `stock_id` уже существует:

  
[![r.webp](https://wiki.rocketfirm.com/uploads/images/gallery/2023-03/fyqr.webp)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-03/fyqr.webp)

#### Шаг назад

Давайте отключим проверку на уникальность и изменение `stock_id` при редактирований:

```php
public static function form(Form $form): Form
{
    return $form
        ->schema([
            Forms\Components\TextInput::make('stock_id')
                ->required()
                ->integer()
                ->exists('stocks', 'id')
                ->disabledOn('edit')
                ->rule(
                    fn (RelationManager $livewire) => Rule::unique('product_stock', 'stock_id')->where('product_id', $livewire->ownerRecord->getKey()),
                    fn (string $context) => $context !== 'edit'
                ),

            Forms\Components\TextInput::make('balance')
                ->required()
                ->integer(),
        ]);
}
```

Теперь при редактирований поле `stock_id` будет задизейблен и проверка на уникальность отключен.

#### Выпадающий список

Меня не устраивает, что нужно знать `id` склада наизусть.

Заменяем наше числовое поле на выпадающий список:

```php
public static function form(Form $form): Form
{
    return $form
        ->schema([
            Forms\Components\Select::make('stock_id')
                ->relationship('stock','address')
                ->required()
                ->exists('stocks', 'id')
                ->disabledOn('edit')
                ->rule(
                    fn (RelationManager $livewire) => Rule::unique('product_stock', 'stock_id')->where('product_id', $livewire->ownerRecord->getKey()),
                    fn (string $context) => $context !== 'edit'
                ),

            Forms\Components\TextInput::make('balance')
                ->required()
                ->integer(),
        ]);
}
```

Если оставить так, то в впадающем списке всегда будут все существующие склады. Нужно чтоб, существующие отношения были исключены.

Поступим так:  
Делаем запрос на список складов, у которых нет отношения с данным товаром, и при этом, в списке всегда должен присутствовать уже выбранный склад, если это редактирование:

```php
public static function form(Form $form): Form
{
    return $form
        ->schema([
            Forms\Components\Select::make('stock_id')
                ->options(
                    fn (callable $get, RelationManager $livewire) => Stock::query()
                    	->whereDoesntHave('products', fn (Builder $query) => $query
                                          ->where('products.id', $livewire->ownerRecord->getKey()))
                    ->orWhere('id', $get('stock_id'))
                    ->pluck('address', 'id')
                )
                ->required()
                ->exists('stocks', 'id')
                ->disabledOn('edit')
                ->rule(
                    fn (RelationManager $livewire) => Rule::unique('product_stock', 'stock_id')->where('product_id', $livewire->ownerRecord->getKey()),
                    fn (string $context) => $context !== 'edit'
                ),

            Forms\Components\TextInput::make('balance')
                ->required()
                ->integer(),
        ]);
}
```

### Результат

Получился удобный CRUD связки товар-склад, который не предлагает вариант, который вызовет ошибку.

А когда закончились варианты для складов, в выпадающем списке тоже пусто. Если это вас разочаровывает, можете динамически скрывать кнопку "Создать", если больше вариантов нет.

[![r.webp](https://wiki.rocketfirm.com/uploads/images/gallery/2023-03/g05r.webp)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-03/g05r.webp)