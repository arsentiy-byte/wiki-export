# Книги > Логотипы Rocket Firm Group > Holy Media: агентство диджитал-маркетинга

# Holy Media: агентство диджитал-маркетинга

PNG с прозрачным фоном

[![holy_media.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/holy-media.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/holy-media.png)