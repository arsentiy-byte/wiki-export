# Книги > DevOps > Настройка CI/CD для frontend > Добавление и настройка файла .gitlab-ci.yml

# Добавление и настройка файла .gitlab-ci.yml

В корень проекта добавляем файл `.gitlab-ci.yml`, внутри него требуется прописать команды, которые будут выполняться на сервере:

```shell
image: node:14.16.0
# Указываем версию node, которая используется в проекте.
```

Далее прописываем стадии деплоя, их две:

```shell
stages:
	- install
	- deploy
```

Первая стадия `install`, в этой команде перед выполнением скрипта отправляем запрос на установку пакетного менеджера Yarn и устанавливаем пакеты. После этого прописываем артефакты и пути. Далее настраиваем триггер для первой стадии, в данном случае это пуш в ветку `develop`

```shell
install:
 stage: install
 before_script:
   - curl -o- -L https://yarnpkg.com/install.sh | bash
   - export PATH="$HOME/.yarn/bin:$HOME/.config/yarn/global/node_modules/.bin:$PATH"
 script:
   - yarn install
 artifacts:
   name: 'artifacts'
   untracked: true
   expire_in: 30 mins
   paths:
     - .npm/
     - node_modules/
     - .yarn/
 only:
   refs:
     # - master
     - develop
```

Вторая стадия - непосредственно деплой `dev_deploy`. В этой стадии спуливаются изменения с ветки git и запускается докер контейнер. Благодаря именно этой стадии ваш код попадает на сервер

```shell
dev_deploy:
 stage: deploy
 before_script:
   - 'which ssh-agent || ( apt-get update -y && apt-get install openssh-client -y )'
   - mkdir -p ~/.ssh
   - eval $(ssh-agent -s)
   - '[[ -f /.dockerenv ]] && echo -e "Host *\n\tStrictHostKeyChecking no\n\n" > ~/.ssh/config'
   - ssh-add <(echo "$DEV_PRIVATE_KEY")
 script:
   #данная команда осуществляет слияние с удаленным репозиторием
   - ssh $USER@$DEV_HOST "cd $DEV_PATH && git pull"
   #данная команда собирает докер контейнер
   - ssh $USER@$DEV_HOST "cd $DEV_PATH && docker-compose build --no-cache"
   #данная команда поднимает докер контейнер
   - ssh $USER@$DEV_HOST "cd $DEV_PATH && docker-compose up -d"
   #данная команда удаляет ненужный мусор из контейнера
   - ssh $USER@$DEV_HOST "docker image prune -af"
 only:
   #настраиваем триггер на определенную ветку в Git (в данном случае develop)
   - develop
```