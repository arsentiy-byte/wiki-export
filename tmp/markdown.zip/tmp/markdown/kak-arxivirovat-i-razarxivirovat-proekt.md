# Книги > Jira > Управление проектами > Как архивировать и разархивировать проект

# Как архивировать и разархивировать проект

Чтобы архивировать проект, нужно назначить ему схему прав доступа ***Permission Scheme for Archived Projects***:

1. В режиме администратора проекта открываем проект, который хотим архивировать и в левом нижнем углу жмакаем на *"Параметры проекта"*.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/scaled-1680-/image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/image.png)

2\. В новом окне с настройками проекта находим раздел *"Права Доступа"*. Там переходим по ссылке в поле *"Схема"*

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/scaled-1680-/I6gimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/I6gimage.png)

3\. В новом окне с правой сторны находим выпадающее меню *"Действия"*, выбираем *"Использовать другую схему"*.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/scaled-1680-/Iuyimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/Iuyimage.png)

4\. В новом окне выбираем "*Permission Scheme for Archived Projects"* и нажимаем *"Ассоциировать"*.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/scaled-1680-/ZC3image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/ZC3image.png)

---

Чтобы разархивировать проект, нужно назначить ему схему прав доступа отличную от ***Permission Scheme for Archived Projects***:

Находим все архивированные проекты. Для нам нужно попасть в наши схемы разрешений. Это можно сделать несколькими путями   
1\. По [ссылке](https://jira.rocketfirm.com/secure/admin/ViewPermissionSchemes.jspa) перейти в писок разрешений или попасть туда переходя по страницам.  


1.1. Правое верхнее меню: "*Настройки" -&gt; "Задачи"* 

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/scaled-1680-/m6cimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/m6cimage.png)

1.2. В правом меню в самом низу находим *"Схемы прав доступа"* и переходим по ссылке  


[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/scaled-1680-/93Fimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/93Fimage.png)

1.3. В низу списка находим Схему "*Permission Scheme for Archived Projects"* и список привязанных к ней проектов. ВЫбираем нужный проект, перехоим в него по ссылке и меняем схему, например, на *"Default software scheme" по тому же принципу, как мы архивируем проект.*

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/scaled-1680-/JGBimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/JGBimage.png)

2\. По [ссылке](https://jira.rocketfirm.com/secure/project/BrowseProjects.jspa) прейти в администрирование проектов или попасть туда переходя по страницам.

2.1 Правое верхнее меню: "*Настройки" -&gt; "Проекты"*

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/scaled-1680-/kFeimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-01/kFeimage.png)

---

Референс:  
[https://jiraved.ru/admin-jira064/archiving-a-project](https://jiraved.ru/admin-jira064/archiving-a-project) раздел "Скрытие проекта"