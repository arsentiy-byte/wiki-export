# Книги > Mailgun в качестве SMTP шлюза > Mailgun в качестве SMTP сервера

# Mailgun в качестве SMTP сервера

Сервис может использоваться для отправки email-уведомлений пользователям через SMTP сервиса  
Зачем это нужно и почему нельзя отправлять уведомления с сервера проекта можно прочесть здесь:  
[https://www.unisender.com/ru/blog/idei/smtp-guide/](https://www.unisender.com/ru/blog/idei/smtp-guide/)

---

### Регистрация

Регистрируемся по ссылке  
[https://signup.mailgun.com/new/signup](https://signup.mailgun.com/new/signup)

При регистрации можно сразу привязать платежную карту

Без привязанной карты нельзя использовать собственный домен

Первые 3 месяца после регистрации дается по 5 тысяч писем бесплатно, затем потребуется перейти на платный тариф (от 35$)

### Подключение домена

Для подключения домена нужно проделать две вещи:  
1\. Добавить домен в панели Mailgun  
2\. Изменить настройки DNS домена

#### В Mailgun

В боковом меню выбираем **Sending,** затем **Domains** На открывшейся странице кликните **Add New Domain**

[![image-1645093561871.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645093561871.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645093561871.png)

В поле **Domain name** укажите имя домена. Рекомендуется для Mailgun создавать поддомен **mg.**

**Domain region** - US  
**DKIM key length** – 1024

[![image-1645093697057.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645093697057.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645093697057.png)

Далее через боковое меню переходим на страницу **Overview** Сверху в выпадающем списке выберите свой домен

[![image-1645094055293.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645094055293.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645094055293.png)

Здесь вы увидите настройки DNS, которые необходимо прописать для вашего домена

Перейдите в панель управления доменом и пропишите все указанные настройки по примеру ниже

Существующие MX-записи нужно удалить

[![image-1645094370229.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645094370229.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645094370229.png)

[![image-1645094397826.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645094397826.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645094397826.png)

[![image-1645094536825.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645094536825.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645094536825.png)

Когда завершите, перепроверьте все 5 записей и кликните **Обновить SOA**

[![image-1645094611598.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645094611598.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645094611598.png)

Обновление записей может занять до 2 суток, но обычно это происходит в течение нескольких часов

В Mailgun кликните **Verify DNS settings** чтобы проверить, обновились ли записи

[![image-1645095067284.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645095067284.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645095067284.png)

Когда все записи обновятся, на странице **Overview** вы увидите вот такое сообщение  
Это значит, что домен настроен и готов к работе

[![image-1645095148046.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645095148046.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645095148046.png)

### SMTP доступы

Когда домен подключен, перейдите на страницу **Domain Settings,** выберите вкладку **SMTP credentials**

По умолчанию будет создан SMTP-пользователь с логином **postmaster**   
Чтобы получить пароль, кликните **Reset password** или создайте нового SMTP-пользователя кнопкой **Add new SMTP-user**

[![image-1645095318126.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645095318126.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645095318126.png)

Подтвердите сброс пароля (или введите имя нового SMTP-пользователя)

[![image-1645095511569.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645095511569.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645095511569.png)

[![image-1645095971070.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645095971070.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645095971070.png)

После этого в нижнем правом углу появится уведомление с кнопкой **Copy**

Скопируйте пароль и сохраните где-нибудь, иначе придется снова сбрасывать его

[![image-1645095588773.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645095588773.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645095588773.png)

###   
Что передать разработчику

Разработчику нужен логин и пароль от SMTP-пользователя, а также адрес SMTP-сервера Mailgun (он один для всех проектов)

> smtp.mailgun.org  
> Our servers listen on ports 25, 587, and 465 (SSL/TLS)
> 
> **hello@site.kz**  
> **5h6412f8ja129345d711e9c140n6353#e-n3d1d1sb-313aa33n**