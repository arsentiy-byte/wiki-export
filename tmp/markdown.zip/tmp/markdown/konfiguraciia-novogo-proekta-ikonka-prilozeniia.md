# Книги > Archived > ROCKETFRONT-REACTNATIVE (ЧЕРНОВИК) > Конфигурация нового проекта :: Иконка приложения

# Конфигурация нового проекта :: Иконка приложения

#### **Создаем лого (1024x1024)**

[![image-1648665013527.30.10.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/scaled-1680-/image-1648665013527-30-10.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/image-1648665013527-30-10.png)

#### **Генерируем ресурсы** 

Сайт [AppIcon](https://appicon.co/#app-icon)

Импортируем картинку

[![image-1648665103757.31.39.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/scaled-1680-/image-1648665103757-31-39.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/image-1648665103757-31-39.png)

#### **Android**

Открываем папку android -&gt; app -&gt; src -&gt; main -&gt; res

Сгенерированные ресурсы внутри папки android переносим

#### **IOS**

Открываем папку ios -&gt; \[project name\] -&gt; Images.xcassets -&gt; AppIcon.appiconset

Сгенерированные ресурсы внутри папки AppIcon.appiconset переносим