# Книги > QA > DevTools > Console

# Console

В консоли можно увидеть предупреждения и ошибки, которые могут возникнуть при выполнении скриптов.

[![__2021-03-23__22.39.18.jpg](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/scaled-1680-/2021-03-23-22-39-18.jpg)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/2021-03-23-22-39-18.jpg)

Так же, часто в консоли можно увидеть отладочную информацию, которую разработчики выводят для себя.

[![__2021-02-25__11.43.51.jpg](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/scaled-1680-/2021-02-25-11-43-51.jpg)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/2021-02-25-11-43-51.jpg)