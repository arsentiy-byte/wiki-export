# Книги > Единый стандарт кода (PHP, Laravel) > Оформление API

# Оформление API

Инструкция по оформлению API метода пошагово.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/Xi1image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/Xi1image.png)

**В примере показано создание пользователя:**

##### Первый шаг. Создание RequestDTO класса

Создаем класс в директории `app/DTO/V1/User/CreateRequestDTO.php`

```php

     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ];
    }

    public function getDto(): CreateRequestDTO
    {
        return CreateRequestDTO::fromArray($this->validated());
    }
}

```

##### Третий шаг. Создание Handler класса

Создаем класс в директории `app/Handlers/V1/User/CreateHandler.php`

```php
create([
                'name' => $dto->name,
                'email' => $dto->email,
                'password' => Hash::make($dto->password),
            ]);

        return $user;
    }
}

```

##### Четвертый шаг. Создание Resource класса

Создаем класс в директории `app/Http/Resources/V1/User/UserResource.php`

```php
 $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'email_verified_at' => $this->email_verified_at?->toDateTimeString(),
            'is_active' => $this->is_active,
            'created_at' => $this->created_at->toDateTimeString(),
            'updated_at' => $this->updated_at->toDateTimeString(),
        ];
    }
}

```

##### Пятый шаг. Создание Controller класса

Создаем класс в директории `app/Http/Controllers/V1/UserController.php`

```php
handle($request->getDto());

        return $this->response(new UserResource($user), Response::HTTP_CREATED);
    }
}

```