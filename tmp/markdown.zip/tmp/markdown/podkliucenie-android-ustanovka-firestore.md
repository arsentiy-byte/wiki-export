# Книги > Archived > Live чат на Firebase > Подключение Android :: Установка firestore

# Подключение Android :: Установка firestore

**1.** На этом этапе все что нам осталось сделать это обратиться к firestore так как при запуске проекта подключение к firebase происходит автоматически, по средствам конфигурационного файла который мы скачали и тех зависимостий что мы прописали в наш gradle. Я использую готовый модуль установить который можно используя одну из команд ниже.

```
# Using npm
npm install --save @react-native-firebase/app

# Using Yarn
yarn add @react-native-firebase/app
```

  
  
**2.** После чего мы можем импортировать firestore из данной библиотеки и использовать его в своих целях

[![Screen Shot 2021-09-01 at 1.42.19 AM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-09-01-at-1-42-19-am.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-09-01-at-1-42-19-am.png)

**3.** Более детально по подключению самого чата и работы с ним я описывал в веб [версии данной](https://wiki.rocketfirm.com/books/live-chat-na-firebase/chapter/podklyuchenie-web) книги, там вы можете ознакомится с более детальным описанием по работе с самим чатом. Здесь же я скажу лишь что использовал готовое решение с [чатом ](https://github.com/FaridSafi/react-native-gifted-chat) и приведу ниже код который использовал на проекте созданом с нуля для теста, прям в файле App.js.

```
import React, {useState, useCallback, useEffect, useLayoutEffect} from 'react';
import {StyleSheet, Platform} from 'react-native';
import {GiftedChat} from 'react-native-gifted-chat';
import firestore from '@react-native-firebase/firestore';

const App = () => {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');

  useEffect(() => {
    const unsubscribe = firestore()
      .collection('Chats')
      .doc('1')
      .collection('messages')
      .orderBy('createdAt', 'desc')
      .onSnapshot(snapshot =>
        setMessages(
          snapshot.docs.map(doc => ({
            _id: doc.data()._id,
            createdAt: doc.data().createdAt.toDate(),
            text: doc.data().text,
            user: doc.data().user,
          })),
        ),
      );
    return unsubscribe;
  }, []);

  const onSend = useCallback((messages = []) => {
    setMessages(previousMessages =>
      GiftedChat.append(previousMessages, messages),
    );
    const {_id, text, createdAt, user} = messages[0];
    firestore()
      .collection('Chats')
      .doc('1')
      .collection('messages')
      .add({_id, text, createdAt, user});
  }, []);

  return (
     onSend(messages)}
      onInputTextChanged={setText}
      user={{
        _id: Platform.OS === 'ios' ? 1 : 2,
      }}
    />
  );
};

export default App;

const styles = StyleSheet.create({
  container: {paddingHorizontal: 10, flex: 1},
  card: {
    flex: 1,
    marginRight: 10,
    backgroundColor: '#c6c6c6',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardWrapper: {
    flexDirection: 'row',
  },
});

```

**4.** Ну и финальный результат выглядит вот так

[![Screen Shot 2021-08-31 at 11.47.55 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-47-55-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-47-55-pm.png)