# Книги > PPC > Медиапланирование > Отдел продаж

# Отдел продаж

#### [Таблица по всем проектам приходящим в отдел PPC по медиапланированию. ](https://docs.google.com/spreadsheets/d/1_Db3ZG-zkvjuUX6qIjXvt7Tg1ZCg5ogScUJRj5TeLCg/edit#gid=0)