# Книги > Archived > ROCKETFRONT-REACTNATIVE (ЧЕРНОВИК) > Конфигурация нового проекта :: Style Guide

# Конфигурация нового проекта :: Style Guide

### При конфигурации нового проекта, первое с чем мы должны ознакомится, это **Style Guide** 

Style Guide - это документ, который содержит в себе список элементов и правил, подходящих под стилистику конкретного проекта. Style Guide создается для разработчиков, и для того, чтобы дизайн в дальнейшем выглядел целостно и гармонично.

Для ее настройки в коробке используется сервис ThemeController   
src/services/ThemeController


#### **Шрифты и Типографика** 

/ThemeController/typography.ts

##### Дизайн

[![Screen Shot 2022-03-28 at 19.34.43.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/scaled-1680-/screen-shot-2022-03-28-at-19-34-43.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/screen-shot-2022-03-28-at-19-34-43.png)

##### Настройка

```JavaScript
export const FONTS = {
  Bold: 'Roboto-Bold',
  Light: 'Roboto-Light',
  Regular: 'Roboto-Regular',
}
```

#### Пример использования

```JavaScript
import { Text } from 'react-native-ui-lib'

H1 Text
H2 Text
H3 Text
P1 Text
P2 Text
S Text
```

Как можно заметить ключи из объекта TYPOGRAPHY можно использовать для применения стиля 

#### **Цвет**

**/ThemeController/colors.ts**

##### Дизайн

[![Screen Shot 2022-03-28 at 19.33.57.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/scaled-1680-/screen-shot-2022-03-28-at-19-33-57.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/screen-shot-2022-03-28-at-19-33-57.png)

##### Настройка

##### Пример использования


#### **Spacings** - это часто повторяющие расстояния в дизайне, например расстояние от экрана 24px

**/ThemeController/spacings.ts**

##### Настройка

```JavaScript
import { verticalScale } from 'react-native-size-matters'

export const SPACINGS = {
  container: verticalScale(24),
}
```

Как можно заметить используется verticalScale, подробнее можно ознакомится на странице [Работа с адаптивными размерами](https://wiki.rocketfirm.com/books/archived/page/rabota-s-adaptivnymi-razmerami)

##### Пример использования

```JavaScript
import { View } from 'react-native-ui-lib'




```

Как можно заметить ключи из объекта SPACINGS можно использовать для применения margin и padding 


#### **Компоненты**

**/ThemeController/uilib-components.ts**

Для базовых компонентов, такие как, Текст, Кнопки, Инпуты и.т.д используется [react-native-ui-lib](https://wix.github.io/react-native-ui-lib/)

##### Настройка

```JavaScript
import { ThemeManager, Incubator } from 'react-native-ui-lib'
import { verticalScale } from 'react-native-size-matters'
import { TYPOGRAPHY } from './typography'

const { TextField } = Incubator

ThemeManager.setComponentTheme('Text', {
  p1: true,
})

ThemeManager.setComponentTheme('Incubator.TextField', () => ({
  fieldStyle: {
    backgroundColor: '#F4F5F7',
    borderRadius: 50,
    width: '100%',
    borderWidth: 0,
    height: verticalScale(56),
    paddingHorizontal: verticalScale(24),
  },
  style: {
    fontSize: verticalScale(15),
  },
  validationMessagePosition: TextField.validationMessagePositions.BOTTOM,
  validationMessageStyle: {
    ...TYPOGRAPHY.s,
    paddingLeft: verticalScale(24),
    paddingTop: verticalScale(5),
  },
}))

```



#### **Иконки**

Для работы с иконками коробка использует библиотеку react-native-svg

Путь assets/icons

##### Дизайн

[![Screen Shot 2022-03-28 at 19.53.29.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/scaled-1680-/screen-shot-2022-03-28-at-19-53-29.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/screen-shot-2022-03-28-at-19-53-29.png)

##### Настройка

Путь assets/icons/SearchIcon

```JavaScript
import React, { FC } from 'react'
import Svg, { Path } from 'react-native-svg'

export const SearchIcon: FC = (props) => {
  const width = 24
  const height = 24
  const size = props.size || width

  return (
    
      
    
  )
}
```

##### Пример использования

```JavaScript
import { SearchIcon } from "icons/SearchIcon";


```