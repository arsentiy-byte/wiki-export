# Книги > PHP > Laravel > Инструкция по написанию комментариев

# Инструкция по написанию комментариев

Вся документация ведется в Swagger, для удобства и актуализации используется пакет [DarkaOnLine / L5-Swagger](https://github.com/DarkaOnLine/L5-Swagger), который генерирует документацию на основании комментариев.

#### Раздел Info, Servers, Tags, SecurityScheme

В первую очередь добавляются комментарии для формирования раздела [Info](https://wiki.rocketfirm.com/link/240#bkmrk-%D0%A0%D0%B0%D0%B7%D0%B4%D0%B5%D0%BB%C2%A0info%C2%A0--%D0%BE%D0%BF%D0%B8%D1%81%D0%B0%D0%BD), [Servers](https://wiki.rocketfirm.com/link/240#bkmrk-%D0%A0%D0%B0%D0%B7%D0%B4%D0%B5%D0%BB%C2%A0servers%C2%A0--%D0%B0%D0%B4%D1%80). Тут же есть комментарии для тегов ([Tag](https://wiki.rocketfirm.com/link/240#bkmrk-%D0%A0%D0%B0%D0%B7%D0%B4%D0%B5%D0%BB%C2%A0tags---%D1%82%D0%B5%D0%B3%D0%B8-%D0%B7)) и авторизации ([SecurityScheme](https://wiki.rocketfirm.com/link/240#bkmrk-%D0%A0%D0%B0%D0%B7%D0%B4%D0%B5%D0%BB%C2%A0components%C2%A0--)). Чаще всего этот код храниться в общем контроллере app/Http/Controllers/Controller.php

Код комментария

```PHP
/**
   * @OA\Info(
   *      version="1.0.0",
   *      title="Grabglide Api documentation",
   *      description="API for app",
   * )
   *
   * @OA\Server(
   *      url=L5_SWAGGER_CONST_HOST,
   *      description="Stage Server"
   * )
   *
   * @OA\Tag(
   *     name="Users.Common",
   *     description="API Endpoints of Users"
   * )
   * @OA\SecurityScheme(
   *     description="Токен авторизации",
   *     type="http",
   *     scheme="bearer",
   *     securityScheme="bearerAuth"
   * )
   */

class Controller extends BaseController{}
```

Результат yaml

```YAML
openapi: 3.0.0
info:
  title: 'Grabglide Api documentation'
  description: 'API for app'
  version: 1.0.0
servers:
  -
    url: 'https://grabglide.test/api'
    description: 'Stage Server'

tags:
  -
    name: Users.Common
    description: 'API Endpoints of Users'
```

#### Раздел components/schema

Далее описываются схемы, которые будут частью компонентов. [Schema](https://wiki.rocketfirm.com/link/240#bkmrk-%D0%A0%D0%B0%D0%B7%D0%B4%D0%B5%D0%BB%C2%A0components%C2%A0--) в Swagger это модель данных, поэтому храниться такие комментарии будут в модели, например app/Models/City.php. Атрибуты(Property) модели могут отличаться от тех что указаны в комментариях, такое может быть если API возвращает не все данные модели.

Код комментария

```PHP
/**
 * @OA\Schema(
 *     title="City",
 *     description="City model",
 *     type="object",
 *     @OA\Property(
 *       property="ID",
 *            description="ID",
 *            type="integer",
 *            format="int64"
 *        ),
 *    @OA\Property(
 *            property="title",
 *            description="название",
 *            type="string"
 *        ),
 *     @OA\Property(
 *            property="long",
 *            description="долгота",
 *            type="number",
 *            format="float"
 *        ),
 *     @OA\Property(
 *            property="lat",
 *            description="ширина",
 *            type="number",
 *            format="float"
 *        ),
 *     @OA\Property(
 *            property="state",
 *            description="штат",
 *            type="string"
 *        ),
 *     @OA\Property(
 *            property="is_active",
 *            description="активность",
 *            type="boolean"
 *        ),
 *     @OA\Xml(
 *         name="City"
 *     )
 * )
 */

class City extends Model{}
```

Результат yaml

```YAML
components:
  schemas:
    City:
      title: City
      description: 'City model'
      properties:
        ID:
          description: ID
          type: integer
          format: int64
        title:
          description: название
          type: string
        long:
          description: долгота
          type: number
          format: float
        lat:
          description: ширина
          type: number
          format: float
        state:
          description: штат
          type: string
        is_active:
          description: активность
          type: boolean
      type: object
      xml:
        name: City
```

#### Раздел components/requestBodies

Для описания тела запроса можно использовать так же компоненты. Чаще всего комментарии для requestBodies хранятся в файлах Requests, например app/Http/Requests/CompanyRequests.php

Код комментария

```PHP
/**
 *
 * @OA\RequestBody(
 *     request="Company",
 *     required=true,
 *     @OA\JsonContent(
 *            type="object",
 *        @OA\Property(
 *                property="title",
 *                description="Название",
 *                type="string"
 *            ),
 *          @OA\Property(
 *                property="description",
 *                description="описание",
 *                type="string"
 *            ),
 *          @OA\Property(
 *                property="crew",
 *                description="экипаж",
 *                type="string"
 *            ),
 *          @OA\Property(
 *                property="logo",
 *                description="логотип",
 *                type="string",
 *            ),
 *          @OA\Property(
 *                property="address",
 *                description="адрес",
 *                type="string"
 *            ),
 *          @OA\Property(
 *                property="email",
 *                description="email",
 *                type="string",
 *            ),
 *       @OA\Property(
 *                property="phone",
 *                description="телефон",
 *                type="string",
 *            ),
 *            @OA\Property(
 *                property="city_id",
 *                description="ID города ",
 *                type="integer",
 *               format="int64"
 *            ),
 *          @OA\Property(
 *                property="rating",
 *                description="рейтинг",
 *                type="number",
 *               format="float"
 *            ),
 *            @OA\Property(
 *                property="allow_animals",
 *                description="Согласие на перевозку животных",
 *                type="boolean"
 *            ),
 *     )
 * )
 */
```

Результат yaml

```YAML
requestBodies:
  Company:
    required: true
    content:
      application/json:
        schema:
          properties:
            title:
              description: Название
              type: string
            description:
              description: описание
              type: string
            crew:
              description: экипаж
              type: string
            logo:
              description: логотип
              type: string
            address:
              description: адрес
              type: string
            email:
              description: email
              type: string
            phone:
              description: телефон
              type: string
            city_id:
              description: 'ID города '
              type: integer
              format: int64
            rating:
              description: рейтинг
              type: number
              format: float
            allow_animals:
              description: 'Согласие на перевозку животных'
              type: boolean
          type: object
```

После можно использовать компоненты чтобы ссылаться на них в разделе Path  
Пример ссылки на тело запроса

`requestBody={"$ref": "#/components/requestBodies/Company"}`

Пример ссылки на модель в списке

`@OA\Items(ref="#/components/schemas/Company")`

Пример ссылки на 1 модель

`ref="#/components/schemas/City"`

#### Раздел Path

Endpoint-ы описываются в контролерах, каждый endpoint должен располагаться над соответствующей функцией. Если отсутствуют функции для каждого endpoint, например подключен пакет json api, то можно описать все endpoint-ы в одном комментарии.

##### GЕT запросы

Пример GET запроса, без входящих параметров.

Код комментария

```PHP
/**
 * @OA\Get(
 *    path="/cities",
 *    operationId="cityIndex",
 *      tags={"Cities.Common"},
 *      summary="Список всех городов",
 *      description="Возращает cписок всех городов",
 *      @OA\Response(
 *          response=200,
 *          description="cписок городов",
 *          @OA\JsonContent(
 *              type="object",
 *               @OA\Property(
 *             property="success",
 *             type="boolean",
 *                 default=true
 *              ),
 *          @OA\Property(
 *             property="data",
 *             type="array",
 *                 @OA\Items(ref="#/components/schemas/City")
 *              )
 *          )
 *      ),
 *     @OA\Response(
 *          response=404,
 *          description="Invalid data"
 *      )
 * )
 */
```

Результат yaml

```YAML
/cities:
  get:
    tags:
      - Cities.Common
    summary: 'Список всех городов'
    description: 'Возращает cписок всех городов'
    operationId: cityIndex
    responses:
      200:
        description: 'cписок городов'
        content:
          application/json:
            schema:
              properties:
                success:
                  type: boolean
                  default: true
                data:
                  type: array
                  items:
                    $ref: '#/components/schemas/City'
              type: object
      404:
        description: 'Invalid data'
```

В разделе @OA\\Response описываются примеры ответов, так же можно указать ссылку на schema, как было описано [выше](https://wiki.rocketfirm.com/link/248#bkmrk-%D0%A0%D0%B0%D0%B7%D0%B4%D0%B5%D0%BB-components%2Fsc), если endpoint возвращает целую модель.

Если GET запрос принимает какие-то параметры, то они описываются в разделе @OA\\Get. Пример запроса на [http://project.com/cities/1](http://project.com/cities/1)

Код комментария

```PHP
/**
 * @OA\Get(
 *    path="/cities/{id}",
 *    operationId="cityShow",
 *      tags={"Cities.Common"},
 *      summary="Модель города",
 *      description="Возращает модель города",
 *         @OA\Parameter(
 *          name="id",
 *          description="Id города",
 *          required=true,
 *          in="path",
 *          @OA\Schema(
 *              type="integer"
 *          )
 *      ),
 *      @OA\Response(
 *          response=200,
 *          description="модель города",
 *          @OA\JsonContent(
 *              type="object",
 *               @OA\Property(
 *             property="success",
 *             type="boolean",
 *                 default=true
 *              ),
 *          @OA\Property(
 *                  property="data",
 *                  ref="#/components/schemas/City"
 *              )
 *          )
 *      ),
 *     @OA\Response(
 *          response=404,
 *          description="Model not found"
 *      )
 * )
 */
```

Результат yaml

```YAML
'/cities/{id}':
  get:
    tags:
      - Cities.Common
    summary: 'Модель города'
    description: 'Возращает модель города'
    operationId: cityShow
    parameters:
      -
        name: id
        in: path
        description: 'Id города'
        required: true
        schema:
          type: integer
    responses:
      200:
        description: 'модель города'
        content:
          application/json:
            schema:
              properties:
                success:
                  type: boolean
                  default: true
                data:
                  $ref: '#/components/schemas/City'
              type: object
      404:
        description: 'Model not found'
```

##### POST запросы

Примеры POST запроса. Тело запроса может быть разного типа и в зависимости от него в swagger будет разное отображение:

- multipart/form-data

[![image-1628240393986.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/image-1628240393986.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/image-1628240393986.png)

- application/json

[![image-1628240401884.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/image-1628240401884.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/image-1628240401884.png)

Пример POST с телом запроса типа multipart/form-data

Код комментария

```PHP
/**
 * @OA\Post(
 *    path="/login",
 *    operationId="loginClient",
 *      tags={"Users.Client"},
 *      summary="Вход пользователя",
 *      description="Возращает токен для авторизации",
 *      @OA\RequestBody(
 *       required=true,
 *       @OA\MediaType(
 *          mediaType="multipart/form-data",
 *          @OA\Schema(
 *             type="object",
 *                  @OA\Property(
 *                      property="phone",
 *                      description="phone",
 *                      type="string"
 *                  ),
 *                  @OA\Property(
 *                      property="password",
 *                      description="пароль",
 *                      type="string",
 *                     format="password"
 *                  )
 *              )
 *          )
 *      ),
 *      @OA\Response(
 *          response=200,
 *          description="данные пользователя",
 *            @OA\JsonContent(
 *              type="object",
 *               @OA\Property(
 *             property="success",
 *             type="boolean",
 *                 default=true
 *              ),
 *          @OA\Property(
 *             property="data",
 *                  type="object",
 *                 @OA\Property(
 *                        property="access_token",
 *                        type="string"
 *                 ),
 *                 @OA\Property(
 *                        property="token_type",
 *                        type="string"
 *                 )
 *              )
 *          )
 *      ), 
 *      @OA\Response(
 *          response=403,
 *          description="Forbidden"
 *      )
 * )
 */
```

Результат yaml

```YAML
/login:
  post:
    tags:
      - Users.Client
    summary: 'Вход пользователя'
    description: 'Возращает токен для авторизации'
    operationId: loginClient
    requestBody:
      required: true
      content:
        multipart/form-data:
          schema:
            properties:
              phone:
                description: phone
                type: string
              password:
                description: пароль
                type: string
                format: password
            type: object
    responses:
      200:
        description: 'данные пользователя'
        content:
          application/json:
            schema:
              properties:
                success:
                  type: boolean
                  default: true
                data:
                  properties:
                    access_token:
                      type: string
                    token_type:
                      type: string
                  type: object
              type: object
      403:
        description: Forbidden
```

Пример POST с телом запроса типа application/json

Код комментария

```PHP
/**
   *   @OA\Post(
   *      path="/companies/my",
   *      operationId="companyUpdate",
   *      tags={"Companies.Business"},
   *      summary="Изменение модели компании пользователя по токену",
   *      description="Возращает измененную модель компании принадлежащей пользователю",
   *      requestBody={"$ref": "#/components/requestBodies/Company"},
   *      @OA\Response(
   *          response=200,
   *          description="Изменение модели компании",
   *          @OA\JsonContent(
   *              type="object",
   *             @OA\Property(
   *               property="success",
   *               type="boolean",
   *               default=true
   *              ),
   *            @OA\Property(
   *               property="data",
   *               type="array",
   *               @OA\Items(ref="#/components/schemas/Company")
   *              )
   *          )
   *      ),
   *     @OA\Response(
   *          response=401,
   *          description="Неавторизированный пользователь"
   *      ),
   *     @OA\Response(
   *          response=404,
   *          description="Invalid data"
   *      ),
   *     security={{"bearerAuth": {}}}
   *   )
```

Результат yaml

```YAML
/companies/my:
  get:
    tags:
      - Companies.Business
    summary: 'Модель компании пользователя'
    description: 'Возращает модель компании принадлежащей пользователю'
    operationId: companyShow
    responses:
      200:
        description: 'модель компании'
        content:
          application/json:
            schema:
              properties:
                success:
                  type: boolean
                  default: true
                data:
                  $ref: '#/components/schemas/Company'
              type: object
      401:
        description: 'Неавторизированный пользователь'
      404:
        description: 'Invalid data'
    security:
      -
        bearerAuth: []
```

В разделе @OA\\Post так же можно указать ссылку на requestBodies, как было описано [выше](https://wiki.rocketfirm.com/link/248#bkmrk-%D0%A0%D0%B0%D0%B7%D0%B4%D0%B5%D0%BB-components%2Fre).

#### Авторизация

Для указания того что endpoint требует авторизацию используется атрибут security

`security={{"bearerAuth": {}}}`

Это значит что endpoint доступен только по токену авторизации и в swagger-e помечается замком

[![image-1628240807408.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/image-1628240807408.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/image-1628240807408.png)

Источники:

1. [https://swagger.io/docs/](https://swagger.io/docs/)
2. [https://zircote.github.io/swagger-php/#links](https://zircote.github.io/swagger-php/#links)