# Книги > Mattermost > Функциональность > Настройка уведомлений в MatterMost

# Настройка уведомлений в MatterMost

##### Для того чтобы настроить получение уведомлений в Mattermost как на Десктоп клиенте так и на мобильном вам нужно выполнить несколько шагов.  
  
**1) Заходим в настройки**  


[![Screenshot_6.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/screenshot-6.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/screenshot-6.png)

##### **2) Выбираем вкладку уведомления, и кликаем на кнопку изменить**

[![Screenshot_7.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/screenshot-7.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/screenshot-7.png)

##### **3) Выбираем нужную опцию**

**На выбор доступно несколько опций:**  
***All new messages -** При выборе опции **"All new messages"**, на ваше устройство будут поступать уведомления обо всех новых сообщениях, которые приходят в **MM:** публичные и приватные группы, в которых вы состоите, личные сообщения, треды и другие каналы.  
  
**Mentions, direct messages... -** при выборе данной опции "Упоминания и личные сообщения", на ваше устройство будут поступать уведомления только о сообщениях, в которых вас упомянули, а также о личных сообщениях и сообщениях из тредов, которые вы отслеживаете.  
  
**Nothing** - при выборе этой опции уведомления не будут приходить вовсе*

[![Screenshot_8.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/screenshot-8.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/screenshot-8.png)

**Так же есть опции которые отвечают за триггер к уведомлению т.е:**  
***Online, away, or offline -** опция отвечает за то чтобы уведомление приходили вам всегда (Когда вы онлайн, оффлайн, или имеете статус отошёл)  
  
**Away or offline -** Опция, при которой уведомления будут приходить только в случае, если вы находитесь оффлайн или отошли (состояние "отошел" определяется как отсутствие активности в запущенном приложении в течение длительного времени).*

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/Gwbimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/Gwbimage.png)

##### **4) Передача настроек на мобильное приложение** 

*Вы можете настроить уведомления в моб. приложении из приложения на десктопе, просто отметив данный чек-бокс и выбрав нужные опции, либо же через настройку уведомлений в самом приложении **MM** на смартфоне*

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/Hihimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/Hihimage.png)