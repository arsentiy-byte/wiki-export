# Книги > Archived > Live чат на Firebase > Подключение Android :: Инициализация для android

# Подключение Android :: Инициализация для android

**1.** В первую очередь хочу сказать что необходимо уже иметь аккаунт [https://firebase.google.com](https://firebase.google.com) более подробная инициализация была описана в [WEB](https://wiki.rocketfirm.com/books/live-chat-na-firebase/chapter/podklyuchenie-web) главе этой книги.

**2.** После создания так сказать проекта - кластера у нас сформируется панель с возможностью добавления инстанций приложений, как веб так и всех остальных. Нас интересует в данном случае андроид кликаем по созданию приложения и выбираем андроид. В списке слева так же будут показанны те приложения для которых вы уже делали конфиги.

[![Screen Shot 2021-08-31 at 11.01.38 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-01-38-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-01-38-pm.png)

[![Screen Shot 2021-08-31 at 11.02.08 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-02-08-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-02-08-pm.png)