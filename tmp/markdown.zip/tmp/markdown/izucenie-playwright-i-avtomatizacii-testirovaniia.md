# Книги > QA > Автоматизация тестирования > Изучение Playwright и автоматизации тестирования

# Изучение Playwright и автоматизации тестирования

Стоит обратить внимание на два момента:

1\) Стоит обратить внимание на модуль [Test Generator,](https://playwright.dev/docs/codegen-intro) запуск которого позволяет генерировать строки кода файлов автотеста отслеживая действия пользователя: переход на сайт, клики мышкой по элементам, ввод данных в поля и т. д.

2\) Использование библиотеки Playwright для простых сайтов не требует глубокого изучения языков программирования (TypeScript или JavaScript) - основные языковые конструкции показаны в [документации](https://playwright.dev/), но особое внимание стоит уделить поиску элементов на страницах по их "[локаторам](https://habr.com/ru/companies/skyeng/articles/588282/)".

Полезные ссылки:

- [Документация](https://playwright.dev/) (на английском) от разработчиков библиотеки Playwright.
- [Youtube-канал](https://www.youtube.com/@Playwrightdev) разработчиков библиотеки и ознакомительный [плейлист](https://www.youtube.com/watch?v=Xz6lhEzgI5I&list=PLQ6Buerc008dhme8fC80zmhohqpkA0aXI) (на английском). Перевод на русский можно включить с помощью [закадрового переводчика от Яндекс](https://yandex.ru/blog/company/smotrite-po-russki-yandeks-zapustil-zakadrovyy-perevod-video#:~:text=%D0%9E%D1%82%D0%BA%D1%80%D0%BE%D0%B9%D1%82%D0%B5%20%D0%B0%D0%BD%D0%B3%D0%BB%D0%BE%D1%8F%D0%B7%D1%8B%D1%87%D0%BD%D1%8B%D0%B9%20%D1%80%D0%BE%D0%BB%D0%B8%D0%BA,%20%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D1%8B%D0%B9%20%D0%B2%D1%8B,%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%BE%D0%B4%D0%B0,%20%D0%B4%D0%BE%D1%81%D1%82%D0%B0%D1%82%D0%BE%D1%87%D0%BD%D0%BE%20%D0%BD%D0%B0%D0%B6%D0%B0%D1%82%D1%8C%20%D0%BD%D0%B0%20%D0%BA%D0%BD%D0%BE%D0%BF%D0%BA%D1%83).
- Обзор основных функций библиотеки Playwright из официальной документации (на русском): [https://testengineer.ru/playwright-tutorial/](https://testengineer.ru/playwright-tutorial/).
- [Гайд по локаторам](https://habr.com/ru/companies/skyeng/articles/588282/) на habr (на русском).
- Сайт для тренировки автотестеров [https://demoqa.com](https://demoqa.com) , содержащий различные web-элементы.

по изучению javascript есть большое множество различны ресурсов например:

- сайт [h](https://demoqa.com)[ttps://learn.javascript.ru ](https://learn.javascript.ru/)
- видео [https://www.youtube.com/channel/UCP-xJwnvKCGyS-nbyOx1Wmg](https://www.youtube.com/channel/UCP-xJwnvKCGyS-nbyOx1Wmg)
- видео [https://www.youtube.com/playlist?list=PLqKQF2ojwm3l4oPjsB9chrJmlhZ-zOzWT](https://www.youtube.com/playlist?list=PLqKQF2ojwm3l4oPjsB9chrJmlhZ-zOzWT)
- видео [https://www.youtube.com/watch?v=fcMcf\_4PjfI](https://www.youtube.com/watch?v=fcMcf_4PjfI)

  
курсы по playwright на английском:

- много js [https://www.youtube.com/watch?v=yIYGurn-76Y&amp;list=PLFGoYjJG\_fqrim-B3TE34Tbr8cdWMYtH7](https://www.youtube.com/watch?v=yIYGurn-76Y&list=PLFGoYjJG_fqrim-B3TE34Tbr8cdWMYtH7)
- основы playwright [https://www.youtube.com/watch?v=4\_m3HsaNwOE&amp;list=PLhW3qG5bs-L9sJKoT1LC5grGT77sfW0Z8](https://www.youtube.com/watch?v=4_m3HsaNwOE&list=PLhW3qG5bs-L9sJKoT1LC5grGT77sfW0Z8)
- основательное погружение в playwright  
    [https://www.youtube.com/watch?v=wawbt1cATsk&amp;list=PLZMWkkQEwOPlS6BSWWqaAIrSNf\_Gw4MQ1](https://www.youtube.com/watch?v=wawbt1cATsk&list=PLZMWkkQEwOPlS6BSWWqaAIrSNf_Gw4MQ1) [https://www.youtube.com/watch?v=yOuElUSfAs8&amp;list=PLUDwpEzHYYLsw33jpra65LIvX1nKWpp7-](https://www.youtube.com/watch?v=yOuElUSfAs8&list=PLUDwpEzHYYLsw33jpra65LIvX1nKWpp7-)