# Книги > Настройка и работа в Jira > Порядок

# Порядок

Перед началом работы в Jira, ей необходимо задать название и оформление, это полезно как и для себя, так и для и всей команды.  
  
Начнем с самого простого, с названия и оформления вашей доски.   
  
Представим, вас добавили в ваш первый проект, по сути он голый и выглядит таким образом:

[![Снимок экрана 2023-08-17 в 15.11.48.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/scaled-1680-/snimok-ekrana-2023-08-17-v-15-11-48.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/snimok-ekrana-2023-08-17-v-15-11-48.png)

Первым делом, необходимо привести его в порядок, задать название и добавить лого.

1\. Заходим в параметры проекта:

[![Снимок экрана 2023-08-17 в 15.12.03.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/scaled-1680-/snimok-ekrana-2023-08-17-v-15-12-03.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/snimok-ekrana-2023-08-17-v-15-12-03.png)

2\. Переходим во вкладку "Детали", и заполняем название, ссылку, аватар + описание.  
  
[![Снимок экрана 2023-08-17 в 15.13.30.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/scaled-1680-/snimok-ekrana-2023-08-17-v-15-13-30.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/snimok-ekrana-2023-08-17-v-15-13-30.png)

3\. Формат заполнения достаточной простой:

– Название: Название проекта (можно сокращенно или неполное, например Bank Center Credit, можно сократить до BCC), второй строкой, дайте понимание о чем ваш проект, например "Мобильное Приложение"), как итог – BCC :: Приложение;  
– URL;  
– Выбираем логотип клиента, нужно чтоб не путаться в большом кол-ве проектов и визуально ориентироваться среди ваших досок;  
– Короткое описание проекта (по желанию).

[![Снимок экрана 2023-08-17 в 15.15.05.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/scaled-1680-/snimok-ekrana-2023-08-17-v-15-15-05.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2023-08/snimok-ekrana-2023-08-17-v-15-15-05.png)

\_\_\_  
  
Готово, теперь ваша доска оформлена, время приглашать команду – [https://wiki.rocketfirm.com/books/nastroika-i-rabota-v-jira/page/ispolniteli](https://wiki.rocketfirm.com/books/nastroika-i-rabota-v-jira/page/ispolniteli)