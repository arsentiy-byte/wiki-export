# Книги > DevOps > Continuous Deployment в «Ракетной» (архивное)

# Continuous Deployment в «Ракетной» (архивное)

Для сокращения возни с сервером [rocketfirm.net](http://rocketfirm.net/) и [makers.kz](http://makers.kz/) в консоли и прозрачности всех процессов, в начале этого года было решено переехать на панель Plesk.

Plesk уже имеет систему UNIX-пользователей, рушить которую нельзя. Работать под рутом — вообще запрет (кроме ограниченного числа случаев). Для этого было решено проапгрейдить систему разворачивания проектов.

### Пару слов о Continuous Deployment

Цель Continuous Deployment — сократить время, которое разработчику необходимо, чтобы код, который он пишет, попал к конечному пользователю. По пути добавляются такие плюсы как удобный интерфейс для отката и логи развёрток, т.е. прозрачность.

[![](https://intra.rocketfirm.com/media/page_image/wg/1521459754130mn.png)](https://intra.rocketfirm.com/media/page_image/wg/1521459754130mn.png)Интерфейс CI/CD тестового проекта

В качестве тестового проекта покажу вам новую админку:

[bridge-demo.makers.kz](https://bridge-demo.makers.kz/) — Боевой сервер

[bridge-demo.hipster.kz](https://bridge-demo.hipster.kz/) — Тестовый сервер

[gitlab.com/rocketfirm/bridge-demo/-/jobs](https://gitlab.com/rocketfirm/bridge-demo/-/jobs) — Список деплоев

### Как теперь деплоить?

Для запуска скрипта нужно лишь «запушить» изменения в ветку (`master` для **production** сервера, `develop` для **stage** сервера.

Однако перед этим, нужно добавить соответствующие SSH-ключи и включить файлы deploy.php и .gitlab-ci.yml (по файлам инфа ниже).

[![](https://intra.rocketfirm.com/media/page_image/tn/1523529815pfbto.png)](https://intra.rocketfirm.com/media/page_image/tn/1523529815pfbto.png)

Сервер, ответственный за все развёртки (Gitlab-Runner) находится в подсобке у дизайнеров. Инфа по нему находится в этой [карточке Трелло](https://trello.com/c/zcHaSNxN/33-gitlab-runner).

### Сервер staging/stage

Зачем нужен сервер **staging**? Какая разница с **dev**?

Разница в том, что **staging** сервер — это такой же **production**, но для тестов. По сути и есть тестовый сервер.

В рамках инфраструктуры ракетной было принято называть серверы так:

- **production** — боевой сервер. По умолчанию — [makers.kz](https://wiki.rocketfirm.com/makers.kz).
- **stage** — сервер для прогона перед боем. По умолчанию — новый [rocketfirm.net](http://rocketfirm.net/).

Можно создать **dev** окружение для своих тестов, менеджерам и клиентам отдаем stage.

### Deploy скрипт

Сам deploy скрипт не особо меняется (за исключением пользователей, под которым производится deploy). Все изменения уже находятся в обновленном шаблоне админки тут — [github.com/naffiq/yii2-app-bridge](https://github.com/naffiq/yii2-app-bridge).

Скрипт ниже можно копипастить :)

```
deploy.php 

stage('prod')
//         ->user($userProduction)
//         ->set('branch', 'master')
//         ->set('deploy_path', '/var/www/www-root/data/www/algosglobal.com')
//         ->set('keep_releases', 5);

host('rocketfirm.net')
        ->stage('stage')
        ->user($userStage)
        ->set('branch', 'develop')
        ->set('deploy_path', '/var/www/vhosts/rocketfirm.net/science2.rocketfirm.net') //Путь деплоя 
        ->set('keep_releases', 2);

// Tasks
task('deploy:config', function () {
    $stage = get('stage');
    run("echo '{$stage}' > {{release_path}}/config/mode.php");
    run("cat {{release_path}}/config/mode.php");
})->desc('Set application stage config');
after('deploy:update_code', 'deploy:config');

task('deploy:chmod', function () {
    run("chmod 0777 {{release_path}}/yii");
})->desc('Set application stage config');
after('deploy:config', 'deploy:chmod');

task('deploy:vendors', function () {
    if (commandExist('composer'))
    {
        $composer = 'composer';
    }
    else
    {
        run("cd {{release_path}} && curl -sS https://getcomposer.org/installer | /opt/php70/bin/php");
        $composer = '/opt/php70/bin/php composer.phar';
    }

    run("cd {{release_path}} $composer install --no-dev --verbose --prefer-dist --optimize-autoloader --no-progress --no-interaction");
})->desc('Installing vendors');

task('deploy:run_migrations', function () {
    $stage = get('stage');
    if ($stage == 'prod')
    {
        run('/opt/php70/bin/php {{release_path}}/yii migrate --interactive=0');
    }
    else
    {
        run('cd {{release_path}} && ./vendor/bin/bridge-install');
    }

})->desc('Run migrations');

after('deploy:failed', 'deploy:unlock');
after('deploy:vendors', 'deploy:clear_paths');
```

Т.е. у вас так же остается возможность запускать deploy с локальной машины (если вы тестируете собственную ветку например).

К основному скрипту добавляется конфиг gitlab CI (в новых проектах файл называется **.gitlab-ci.yml.example** Чтобы он заработал, нужно убрать **.example**). В этом скрипте и заложена основная магия (этот скрипт тоже можно копипастить):

```
.gitlab-ci.yml

image: composer:1.6

stages:
  - deploy

before_script:
  ##
  ## Install ssh-agent if not already installed, it is required by Docker.
  ## (change apt-get to yum if you use an RPM-based image)
  ##
  - 'which ssh-agent || ( apt-get update -y && apt-get install openssh-client -y )'

  ##
  ## Run ssh-agent (inside the build environment)
  ##
  - eval $(ssh-agent -s)

  ##
  ## Add the SSH key stored in SSH_PRIVATE_KEY variable to the agent store
  ## We're using tr to fix line endings which makes ed25519 keys work
  ## without extra base64 encoding.
  ## https://gitlab.com/gitlab-examples/ssh-private-key/issues/1#note_48526556
  ##
  - echo "$RUNNER_SSH_PRIVATE_KEY" | tr -d '\r' | ssh-add - > /dev/null
  ##
  ## Create the SSH directory and give it the right permissions
  ##
  - mkdir -p ~/.ssh
  - chmod 700 ~/.ssh

  ##
  ## Store key as file
  ##
  - echo "$RUNNER_SSH_PRIVATE_KEY" > ~/.ssh/id_rsa
  ##
  ## Add required host data to known_hosts
  ##
  - echo "$RUNNER_KNOWN_HOSTS" > ~/.ssh/known_hosts

  ##
  ## Install deployer
  ##
  - curl -LO https://deployer.org/deployer.phar
  - mv deployer.phar /usr/local/bin/dep
  - chmod +x /usr/local/bin/dep

##
## Runs deploy to host prod with verbose output for logs
##
deploy to prod:
  stage: deploy
  script:
    - dep deploy:unlock prod -vvv
    - dep deploy prod --branch=master -vvv
  only:
    - master

##
## Runs deploy to host stage with verbose output for logs
##
deploy to stage:
  stage: deploy
  script:
    - dep deploy:unlock stage -vvv
    - dep deploy stage --branch=develop -vvv
  only:
    - develop
```

Скрипт ставит на машину **deployer** последней версии и запускает сам deploy.

### Что делать, если серверы предоставил клиент?

В новом deploy скрипте используются переменные окружения для определения пользователей, USER\_STAGE и USER\_PRODUCTION. Переопределить их можно двумя способами:

- Для того, чтобы Gitlab правильно задавал их в CI/CD, в проекте нужно переписать эти значения

[![](https://intra.rocketfirm.com/media/page_image/3i/15235309573n13l.png)](https://intra.rocketfirm.com/media/page_image/3i/15235309573n13l.png)

- Локально можно добавить префиксом к деплой скрипту следующее:

[![](https://intra.rocketfirm.com/media/page_image/8l/1523531120dvmr2.png)](https://intra.rocketfirm.com/media/page_image/8l/1523531120dvmr2.png)

### Репорты

В случае неудачного deploy, GitLab пришлет вам письмо с соответствующим уведомлением

[![](https://intra.rocketfirm.com/media/page_image/nd/1523529446nanoe.png)](https://intra.rocketfirm.com/media/page_image/nd/1523529446nanoe.png)

### Итоги

Вдобавок к инструкциям, хочу привести статью компании Atlassian о беспрерывной поставке:

[Вот эту — ](https://www.atlassian.com/continuous-delivery)[atlassian.com/continuous-delivery](https://www.atlassian.com/continuous-delivery)

И заодно напомню, что компания Atlassian добилась капитализации более чем в 2 млрд долларов и вышла на IPO без единого инвестора, выбрав автоматизацию в качестве основной стратегии.

Если вам кажется, что сейчас CI/CD — лишний обвес к текущему объему работы, то можете продолжать просто пользоваться голым deployer, это нормально. Однако советую просто попробовать и ощутить все самим.

С вопросами по CI/CD можно обращаться к техническим спецалистам.

Спасибо.