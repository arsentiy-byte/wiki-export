# Книги > DevOps > Настройка CI/CD для frontend > Дополнительно

# Дополнительно

P.S. Так как на сервере проект в докер контейнере, желательно перед выгрузкой на тестовый или на продакшн запускать локально проект в докере. 

Вот ссылка на статью, где это описано более подробно: 

[https://intra.rocketfirm.com/tech/post/1585-rocketfront-hybrid-v2-dockerized/](https://intra.rocketfirm.com/tech/post/1585-rocketfront-hybrid-v2-dockerized/)