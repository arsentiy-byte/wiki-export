# Книги > QA > Теория тестирования > Если вы ещё не начитались...

# Если вы ещё не начитались...

[https://sergeygavaga.gitbooks.io/kurs-lektsii-testirovanie-programnogo-obespecheni/content/](https://sergeygavaga.gitbooks.io/kurs-lektsii-testirovanie-programnogo-obespecheni/content/)

[https://testengineer.ru/](https://testengineer.ru/)

[https://vladislaveremeev.gitbook.io/qa\_bible/](https://vladislaveremeev.gitbook.io/qa_bible/)

[https://elearn.epam.com/courses/course-v1:EPAM+STI+RU/courseware/](https://elearn.epam.com/courses/course-v1:EPAM+STI+RU/courseware/bbea8191c8864320b21544ae133022b4/50b199945cad4d3cb7cf3f41a238b6f4/?activate_block_id=block-v1%3AEPAM%2BSTI%2BRU%2Btype%40sequential%2Bblock%4050b199945cad4d3cb7cf3f41a238b6f4) - курс Святослава Куликова - короткие видео и вопросы по ним (рус/англ)

[http://svyatoslav.biz/software\_testing\_book/](http://svyatoslav.biz/software_testing_book/) - Святослав Куликов, книга по основам тестирования