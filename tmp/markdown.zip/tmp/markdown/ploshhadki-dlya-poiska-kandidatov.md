# Книги > Рекрутинг > Площадки для поиска кандидатов

# Площадки для поиска кандидатов

**Создание вакансий**

Большая часть вакансий размещается на **hh.kz**, за исключением технических позиций уровня middle и выше - как правило, отклик разработчиков, devops невысокий.   
Хороший отклик по позициям в отделы: продаж, менеджеров проектов, бэк-офис, маркетинг, СММ.

**Linkedin**  
Эффективен для подбора и общения напрямую с кандидатами уровня middle и выше. Результативнее рекрутить ИТ-спеуов оттуда.

**Telegram-чаты для размещения вакансий:**  
[https://t.me/backenderskz —](https://t.me/backenderskz) сообщество backend разработчиков в KZ  
[https://t.me/frontendkz](https://t.me/frontendkz) — сообщество frontend разработчиков в KZ  
[https://t.me/productskz ](https://t.me/productskz-)— сообщество product менеджеров в KZ  
[https://t.me/projects\_kz](https://t.me/projects_kz) — сообщество project менеджеров в KZ  
[https://t.me/devkz\_jobs](https://t.me/devkz_jobs) — размещение ИТ-вакансий  
[https://t.me/relocation\_kaz](https://t.me/relocation_kaz) — релокация россиян в Казахстан  
[https://t.me/+C\_W9krm5jRgyYjhi](https://t.me/+C_W9krm5jRgyYjhi) — IT hub для нерезидентов РК

**Группы в телеге для вакансий и сорсинга кандидатов:**

QA  
https://t.me/qaz\_qa\_vacancies  
https://t.me/kzqacommunity

Product и айти в целом:  
https://t.me/itvacancies4u  
https://t.me/productskz  
https://t.me/it\_outsource  
https://t.me/aaitcomm  
https://t.me/Terricon

Бекендеры:  
https://t.me/backenderskz  
https://t.me/go\_kz\_vacancy  
https://t.me/javadevjob

Фронтендеры:  
https://t.me/frontendkz  
https://t.me/JScript\_jobs  
https://t.me/javascript\_jobs\_feed  
https://t.me/job\_react

Мобильные разработчики:  
https://t.me/android\_developers\_kz  
https://t.me/android\_developers\_kz  
https://t.me/iOSDevelopers\_KZ

Группа вакансий:  
https://t.me/devkz\_jobs  
https://t.me/vacancy\_argos  
https://t.me/KZN\_Vacancy  
https://t.me/workitkz  
https://t.me/digitaljobkz  
https://t.me/jobkz\_1  
https://t.me/vacancykgz  
https://t.me/itkgz  
https://t.me/vacancykgg  
https://t.me/bank\_vakansiy