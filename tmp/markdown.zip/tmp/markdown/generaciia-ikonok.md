# Книги > Archived > ROCKETFRONT-REACTNATIVE (ЧЕРНОВИК) > Генерация иконок

# Генерация иконок

#### **Экспорт иконок с дизайна**

[![image-1648799316895.48.32.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1648799316895-48-32.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1648799316895-48-32.png)

##### С дизайна экспортируем иконки в svg формате 

##### Названия файлов будет использоваться как имя иконки

[![image-1648799376814.49.31.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1648799376814-49-31.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1648799376814-49-31.png)

#### **Переносим в папку assets/icons-import**

[![image-1648799443699.50.35.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1648799443699-50-35.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1648799443699-50-35.png)

#### **Запускаем скрипт** 

```shell
$ yarn run gen-icons
```

[![image-1648799558117.52.35.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1648799558117-52-35.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1648799558117-52-35.png)

#### **Папку icons-import можно удалить** 