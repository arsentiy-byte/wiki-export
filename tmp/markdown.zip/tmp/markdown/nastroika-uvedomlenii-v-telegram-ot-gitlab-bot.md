# Книги > DevOps > Настройка CI/CD для frontend > Настройка уведомлений в Telegram от Gitlab Bot

# Настройка уведомлений в Telegram от Gitlab Bot

Если в проекте не настроен Gitlab Bot:

В gitlab идем в settings &gt; webhooks

![pasted image 0 (2).png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pasted-image-0-2.png)

Добавляем gitlab bot в группу проекта в “telegram”

![pasted image 0 (3).png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pasted-image-0-3.png)

полученную ссылку вставляем сюда:

![pasted image 0 (4).png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pasted-image-0-4.png)

и вводим токен (рандомное слово).

Далее настраиваем нужные для нас триггеры:

![pasted image 0 (5).png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pasted-image-0-5.png)

Если же в проекте настроен gitlab bot, однако нет уведомлений о деплое:

![pasted image 0 (6).png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pasted-image-0-6.png)

и выбираем нужные нам настройки, для отображения состояния деплоя требуются: Job events и Pipeline events:

![pasted image 0 (7).png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pasted-image-0-7.png)