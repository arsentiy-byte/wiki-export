# Книги > Как войти в свою почту 🤯 > Краткая инструкция о подключении почты на доменах ps.kz

# Краткая инструкция о подключении почты на доменах ps.kz

В Ракетной есть несколько доменов почтовых адресов, созданные под направления в компании. Если твоя почта заканчивается на: @rocketfirm.com, @setochka.kz и @holymedia.kz, @magicslide.kz то эта инструкция для тебя.

Для того чтобы беспрепятственно пользоваться своим почтовым ящиком на MacOS или iOS, нужно иметь приложение почта на своем устройстве. Обычно такие приложения уже установлены на устройстве.

**[![](https://lh7-us.googleusercontent.com/GOziC8tuvxqfeZLoU29RMZShuTKArakPmmtlFyDqLuTUnVcuHr9Q8pO2aQ7wPH0B8Wv1PL_jaEguTDqbHQGZIiu7LFrPUGIIqb5TLTDlbD5OyfO_qcUDLJM_TNcwLxzvfBWo5yomyMGfPde6FYp9Ux4)](https://lh7-us.googleusercontent.com/GOziC8tuvxqfeZLoU29RMZShuTKArakPmmtlFyDqLuTUnVcuHr9Q8pO2aQ7wPH0B8Wv1PL_jaEguTDqbHQGZIiu7LFrPUGIIqb5TLTDlbD5OyfO_qcUDLJM_TNcwLxzvfBWo5yomyMGfPde6FYp9Ux4)**

И так, заходим в почту и добавляем пользователя, нам нужно добавить “Другую учетную запись…” **[![](https://lh7-us.googleusercontent.com/d6Wn2xVXpG8HEkPMkWG4oqIhN_gvHoEBjvwdvan3SkNEH_CUrFZwY_ncj_9VQI7DoLSATLq8s65p_TaXOqVnk9HH2RVwib1Fh_So8XwC6ZeUHKgDLfiIyKfcMRrxYkK70LucK5hNlbdnWexunHwSYzI)](https://lh7-us.googleusercontent.com/d6Wn2xVXpG8HEkPMkWG4oqIhN_gvHoEBjvwdvan3SkNEH_CUrFZwY_ncj_9VQI7DoLSATLq8s65p_TaXOqVnk9HH2RVwib1Fh_So8XwC6ZeUHKgDLfiIyKfcMRrxYkK70LucK5hNlbdnWexunHwSYzI)**

Вводим данные почты и пароль

**[![](https://lh7-us.googleusercontent.com/docsz/AD_4nXfYyNaBjNGXqDnXavKNEM5Y_QnLTDqN1RyDIE9uHoX9sZrFZxOaY0hKUklfu42b22x-7cNqwH_TfhPc8OLR6GAQh76inTSKrwk9JE-lapePH_39KD25PTUtVa2WGB2X5yRz4VrIZHFtvZaPr-xyB1WjF2B8?key=RMxMBImHy2_rk_Ml97CiJQ)](https://lh7-us.googleusercontent.com/docsz/AD_4nXfYyNaBjNGXqDnXavKNEM5Y_QnLTDqN1RyDIE9uHoX9sZrFZxOaY0hKUklfu42b22x-7cNqwH_TfhPc8OLR6GAQh76inTSKrwk9JE-lapePH_39KD25PTUtVa2WGB2X5yRz4VrIZHFtvZaPr-xyB1WjF2B8?key=RMxMBImHy2_rk_Ml97CiJQ)**

Так как, мы пользуемся сторонним сервисом для почты, нам необходимо указать сервер используемой почты.[ ](https://lh7-us.googleusercontent.com/docsz/AD_4nXcsb4wy4PuzUnDY0MnAR2EniH4K1Yygff_hLy7oM-iGPs7Hzn9gwx2bLfvh7AeD69bRevs73HpvyYtt3riGhnpQU4SMP8Yxx0RhhuVHy-0xDvvaf-i_r2hxd8YL6wcJ9z_d6A-93M6XDRq9s9HUuS_MRyfo?key=RMxMBImHy2_rk_Ml97CiJQ)**[![](https://lh7-us.googleusercontent.com/docsz/AD_4nXcsb4wy4PuzUnDY0MnAR2EniH4K1Yygff_hLy7oM-iGPs7Hzn9gwx2bLfvh7AeD69bRevs73HpvyYtt3riGhnpQU4SMP8Yxx0RhhuVHy-0xDvvaf-i_r2hxd8YL6wcJ9z_d6A-93M6XDRq9s9HUuS_MRyfo?key=RMxMBImHy2_rk_Ml97CiJQ)](https://lh7-us.googleusercontent.com/docsz/AD_4nXcsb4wy4PuzUnDY0MnAR2EniH4K1Yygff_hLy7oM-iGPs7Hzn9gwx2bLfvh7AeD69bRevs73HpvyYtt3riGhnpQU4SMP8Yxx0RhhuVHy-0xDvvaf-i_r2hxd8YL6wcJ9z_d6A-93M6XDRq9s9HUuS_MRyfo?key=RMxMBImHy2_rk_Ml97CiJQ)**

Для доменов @setochka.kz, @holymedia.kz и@magicslide.kz мы вводим сервер – srv-plesk31.ps.kz

Для @rocketfirm.com – srv-plesk54.ps.kz

**[![](https://lh7-us.googleusercontent.com/docsz/AD_4nXcR8sQrbKPrjHKs1Erv7rRBZrHHv5yYCRAavuTCsshzfQgRBceN_hreHVqLgIe9aS486OkLdBcdGFEdJkMywSoVcvaEvWPmDM-lB2eWLhJ06sihe1mZQfTA7hCIguh9P-cWlJR-bzI3zzbSwOthQTUxzKc?key=RMxMBImHy2_rk_Ml97CiJQ)](https://lh7-us.googleusercontent.com/docsz/AD_4nXcR8sQrbKPrjHKs1Erv7rRBZrHHv5yYCRAavuTCsshzfQgRBceN_hreHVqLgIe9aS486OkLdBcdGFEdJkMywSoVcvaEvWPmDM-lB2eWLhJ06sihe1mZQfTA7hCIguh9P-cWlJR-bzI3zzbSwOthQTUxzKc?key=RMxMBImHy2_rk_Ml97CiJQ)**

Для входящей и исходящей почты сервер одинаковый. Если вы ввели все данные верно, ваше устройство предложит выбрать приложения, которые будут использоваться вашей учетной записью. Выбрав нужные приложения, вы сможете свободно пользоваться вашей почтой.

**[![](https://lh7-us.googleusercontent.com/docsz/AD_4nXf2wb6zeMLnxBldQKqBKgeNU74LIa1iQCkabElTQUIM4NWv0-LRQhhUnfnbm2QttFliCKvN5_pEhrszHELzzDeUh4hYWdhNBJ5iIiuefKN31HHDzT6fS3Vtl_bIHYFInvCdgtJ9TzO80RqHD4MP9hbaei6V?key=RMxMBImHy2_rk_Ml97CiJQ)](https://lh7-us.googleusercontent.com/docsz/AD_4nXf2wb6zeMLnxBldQKqBKgeNU74LIa1iQCkabElTQUIM4NWv0-LRQhhUnfnbm2QttFliCKvN5_pEhrszHELzzDeUh4hYWdhNBJ5iIiuefKN31HHDzT6fS3Vtl_bIHYFInvCdgtJ9TzO80RqHD4MP9hbaei6V?key=RMxMBImHy2_rk_Ml97CiJQ)**

Если вам удобно пользоваться веб-версией, то вам сюда [https://webmail.ps.kz/](https://webmail.ps.kz/)

Для входа в почту через iPhone, нам необходимо провалиться в настройки, найти приложение “Почта” и здесь добавить новую учетную запись.**[![](https://lh7-us.googleusercontent.com/docsz/AD_4nXdifzgwUJSnb65qlQn8nkLdEtVisdDxp7wIXYefSSE7mHXT017vh0r_vGrVpt4dMhZbNhvXbuxrKhJHXbSyUZ4SHu2zzSxyDuYOTA_GB0odIFC_0VBXDL9ee_gfLDCUmcVrjKdmdKG0gvwV6jq79foWqUyi?key=RMxMBImHy2_rk_Ml97CiJQ)](https://lh7-us.googleusercontent.com/docsz/AD_4nXdifzgwUJSnb65qlQn8nkLdEtVisdDxp7wIXYefSSE7mHXT017vh0r_vGrVpt4dMhZbNhvXbuxrKhJHXbSyUZ4SHu2zzSxyDuYOTA_GB0odIFC_0VBXDL9ee_gfLDCUmcVrjKdmdKG0gvwV6jq79foWqUyi?key=RMxMBImHy2_rk_Ml97CiJQ)**

**[![](https://lh7-us.googleusercontent.com/docsz/AD_4nXexEJIyCCGOdHB7YEfcth_I5ms7zN4Wn8wNi6LhhgmeV6KgV0tByqJwsVu6tFq4X6oCvSdrtOuzFqoq-bOceo8SrNcmUw-335wYfhHJy7ZoJUf-fdkse_ekdyeugzRjeAn1DoEJnPxu9ODT6f8WGZ_YVft2?key=RMxMBImHy2_rk_Ml97CiJQ)](https://lh7-us.googleusercontent.com/docsz/AD_4nXexEJIyCCGOdHB7YEfcth_I5ms7zN4Wn8wNi6LhhgmeV6KgV0tByqJwsVu6tFq4X6oCvSdrtOuzFqoq-bOceo8SrNcmUw-335wYfhHJy7ZoJUf-fdkse_ekdyeugzRjeAn1DoEJnPxu9ODT6f8WGZ_YVft2?key=RMxMBImHy2_rk_Ml97CiJQ)**

Делаем все те же шаги, что и проделывали на ноутбуке.

**[![](https://lh7-us.googleusercontent.com/docsz/AD_4nXfY01EX9g4VPnlkCCBhwfSzC0NrUa2RLYmwGr__oUlU7WYOikrHU_ATjNESSAWGXL74K3PSMCFiq0JQR7I0H1eYmJjrWw97dta32T5_6uYhBky3PsRqGEw33m0EB-WccLtz0rt4NEkLxLa0QU06oqGfATVa?key=RMxMBImHy2_rk_Ml97CiJQ)](https://lh7-us.googleusercontent.com/docsz/AD_4nXfY01EX9g4VPnlkCCBhwfSzC0NrUa2RLYmwGr__oUlU7WYOikrHU_ATjNESSAWGXL74K3PSMCFiq0JQR7I0H1eYmJjrWw97dta32T5_6uYhBky3PsRqGEw33m0EB-WccLtz0rt4NEkLxLa0QU06oqGfATVa?key=RMxMBImHy2_rk_Ml97CiJQ)**

**[![](https://lh7-us.googleusercontent.com/docsz/AD_4nXe5BupQh1cA0RZkh_UmYaVfqccph7axSX8_QaX97y7nfhMS7Q9Gn2zDVOkztOCW2KyQLwv4c4eObzOvLim9gVfJnzcWpsrFJnGPyQocMNqNXIWFwsB7R70YMdB7WCTrb7OMtSE49xiEpfMTbCXdEWoeG-8?key=RMxMBImHy2_rk_Ml97CiJQ)](https://lh7-us.googleusercontent.com/docsz/AD_4nXe5BupQh1cA0RZkh_UmYaVfqccph7axSX8_QaX97y7nfhMS7Q9Gn2zDVOkztOCW2KyQLwv4c4eObzOvLim9gVfJnzcWpsrFJnGPyQocMNqNXIWFwsB7R70YMdB7WCTrb7OMtSE49xiEpfMTbCXdEWoeG-8?key=RMxMBImHy2_rk_Ml97CiJQ)**

После введения данных почты, откроется окно для добавления сервера исходящей и входящей почты. Вводите данные сервера и вуаля, ваша почта доступна с телефона.