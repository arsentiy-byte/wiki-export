# Книги > Mattermost > Начало работы с мм > Настройки профиля

# Настройки профиля

При первом входе в систему необходимо настроить свой профиль.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/ivQimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/ivQimage.png)

1. В правом верхнем углу экрана открываем иконку профиля.  
    Там переходим на вкладку Profile (Профиль).

- Заполняем свое полное имя рускими буквами
- Вашу должность/роль (дизайнер, менеджер проектов, java-разработчик etc.)
- Добавляем фотографию профиля  
      
    [![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/ksEimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/ksEimage.png)

2\. Во вкладке Security (Безопасность) можно подклчючить двухфакторную аутентификацию.