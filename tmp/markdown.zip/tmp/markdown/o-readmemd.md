# Книги > README.md для CLM > О README.md

# О README.md

[![hero-image-makeareadme-872f507326e8d9cfc028a33b9ee37039275038e2b10bbac323efaf2dd6c01502.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-06/scaled-1680-/hero-image-makeareadme-872f507326e8d9cfc028a33b9ee37039275038e2b10bbac323efaf2dd6c01502.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-06/hero-image-makeareadme-872f507326e8d9cfc028a33b9ee37039275038e2b10bbac323efaf2dd6c01502.png)

У каждого проекта должно быть описание, в нем мы указываем данные разработчика, менеджера, основные ссылки на доп. материалы и команды для запуска проекта, самое удобное место для этого – README.md

***Какая информация обязательно должна быть в README.md для проекта:***

1. **Название**: тут мы указываем имя презентации подробнее как называть презентации можно почитать [тут](https://wiki.rocketfirm.com/books/rabota-s-prezentatsiyami-v-mi/page/rabota-s-prezentatsiyami-v-mi#bkmrk-%D0%9D%D0%B0%D0%B7%D0%B2%D0%B0%D0%BD%D0%B8%D1%8F-%D0%BF%D1%80%D0%B5%D0%B7%D0%B5%D0%BD%D1%82%D0%B0%D1%86%D0%B8%D0%B9) 
2. **Компания**: указываем заказчика Sanofi/Santo/Stada/Nestle, его можно посмотреть в доске jira, также в названии чата в котором пришла задача от wall-e или сверится с инфографикой [тут](https://wiki.rocketfirm.com/books/pamyatka-erN/page/infografika-po-partneram-platformam-dizainu-i-stranam)
3. **Продукт**: название препарата Essentiale/Telzap. Его можно уточнить у менеджера или получить в описании проекта
4. **Количество слайдов**: считаем исходя из flow, что это такое можно узнать [тут](https://wiki.rocketfirm.com/books/osnovnaya-informatsiya-po-razrabotke-prezentatsiy/page/chast-2-rabota-s-shablonom-biblioteka-cegedimjs-flow-reshenie-problem-i-poleznye-tryuki#bkmrk-flow-%28%D1%81%D1%86%D0%B5%D0%BD%D0%B0%D1%80%D0%B8%D0%B9%29-%28app)
5. **Карточка проекта**: тут указываем ссылку на проект в jira
6. Менеджер: это человек который поставил задачу )))) обязательно указываем ссылку на telegram, чтоб потом не искать в интре по имени. Узнать ник можно или в самом telegram или [тут](https://intra.rocketfirm.com/users/) 
7. **Фронтендер**: это разработчик CLM модуля ))) указываем также ссылку на telegram
8. **Тестировщик**: указываем ссылку на telegram
9. **Далее** идет описание template его можно скопировать [тут](https://gitlab.com/rocketfirm/presentations/presentation-template)

  
[![Снимок экрана 2022-06-07 в 15.22.35.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-06/scaled-1680-/snimok-ekrana-2022-06-07-v-15-22-35.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-06/snimok-ekrana-2022-06-07-v-15-22-35.png)

***Важно.***

Поддерживаю актуальную информацию мы всегда можем быстро найти нужный проект, на данный момент готовых модулей у нас порядка 350, и в каждом проекта есть несколько веток под разные системы. README нам позволяет повышать понимание проекта, иметь доступ ко всем материалам проекта. В случае с новыми разработчиками, ребята могут самостоятельно быстро найти нужную им информацию, даже если этому модулю много лет и не дублировать уже существующий проект.

P.S. И не забываем пользоваться правилами git, об этом можно почитать [тут](https://wiki.rocketfirm.com/books/pravila-git-dlya-clm-prezentatsiy)