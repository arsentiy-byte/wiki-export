# Книги > DevOps > Бэкапирование БД с помощью BASH скрипта

# Бэкапирование БД с помощью BASH скрипта

Данная инструкция описывает пошаговую настройку автоматического выполнения резевного копирования баз данных(далее БД) используя bash скрипт. Для бэкапирования БД используются скрипт - backup\_db.sh, который доступен в публичном репозиторий гитлаб : [БД.](https://gitlab.com/ablaikhan-s/script-tools/-/blob/3e6e4d18934072e9c18c030db008b39fabed6d4f/backup_db.sh "скрипт бэкапирования БД")[ ](https://gitlab.com/ablaikhan-s/script-tools/-/blob/3e6e4d18934072e9c18c030db008b39fabed6d4f/backup_media.sh "скрипт бэкапирования медиа")Здесь я остановлюсь на ключевых строках этого скрипта.

### Настройка скрипта

#### Ниже указаны основны строки скрипта:

script_path=~/bin/backups - директория, в которой расположен скриптproject="projectname" - название проекта, используется для названия директорий при хранений бэкаповtime=`date +"%y-%m-%d_%H-%M"` - время выполнения бэкапирования dumpname="$project.$time.dump" - название конечного файла бэкапов   
db_name="database" - название БДdb_user="" - пользователь БДdb_password="" - пароль от учетной записи БДcontainer_name="" - название контейнера (если БД в контейнере)bucket="projectname" - название Бакета (если храним бэкапы в s3 совместимом облаке)  
periodic=$1 - частота бэкапирования (передаем эту переменную при вызове скрипта - hourly, daily, monthly)subd="mysql" # "mysql" or "postgres" - выбираем СУБДbackup_type="cloud" # "cloud" or "local" - выбираем способ храниения - локально или в облаке  
\# setting backups to keepif [[ $periodic == "hourly" ]]then days_to_keep=2 - время хранения почасовых бэкапов в суткахelif [[ $periodic == "daily" ]]then days_to_keep=30 - время хранения ежедневных бэкапов в суткахelif [[ $periodic == "monthly" ]]then days_to_keep=200 - время хранения ежемесячных бэкапов в суткахfi  
#### Так же необходимо проверить следующие строки на актуальность на конкретных серверах(выделено зеленым)(не забываем подставлять вначения вместо переменных при проверке комманд в терминале):

if \[\[ $subd == "postgres" \]\]  
then **sudo -u postgres pg\_dump $db\_name --insert** &gt; $bucket/$project/$periodic/$dumpname - команда для выполнения бэкапирование БД postgres  
\# if db is containerized user command:  
\# **docker exec -it -u postgres $container\_name sh -c "pg\_dump $db\_name --insert"** &gt; $bucket/$project/$periodic/$dumpname - команда для выполнения бэкапирование БД postgres если БД развернута в контейнере docker

elif \[\[ $subd == "mysql" \]\]  
then **mysqldump -u $db\_user -p"$db\_password" $db\_name** &gt; $bucket/$project/$periodic/$dumpname - команда для выполнения бэкапирование БД mysql  
\# if db is containerized user command:  
\# **docker exec -it $container\_name sh -c "mysqldump -u $db\_user -p"$db\_password" $db\_name"** &gt; $bucket/$project/$periodic/$dumpname - команда для выполнения бэкапирование БД mysql если БД развернута в контейнере docker

### Запуск скрипта 

После настройки скрипта и проверки комманд необходимо:

\- перенести скрипт в удобную директорию(которая указана в переменной script\_path), при этом необходимо учитывать то, что рядом со скриптом будут храниться резервные копии(если выбран режим хранения бэкапов локально)

\- добавить в crontab следующие строки(crontab -e - изменение crontab)

05 * * * * bash $script_path/backup_db.sh hourly - запуск почасового бэкапирования в 5 минут каждого часа 00 00 * * * bash $script_path/backup_db.sh daily - запуск ежедневного бэкапирования каждый день в 12 часов ночи 10 00 28 * * bash $script_path/backup_db.sh monthly - запуск ежемесячного бэкапирования 28 числа каждого месяца ### Настройка s3cmd

При выборе режима хранения бэкапов в облаке необходимо на сервере установить пакет s3cmd и настроить ~/.s3cfg файл для пользователя, который будет работать с бэкапированием

Привет базового конфига(или можно просто скопировать с уже настроенных серверов)

```
[default]
access_key = Access_key_goes_here
secret_key = REDACTED
check_ssl_certificate = True
use_https = True
```