# Книги > DevOps > Настройка CI/CD для frontend > Добавление переменных в Gitlab

# Добавление переменных в Gitlab

Добавляем переменные в Gitlab 

![pasted image 0.png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pasted-image-0.png)

![pasted image 0 (1).png](https://wiki.rocketfirm.com/uploads/images/gallery/2023-11/pasted-image-0-1.png)

Переменные НЕ должны быть “protected”

- { PRIVATE\_KEY }- приватный ssh ключ\*
- { USER } - Имя юзера на сервере
- { DEV\_HOST } - адрес сервера
- { DEV\_PATH }- путь до папки проекта на сервере

\* - (ссылка на статью, где получить ключ:https://wiki.rocketfirm.com/books/vkhod-na-server-po-ssh)