# Книги > Archived > Live чат на Firebase > База данных Firestore

# База данных Firestore

**3. Создание базы данных**

Теперь нужно создать саму базу данных. Из левого меню выбираем Firestore Database

![](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-nwp2kdlv.png)

Далее нажимаем на открывшемся экране Create Database

![](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-8hh32nrf.png)

В первом пункте выбираем настройки доступа к базе для записи и чтения. Пока выбираем тестовый режим тестовый режим, но перед выгрузкой в дальнейшем на боевой сервер нужно не забыть поменять эти настройки. Изначально firebase ставит ограничение на этот режим в 30 дней, после создания базы в настройках можно увеличить или уменьшить это время.

![](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-nf3hd3xp.png)

Во втором шаге все просто, выбираем ближайший к нам сервер. После чего нажимаем далее и база будет создана.

![](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-u0h3xsgj.png)

В настройках базы во вкладке Rules можно изменить те самые настройки доступа

![](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/embedded-image-bnffyjzu.png)