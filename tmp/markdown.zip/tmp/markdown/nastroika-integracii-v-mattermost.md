# Книги > DevOps > Настройка интеграций в Mattermost

# Настройка интеграций в Mattermost

### **Jenkins:** 

0\) Должен быть уже создан чат/канал/команда в Mattemost. Нам нужно его название в том виде, в котором оно присутствует в ссылке. То есть, если канал в Mattermost виден как DevOps, то в ссылке он будет скорее всего devops - нужно именно такое.

1\) Заходим в настройки нужного джоба в дженкинсе, нажимаем на "Послесборочные операции", выбираем "Mattermost Notifications":

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/image.png)

2\) Выбираем события джоба, которые должны слать нотификацию в Mattermost:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/lsJimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/lsJimage.png)

3\) Нажимаем на "Расширенные", указываем команду/канал. Больше ничего указывать не надо, поскольку все основные параметры подключения к Mattermost уже указаны в общих настройках Jenkins:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/5OVimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/5OVimage.png)

4\) Рекомендую сразу нажать на кнопку "Test Connection" - если всё настроено верно, то в окне настроек появится надпись Success, а в указанном чате Mattermost появится тестовая нотификация

### **Gitlab**

0\) Нужны админские права в чате

1\) Заходим в нужный чат, пишем /gitlab webhook add &lt;путь к проекту в gitlab&gt;

Путь к проекту в gitlab ищем в адресной строке начиная с rocketfirm:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/SVdimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/SVdimage.png)

То есть в данном случае мы команда будет такая:

/gitlab webhook add rocketfirm/your-sport/your-sport-frontend

2\) Команда автоматически добавит вебхук в свойства репозитория, максимально что вы возможно захотите сделать - указать в свойствах вебхука конкретные ветки, для которых он должен срабатывать

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/HN7image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/HN7image.png)

### **Jira**

0\) Нужны права менеджера в проекте

1\) Заходим в "Параметры проекта":

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/8LEimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/8LEimage.png)

2\) Выбираем в настройках раздел "Mattermost Integration"

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/Q8vimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/Q8vimage.png)

3\) Нажимаем на Connect, видим список команд:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/uBUimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/uBUimage.png)

4\) Выбираем нужную команду (configure), выбираем список того, что нужно и что не нужно отображать (можно через JQL), нажимаем на Save. Можно дополнительно послать тестовое сообщение, чтобы проверить, что всё хорошо:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/scaled-1680-/cv3image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-08/cv3image.png)