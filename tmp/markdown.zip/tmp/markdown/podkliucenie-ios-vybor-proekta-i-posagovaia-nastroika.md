# Книги > Archived > Live чат на Firebase > Подключение IOS :: Выбор проекта и пошаговая настройка

# Подключение IOS :: Выбор проекта и пошаговая настройка

1\. Сначала нужно выбрать необходимую платформу в уже созданом проекте, в данном случае это будет ios. Более детально о создании проекта есть в [веб-версии](https://wiki.rocketfirm.com/books/live-chat-na-firebase/page/sozdanie-proekta) этого гайда.

[![Screen Shot 2021-09-13 at 9.11.19 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-13-at-9-11-19-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-13-at-9-11-19-pm.png)

[![Screen Shot 2021-09-13 at 9.11.49 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-13-at-9-11-49-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-13-at-9-11-49-pm.png)

2\. Сразу после выбора, вас перебросит на экран пошаговой настройки конфигурации для ios. Первым шагом в нам обязательным пунктом нужно указать наш bundle id. Использовать нужно именно ios bundle id не перепутайте и не впишите от андроида.

[![Screen Shot 2021-09-21 at 10.11.01 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-21-at-10-11-01-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-21-at-10-11-01-pm.png)

Найти bundle id можно множеством способов но самый простой это открыть Xcode выбрать в target ваш проект и открыть вкладку general, там можно будет найти bundle identifier именно для ios версии проекта. Так же можно опционально указать App nickname это больше нужно для самого firebase чтобы удобно в дальнейшем управлять проектом.

[![Screen Shot 2021-09-13 at 9.12.55 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-13-at-9-12-55-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-13-at-9-12-55-pm.png)

Если по какой-то причине вам понадобилось найти App Store id который так-же на данном этапе является опциональным, то найти его можно пройдя в ваш appstoreconnect в браузере, выбрать необходимый проект и в строке браузера скопировать id. (возможно есть и более элегантный способ, но я даже не искал).

[![Screen Shot 2021-09-13 at 9.15.22 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-13-at-9-15-22-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-13-at-9-15-22-pm.png)

3\. После этого можно нажимать далее и переходить ко второму пункту. Вторым этапом вам будет предложено сачать файл который нужно поместить по определенному пути.

[![Screen Shot 2021-09-13 at 9.17.10 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-13-at-9-17-10-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-13-at-9-17-10-pm.png)

Сделать удобнее всего это можно через Xcode открыв в левой панели свой проект и выбрать папку с названием проекта еще раз и переместить файл.

[![Screen Shot 2021-09-13 at 9.18.32 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-13-at-9-18-32-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-13-at-9-18-32-pm.png)

4\. Далее в 3 шаг опционален, здесь лишь нужно знать что вам нужно не забыть установить Pods если они у вас уже есть то смело идите к следующему шагу если нет то:

`pod init`

`pod install`

5\. Далее нам нужно прописать ios sdk для правильной загрузки в проект. Для этого нам в первую очередь нужно пройти по пути `/ios/{projectName}/AppDelegate.m` и в файле AppDelegate.m в самый верх вставить строку

\#import &lt;Firebase.h&gt;  
  
  
  
  
```
xxxxxxxxxx
```

  
  
 1```
#import 
```

  
  
[![Screen Shot 2021-09-21 at 9.42.35 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-21-at-9-42-35-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-21-at-9-42-35-pm.png)

Далее в этом же файле нам нужно найти `didFinishLaunchingWithOptions` и вставить код который находится в блоке if в свой файл.

`- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions``{``if ([FIRApp defaultApp] == nil) {``[FIRApp configure];``}`[![Screen Shot 2021-09-21 at 9.42.55 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/scaled-1680-/screen-shot-2021-09-21-at-9-42-55-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-09/screen-shot-2021-09-21-at-9-42-55-pm.png)6\. Последним шагом остается перейти в терминале в папку ios вашего проекта и выполнить команду

`pod install`

Подтянув тем самым новые зависимости firebase