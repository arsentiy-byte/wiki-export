# Книги > Единый стандарт кода (PHP, Laravel) > Оформление

# Оформление

#### Базовый стандарт оформления кода

Код *ДОЛЖЕН* быть оформлен согласно всем правилам, указанным в стандарте [PSR-12](https://www.php-fig.org/psr/psr-12/).

#### Строки

*РЕКОМЕНДУЕТСЯ*, чтобы длина строк не превышала 120 символов.

#### Строгая Типизация

**Строгую типизацию НЕОБХОДИМО использовать во всех проектах.** Это значит, что каждый файл PHP *ДОЛЖЕН* начинаться с объявления строгой типизации, а все функции и методы ДОЛЖНЫ явно указывать типы аргументов и возвращаемых значений.

```php
declare(strict_types=1);

function sum(int $first, int $second): int {
  return $first + $second;
}

```

#### Массивы

При объявлении многострочного массива в конце последнего объявления *ДОЛЖНА* ставиться запятая, для однострочного массива запятую ставить *НЕДОПУСТИМО*.

```php
// Правильно
[
    'firstElement'  => 'firstElement',
    'secondElement' => 'secondElement',
]

// Неправильно
[
    'firstElement'  => 'firstElement',
    'secondElement' => 'secondElement'
]
```

```php
// Правильно
['firstElement' => 'firstElement', 'secondElement' => 'secondElement']

// Неправильно
['firstElement' => 'firstElement', 'secondElement' => 'secondElement',]
```

#### Последовательность вызовов (Chaining)

Каждый элемент вызова для последовательностей, состоящих из трех и более элементов *ДОЛЖЕН* находиться на новой строке. В случае превышения максимальной длины строки каждый элемент последовательности вызовов *ДОЛЖЕН* находиться на новой строке.

```php
// Правильно
$this->firstMethod();

// Неправильно
$this
    ->firstMethod();

// Правильно
$this
    ->firstMethod()
    ->secondMethod();

// Неправильно
$this->firstMethod()->secondMethod();

// Неправильно
$this
    ->firstMethod()->secondMethod();

// Правильно
$this
    ->firstMethod()
    ->thirdMethod(
        $firstArgument,
        $secondArgument,
        $thirdArgument,
        $fourthArgument,
        $fifthArgument,
        $sixArgument
    );

// Неправильно
$this->firstMethod()->thirdMethod(
    $firstArgument,
    $secondArgument,
    $thirdArgument,
    $fourthArgument,
    $fifthArgument,
    $sixArgument
);
```

#### Выделение управляющих инструкций

Управляющие инструкции: `if`, `for`, `foreach`, `while`, `do-while`, `switch`, `break`, `continue`, `return` *ДОЛЖНЫ* отделяться от кода того же уровня вложенности одной пустой строкой.

```php
// Правильно
$count = 5;

if ($count === 5) {
// ...
}

// ...
```

```php
// Неправильно
$count = 5; // Отсутствует перевод строки
if ($count === 5) {
// ...
}
$length = 12; // Отсутствует перевод строки
// ...
```

```php
// Правильно
{
    if ($count === 5) {
    // ...
    }
}
```

```php
// Неправильно
{

    // Лишняя пустая строка
    if ($count === 5) {
    // ...
    }
    // Лишняя пустая строка
}
```

#### Предпочтение `sprintf` вместо Конкатенации Строк

Для объединения строк СЛЕДУЕТ использовать функцию `sprintf`, а не оператор конкатенации (`.`).

```php
// Правильно
$message = sprintf('User %s has %d points.', $userName, $points);

// Неправильно
$message = 'User ' . $userName . ' has ' . $points . ' points.';

```