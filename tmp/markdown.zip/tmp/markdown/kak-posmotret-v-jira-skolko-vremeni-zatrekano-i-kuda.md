# Книги > Jira > Как посмотреть в jira сколько времени затрекано и куда

# Как посмотреть в jira сколько времени затрекано и куда

Используем инструмент Work Time Calendar  
  
1\. Открываем отчёт из верхнего меню

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/wcvimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/wcvimage.png)

или из меню любого проекта

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/bHWimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/bHWimage.png)

---

2\. Создаём свой календарь (календарь имени себя)

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/K2Wimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/K2Wimage.png)

Если вы уже создавали календарь, его можно отредактировать по соседней кнопке

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/s8Zimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/s8Zimage.png)

---

3\. Заполняем название

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/Ml9image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/Ml9image.png)

4\. Переходим во вкладку Sources. ВЫбираем источник Worklog.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/1apimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/1apimage.png)

Задаем название источнику, выюираем фильтр, выбираем все задачи в фильтре и текущего пользователя. Сохраняем.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/i5oimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/i5oimage.png)

---

---

5\. Выбираем даты. Можно нажать skip details в вехнем правом углу.нажимаем на кнопку формирования отчета (справа)

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/LnXimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/LnXimage.png)

Получаем отчет

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/h1Kimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/h1Kimage.png)