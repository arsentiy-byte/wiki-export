# Книги > Бизнес-процесс менеджера отдела продаж > 15. Шаблоны документов

# 15. Шаблоны документов

#### БРИФЫ:  


- Бриф на разработку
- Бриф на разработку мобильного приложения
- Бриф на разработку web-сайта
- [Бриф на CLM](https://docs.google.com/document/d/1TWAADbxgdfCZp9EUreZfSToNnKXOVFjk/edit?usp=sharing&ouid=105370618825868424827&rtpof=true&sd=true)
- Бриф на perfomance маркетинг
- Бриф на SEO услуги
- Бриф на SMM  
    
- [Смета на разработку](https://intra.rocketfirm.com/clients/docs/docs-view/?id=251)

#### ПИСЬМА И СООБЩЕНИЯ КЛИЕНТАМ:  


- Шаблон письма новому потенциальному клиенту
- Шаблон сообщения потенциальному клиенту в LinkedIn

#### ПРЕЗЕНТАЦИИ:  


- Шаблон презентации Ракетной фирмы
- Шаблон презентации Holy Media
- Шаблон презентации Сеточка
- Шаблон презентации Magic slide
- Презентация Ракетной фирмы
- Презентация Holy Media
- Презентация Setochka
- Презентация Magic slide

#### ДОГОВОРА, ПРИЛОЖЕНИЯ, NDA:  


- [Шаблон договора Ракетная фирма (разработка)](https://intra.rocketfirm.com/clients/docs/docs-view/?id=118)
- [Шаблон договора Holy Media (контекст)](https://intra.rocketfirm.com/clients/docs/docs-view/?id=113)
- Шаблон договора Сеточка
- [Шаблон договора Holy Rays](https://intra.rocketfirm.com/clients/docs/docs-view/?id=259)
- Шаблон договора Rocket Science
- [Приложение к договору на разработку](https://intra.rocketfirm.com/clients/docs/docs-view/?id=124)
- [Приложение к договору на услуги хостинга](https://intra.rocketfirm.com/clients/docs/docs-view/?id=129)
- Приложение к договору на техподдержку
- [Приложение на SMM](https://intra.rocketfirm.com/clients/docs/docs-view/?id=36)
- [Приложение к договору на контекстную рекламу](https://intra.rocketfirm.com/clients/docs/docs-view/?id=260)
- Приложение к договору на фото и видео съемку
- [Приложение к договору на фирменный стиль](https://intra.rocketfirm.com/clients/docs/docs-view/?id=96)
- [Шаблон NDA](https://intra.rocketfirm.com/clients/docs/docs-view/?id=131)

#### РЕЙТ-КАРТЫ, ПРАЙС-ЛИСТЫ:  


- [Рейт-карта Ракетной фирмы](https://intra.rocketfirm.com/clients/docs/docs-view/?id=173)

#### СПЕЦИФИКАЦИИ:  


 - [Спецификация требований к ПО (техническое задание)](https://docs.google.com/document/d/1p0phVDa9UP6I4j6GW92aJqA3c2zsTEI6tDh3xRD3nEc/edit)