# Книги > Единый стандарт кода (PHP, Laravel) > PHPStorm и Линтеры

# PHPStorm и Линтеры

#### Использование линтера Laravel Pint

[**Laravel Pint**](https://laravel.com/docs/11.x/pint) — это инструмент для автоматического форматирования кода в Laravel, основанный на PHP CS Fixer. Pint помогает поддерживать чистый и единообразный код в проектах на Laravel, автоматически исправляя код в соответствии с определенными стандартами кодирования.

[Инструкция по настройке Laravel Pint в PHPStorm](https://www.jetbrains.com/help/phpstorm/using-laravel-pint.html)

##### Основные особенности Laravel Pint:

1. **Автоматическое форматирование**: Pint форматирует ваш PHP-код согласно определенным правилам кодирования. Это позволяет поддерживать единый стиль кодирования в команде или проекте.
2. **Простота использования**: Pint интегрируется с Laravel и прост в установке и использовании. Он не требует дополнительной настройки, так как поставляется с предустановленными настройками по умолчанию, подходящими для большинства проектов Laravel.
3. **Основан на PHP CS Fixer**: Laravel Pint построен на базе PHP CS Fixer, популярного инструмента для статического анализа кода и его исправления. Это означает, что Pint использует проверенные правила и конфигурации для форматирования кода.
4. **Настраиваемость**: Несмотря на то что Pint прост в использовании, его можно настроить для соответствия конкретным требованиям проекта. Вы можете изменить конфигурацию, чтобы добавлять или исключать определенные правила, в зависимости от предпочтений вашей команды.
5. **Поддержка командной строки**: Pint запускается из командной строки, что позволяет легко интегрировать его в рабочий процесс разработки. Например, можно настроить Pint на автоматическое выполнение при каждом коммите, чтобы гарантировать единый стиль кода.

**Конфиг файл `pint.json`**

```json
{
    "preset": "psr12",
    "rules": {
        "no_superfluous_phpdoc_tags": true,
        "no_empty_phpdoc": true,
        "align_multiline_comment": true,
        "array_indentation": true,
        "array_syntax": true,
        "blank_line_after_namespace": true,
        "blank_line_after_opening_tag": true,
        "combine_consecutive_issets": true,
        "combine_consecutive_unsets": true,
        "concat_space": {
            "spacing": "one"
        },
        "declare_parentheses": true,
        "declare_strict_types": true,
        "explicit_string_variable": true,
        "final_class": true,
        "fully_qualified_strict_types": true,
        "global_namespace_import": {
            "import_classes": true,
            "import_constants": true,
            "import_functions": true
        },
        "is_null": true,
        "lambda_not_used_import": true,
        "logical_operators": true,
        "mb_str_functions": true,
        "method_chaining_indentation": true,
        "modernize_strpos": true,
        "new_with_braces": true,
        "no_empty_comment": true,
        "not_operator_with_space": true,
        "ordered_traits": true,
        "protected_to_private": true,
        "simplified_if_return": true,
        "strict_comparison": true,
        "ternary_to_null_coalescing": true,
        "trim_array_spaces": true,
        "use_arrow_functions": true,
        "void_return": true,
        "yoda_style": true,
        "array_push": true,
        "assign_null_coalescing_to_coalesce_equal": true,
        "explicit_indirect_variable": true,
        "method_argument_space": {
            "on_multiline": "ensure_fully_multiline"
        },
        "modernize_types_casting": true,
        "no_superfluous_elseif": true,
        "no_useless_else": true,
        "nullable_type_declaration_for_default_null_value": true,
        "ordered_imports": {
            "sort_algorithm": "alpha"
        },
        "ordered_class_elements": {
            "order": [
                "use_trait",
                "case",
                "constant",
                "constant_public",
                "constant_protected",
                "constant_private",
                "property_public",
                "property_protected",
                "property_private",
                "construct",
                "destruct",
                "magic",
                "phpunit",
                "method_abstract",
                "method_public_static",
                "method_public",
                "method_protected_static",
                "method_protected",
                "method_private_static",
                "method_private"
            ],
            "sort_algorithm": "none"
        }
    },
    "exclude": [
        "bootstrap",
        "config",
        "database/migrations",
        "docker",
        "lang",
        "psalm",
        "psysh",
        "public",
        "resources",
        "routes",
        "storage",
        "vendor",
        "pkg"
    ],
    "notName": [
        "_ide_helper.php"
    ]
}
```

#### Использование анализатора PHPStan

[**PHPStan**](https://phpstan.org/) — это статический анализатор кода для PHP, предназначенный для выявления ошибок в коде без его фактического выполнения. PHPStan помогает разработчикам улучшать качество кода, находя ошибки и потенциальные проблемы на раннем этапе, до того, как код будет запущен в среде разработки или продакшене.

[Инструкция по настройке PHPStan в PHPStorm](https://www.jetbrains.com/help/phpstorm/using-phpstan.html)

##### Основные особенности PHPStan:

1. **Статический анализ**: PHPStan анализирует исходный код PHP, не выполняя его. Это означает, что он может находить синтаксические ошибки, нарушения типов данных, недоступные методы, несуществующие классы и другие проблемы, которые могли бы привести к ошибкам во время выполнения.
2. **Проверка типов данных**: PHPStan использует типы данных, указанные в коде (включая PHPDoc аннотации), чтобы проверить их согласованность. Это помогает находить ошибки, такие как передачу неверного типа аргумента в функцию или метод.
3. **Находимые ошибки**: PHPStan способен находить широкий спектр ошибок, включая:
    
    
    - Опечатки в именах методов и свойств.
    - Использование переменных, не определённых до их применения.
    - Возврат значений неверного типа.
    - Отсутствие обязательных параметров в вызовах функций или методов.
    - Нарушение ограничений интерфейсов и абстрактных классов.
    - Работа с несуществующими или приватными методами и свойствами.
4. **Поддержка уровня строгости (Level System)**: PHPStan позволяет настраивать уровень строгости анализа от 0 (наименьшая строгость) до 10 (наивысшая строгость). На более низких уровнях PHPStan выявляет только самые очевидные ошибки, тогда как на высоких уровнях он начинает проверять более сложные и менее очевидные аспекты кода.
5. **Интеграция с CI/CD**: PHPStan легко интегрируется с системами непрерывной интеграции и доставки (CI/CD), такими как GitHub Actions, GitLab CI, Jenkins и другими. Это позволяет автоматически запускать анализ кода при каждом коммите или перед релизом.
6. **Расширяемость**: PHPStan можно расширять, создавая свои собственные правила анализа или используя плагины для поддержки сторонних библиотек и фреймворков. Например, есть плагины для анализа кода Laravel, Doctrine, PHPUnit и других популярных библиотек.

**Конфиг файл `phpstan.neon`**

```
parameters:
    level: 5
    paths:
        - app
        - tests
        - database
        - routes
    parallel:
        maximumNumberOfProcesses: 4
```