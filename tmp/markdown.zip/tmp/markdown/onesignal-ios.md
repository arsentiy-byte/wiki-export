# Книги > Archived > OneSignal push уведомления > OneSignal IOS

# OneSignal IOS

В данной статье рассмотрим подключение onesignal к устройствам ios, напомню, что здесь можно почитать про [подключение android](https://wiki.rocketfirm.com/books/onesignal-push-uvedomleniya/page/onesignal-android-1lP) и тут так же расписано про создание проекта в firebase который нам необходим для обоих версий. В данной статье весь фокус пойдет на подключение ios.

**\*\*\*** Небольшая ремарка касательно тех, у кого macbook на M1 возможно на момент прочтения этого материала проблема будет поправлена, но на данный момент после установки пакета:

- - Yarn: 

```
yarn add react-native-onesignal
```

- - Npm

```
npm install –save react-native-onesignal
```

Нужно будет перейти в директорию ios

`cd ios`

и выполнить

`pod install` 

Если при установке pod install возникли проблемы или ошибки, вам нужно открыть терминал через Rosetta2, а не нативно и выполнить команду заново.

##### **1. Создание проекта в onesignal**

**\*** Если у вас в onesignal в списке приложений уже есть созданное (как в моем случае подключение к приложению и firebase), то выбираем его кликом. Если нет, то нужно создать новое, как, можно ознакомится в андроид версии этого документа.

[![image-1633274293226.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274293226.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274293226.png)

 **\*** Далее переходим в настройки

[![image-1633274315508.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274315508.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274315508.png)

**\*** На следующем экране нам понадобится .p12 сертификат для доступа onesignal к нашему приложению и пароль от него. Давайте разберемся с созданием сертификата для приложения если у вас такого еще не имеется.

[![image-1633274343603.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274343603.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274343603.png)

##### **2. Добываем сертификат .p12**

**\*** Заходим в Keychain Access меню выбираем Certificate Assistant и Request a Certificate from Certificate Authority

[![image-1633274363813.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274363813.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274363813.png)

**\*** На следующем экране вводим почту от своего apple аккаунта который используется для разработки, даем какое ни будь имя и выбираем сохранить на диск. Создастся запрос на сертификат в виде файла, который нам понадобится.

[![image-1633274498594.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274498594.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274498594.png)

##### **Создаем identifier**

**\*** Заходим в Certificates and Identifiers через[ https://developer.apple.com/](https://developer.apple.com/) Далее из меню слева выбираем Identifiers тут мы либо уже выбираем идентификатор, который был создан до вас и добавляем необходимые поля, либо создаем новый. Будь это новый либо уже существующий, выбрать нужно 2 вещи App Groups и Push Notifications, убедиться что эти два параметра выбраны.

1.

[![image-1633274532650.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274532650.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274532650.png)

2\.

[![image-1633274563052.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274563052.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274563052.png) 

**\*** Если нужно создавать новый identifier, то нажимаем на кнопку + (добавить) и на первом экране выбираем App ID

 1.

[![image-1633274648477.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274648477.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274648477.png)

2\.

[![image-1633274661173.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274661173.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274661173.png)

**\*** На следующем экране выбираем App

[![image-1633274684650.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274684650.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274684650.png)**\*** Следующий шаг будет добавление description и bundle id и выбор галочек напротив App Groups и Push Notifications из списка.

1.

[![image-1633274704053.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274704053.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274704053.png)

2\.

[![image-1633274751831.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274751831.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274751831.png)

**\*** Найти bundle id можно в проекте в Xcode

[![image-1633274769729.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274769729.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274769729.png)

- После заполнения всех полей нажимаем continue и если bundle id проходит проверку, то все создается, если bundle id не подходит, то выдаст сообщение об этом и нужно поменять его, как в Xcode так и в поле при регистрации identifier.

#####  **Создаем Certificate**

**\*** Далее нам нужно перейти на вкладку certificates в левом меню. Выбрать либо уже существующий сертификат, либо создать новый в котором мы укажем тот identifier, который мы только что создали. После сертификат нужно скачать на компьютер.

[![image-1633274822554.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274822554.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274822554.png)

 

**\*** Если нажали создать то в следующем окне нужно выбрать из списка пролистав вниз Apple Push Notification service SSL (sandbox &amp; production)

[![image-1633274909950.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274909950.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274909950.png)

**\*** Далее на новом экране нужно выбрать тот identifier из списка, который мы создавали и нажимаем далее.

[![image-1633274932228.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274932228.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274932228.png)

**\*** В следующем окне нам предложат загрузить certificate Signing request этот тот файл, который мы создавали и сохраняли на диск в начале, находим его, добавляем. После этого жмем кнопку далее и завершаем процесс. После этого кнопка сменится на Download нам нужно скачать новый сертификат для приложения на компьютер.

[![image-1633274984976.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633274984976.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633274984976.png)

**\*** После скачивания кликаем 2 раза по файлу, и он должен открыться в Keychain Store. Находим там наш файл, нажимаем правой кнопкой мыши и выбираем export “Apple push services..."

[![image-1633275034478.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275034478.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275034478.png)

##### **Продалжаем с onesignal**

**\*** Даем файлу название, придумываем пароль и сохраняем его с расширением .p12. После этого можно загружать этот файл в onesignal. Вводим пароль от сертификата на сайте такой же, как и при создании сертификата.

[![image-1633275059076.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275059076.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275059076.png)

#####  

****\*** После выбираем среду разработки в данном случае это ReactNative и идем далее.**

[![image-1633275153890.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275153890.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275153890.png)

\* На следующем экране нам нужно либо пройти в документацию, либо если с английским вы не в ладах продолжаем читать эту статью я опишу все по пунктам. С этого экрана нам в дальнейшем понадобится взять App ID если вы еще не устанавливали андроид версию (app id одинаковый для обоих версий android и ios), а пока нужно переключиться в Xcode и проделать работу по подготовке самого проекта. Оставляем пока этот экран открытым.

[![image-1633275228802.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275228802.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275228802.png)

##### **3. Настройка проекта в Xcode**

**\*** Нам нужно убедиться, что в проекте у нас установлены нужные Capabilities. Открываем Xcode с нашим проектом, выбираем его в колонке слева, выбираем проект в targets по середине, идем на вкладку Signing &amp; Capabilities выбираем All и нажимаем + Capability для добавления новой. Нам понадобится Push Notification.

[![image-1633275377115.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275377115.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275377115.png)

 

**\*** Такие же способом как только что добавили push notifications добавляем Background Modes из того же списка и здесь нам нужно будет открыть его после добавления и убедиться, что проставлена галочка напротив Remote notifications.

[![image-1633275398851.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275398851.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275398851.png)

 

**\*** Далее нужно добавить в проект новый Target с расширением Notification Service Extension. Для этого в левом верхнем углу выбираем file &gt; new &gt; target

[![image-1633275428333.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275428333.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275428333.png)

**\*** Находим в списке именно Notification SERVICE Extension нажимаем next

[![image-1633275453894.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275453894.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275453894.png)

 

\* В качестве product name вводим `OneSignalNotificationServiceExtension` и жмем кнопку завершить. В следующем окне нужно нажать на кнопку Cancel, а не activate.

[![image-1633275476703.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275476703.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275476703.png)

**\*** Нажимаем на **cancel**. Если всё же нажали на activate, то рядом с кнопкой запуска проекта вам нужно будет поменять схему запуска с onesignalnotification обратно на ваш проект. А то при запуске вы будете билдить не проект а что-то другое.

[![image-1633275509757.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275509757.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275509757.png)

**\*** Теперь нам нужно открыть podfile в проекте любым редактором, я открыл в Xcode и добавить следующие строки для подгрузки нашего target в проект. Вставить его нужно на тот же уровень что и наш главный таргет.

```JavaScript
target 'OneSignalNotificationServiceExtension' do

  pod 'OneSignal', '>= 3.0', '**\*** Далее закрываем Xcode и в терминале нужно убедится, что мы находимся в папке ios нашего проекта и запустить команду:

 `pod install`

**Отступление для маков на М1**

**\*\*\*** Для пользователей маков на M1 еще раз хочу предупредить что если будете делать pod install из нативного терминала, то возможно у вас будет ошибка как у меня. Для этого нужно запустить терминал через Rosetta 2.

[![image-1633275705991.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275705991.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275705991.png)

[![image-1633275792312.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275792312.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275792312.png)

[![image-1633275810376.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275810376.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275810376.png)

- После чего установка должна быть успешной без каких-либо ошибок

[![image-1633275848199.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633275848199.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633275848199.png)

 

**Продолжаем статью**

\* После успешной установки подов, открываем опять Xcode, находим слева в меню папку с файлом NotificationService.swift и заменяем все что есть внутри этого файла на код (скрин с путём к файлу после кода):

```JavaScript
import UserNotifications

import OneSignal 

class NotificationService: UNNotificationServiceExtension {

var contentHandler: ((UNNotificationContent) -> Void)?

var receivedRequest: UNNotificationRequest!

var bestAttemptContent: UNMutableNotificationContent?

override func didReceive(_ request: UNNotificationRequest, withContentHandler contentHandler: @escaping (UNNotificationContent) -> Void) {

     self.receivedRequest = request

     self.contentHandler = contentHandler

     self.bestAttemptContent = (request.content.mutableCopy() as? UNMutableNotificationContent)

     if let bestAttemptContent = bestAttemptContent {

         //If your SDK version is **\*** Теперь для того, чтобы у нас отрабатывал некоторый функционал onesignal правильно, например подтверждение доставки уведомлений нам нужно добавить App Group с определенными настройками в проект. Выбираем слева наш проект, по середине target с нашим проектом и уже по знакомой нам схеме добавляем App Group по аналогии с тем как мы добавляли Push Notifications выше.

[![image-1633276155010.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276155010.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276155010.png)

**\*** После добавления групп копируем свой bundle id он нам понадобится для наименования группы и нажимаем на + чтобы добавить группу.

[![image-1633276238653.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276238653.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276238653.png)

\* После нажатия на добавить появится окно, в котором вам нужно будет выбрать аккаунт или по-другому Team, выбираем ту, что стоит у вас в качестве Team в вашем проекте. К сожалению, я не успел сделать скриншот этого экрана, но думаю там все максимально просто и понятно.

[![image-1633276270734.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276270734.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276270734.png)

**\*** Далее вводим все по схеме `group.  .onesignal`

[![image-1633276301507.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276301507.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276301507.png)

**\*** Вот как это выглядит после добавления. Если вдруг у вас появится Debug и Release версии App Groups их нужно удалить и добавить App Groups заново и тогда все будет как на скринах. (Когда я первый раз добавил Team у меня создалось 2 группы, я их удалил, заново добавил Team и название и все стало так как на скрине внизу).

[![image-1633276339219.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276339219.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276339219.png)

 

\* Тот же самый процесс проделываем только выбрав на этот раз в качестве TARGET наш oneSignal. Но здесь при создании группы важно убедится, чтобы её название совпадало с тем что мы прописывали в первом случае для нашего приложения. По тому как в bundle id в данном случае добавляется в конец строка *OneSignalNotificationServiceExtension* 

Которая не должна указываться в названии группы. Еще раз, названия обеих групп должны быть одинаковы! Bundle id в этом случае = bundle id нашего приложения.

1.

[![image-1633276411945.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276411945.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276411945.png)

2\.

[![image-1633276464126.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276464126.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276464126.png)

 

##### **4. Переходим в IDE (инициализация в коде)**

**\*** Последним пунктом в нашей настройки будет добавление и инициализация кода с использованием нашего App id который нам сгенерировал onesignal выше, на сайте. Если вы уже подключали андроид то инициализировать уже ничего не нужно так как App id одинаковый для обоих платформ.Напомню, вот он

[![image-1633276539555.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276539555.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276539555.png)

\* Добавляем данный код в корневой файл нашего проекта, запускаем и тестируем push уведомления на ios.

```JavaScript
//OneSignal Init Code

OneSignal.setLogLevel(6, 0);

OneSignal.setAppId("YOUR-ONESIGNAL-APP-ID");

//END OneSignal Init Code

//Prompt for push on iOS

OneSignal.promptForPushNotificationsWithUserResponse(response => {

  console.log("Prompt response:", response);

}); 
```

[![image-1633276687380.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276687380.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276687380.png)

 

##### **5. Отправка уведомлений**

**\*** Как именно создавать и отправлять уведомления есть в конце статьи [про android здесь](https://wiki.rocketfirm.com/books/onesignal-push-uvedomleniya/page/onesignal-android-1lP) дабы не растягивать и без того длинный материал я пропущу этот моемнт, а вы же можете пройти по ссылке и посмотреть, как это делается. Я лишь приложу скриншот ниже с тем пришло ли уведомление или нет если делать все по схеме выше. Думаю ответ будет очевиден иначе к чему было это всё )). Есть лишь небольшое уточнение что, к сожалению, уведомления не работают в эмуляторе ios и тестировать их нужно на реальном устройстве, но, например prompt message который мы прописали приходит и подключение к onesignal можно определить следующим образом (если под рукой нет iphone как у меня) а понять что все работает хочется. 

Во-первых, у вас придет prompt уведомление и не будет ошибки в симуляторе о том, что promise onesignal, а именно это возвращает подключение к нему не разрезолвился. 

И второй момент, если вы пройдете на сайт onesignal где вам показывался ваш App id и нажмете Check Subscribed Users вам напишет очень много красного текста (скрин ниже) который говорит о том, что подключение к onesignal есть но оно происходит через эмулятор а потому уведомления приходить по этому адресу не будут. Нужно воспользоваться реальным устройством. 

[![image-1633276708107.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633276708107.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633276708107.png)

[![image-1633277238503.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633277238503.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633277238503.png)

Таким вот образом, не имея реального устройства под рукой, мы можем убедится, что подключены и ошибок на данный момент у нас нет. И при использовании реального устройства нам будут приходить уведомления.

Как видно на экране на сайте onesignal - **Audience &gt; All Users** - подключение есть но Ios Simulator Unsupported.

[![image-1633277249478.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633277249478.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633277249478.png)

 

В завершение хотелось бы поздравить вас с непростым подключением ios версии к onesignal. Это то, где больше всего возникает проблем и загвоздок, но как видите если сделать все грамотно и строго по шагам, то в итоге вас ждет удачное подключение!

Надеюсь у вас все получилось и данная статья помогла вам сделать это подключение менее стрессовым и затратным по времени.

 