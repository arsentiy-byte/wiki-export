# Книги > Менеджерский > Кейсы > Как писать кейсы

# Как писать кейсы

**План:**   
  
\- Описание клиента (вводная информация: особенности бизнеса, какие есть ресурсы, сильные и слабые стороны важные для кейса);   
\- С какой проблемой пришел клиент;  
\- Наши цели и задачи в рамках проекта;  
\- Описание технических действий (с чего взяли старт и к чему пришли);   
\- Интересные и необычные решения в рамках проекта (если были);   
\- Что планируем делать дальше;   
\- Подводим итоги (в заключительном слове общие выводы по проекту и где можно еще применить полученные методики технические);   
  
  
**Статьи по теме:**   
[https://vc.ru/marketing/119419-kak-napisat-keys-poshagovaya-instrukciya-i-shablon  
  ](https://vc.ru/marketing/119419-kak-napisat-keys-poshagovaya-instrukciya-i-shablon)[https://vc.ru/marketing/285893-kak-napisat-keys-pravilno-i-pochemu-bez-storitellinga-keys-budet-unylym  
  ](https://vc.ru/marketing/285893-kak-napisat-keys-pravilno-i-pochemu-bez-storitellinga-keys-budet-unylym)

[https://skillbox.ru/media/marketing/kak\_napisat\_keys\_esli\_vy\_ranshe\_nikogda\_nichego\_ne\_pisali/](https://skillbox.ru/media/marketing/kak_napisat_keys_esli_vy_ranshe_nikogda_nichego_ne_pisali/)

  
[https://sdelaem.agency/blog/pishem-keysi](https://sdelaem.agency/blog/pishem-keysi)