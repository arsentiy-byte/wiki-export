# Книги > Загрузка в систему Stada :: CT Mobile > Авторизация и создание презентации

# Авторизация и создание презентации

Для проверки презентаций используем доступы Stada :: CT Mobile в [https://pass.rocketfirm.com/  
  
](https://pass.rocketfirm.com/)Загрузку в сруду клиента осуществляем только по запросу клиента с доступами Stada :: СT Mobile PROD  
  
Авторизация  
![](https://lh7-us.googleusercontent.com/6CTTzdobotnlcgtoVDVu15hZI9qLQa4KlzDl9kuy07vditC0Q0PXUEfQl-HsSpPzeFtPk6Tz0esABjW7eI9WfW5LLySZfA-wElLGShVa2PHWj898UQg2BBUx656VHeX1iNz0wotyKRAw3s-kJyjs6jc)

Создание презентации в несколько этапов, выбираем создать и указываем тип презентации.

![](https://lh7-us.googleusercontent.com/iVQW3d5ps2NVo4kWoZ7Nf9cEalcs3ERhSHuZAWbIG1XshqNKuGGL9WeJHK_bw8YNOF_O3JkMs_OFRy1xRPNwdegUUxwHiOyH35x_7KZSOokj7nHpFMt4UyQdhOL-Cg91sRjv8t15Av0_WjTxsJ57h_k)

![](https://lh7-us.googleusercontent.com/f36ZijqKqGcgB4wyF6m1VroenF7LE_m23E0AyVcPinAcfBNl95xseeLnFUj1g_o3FxPQXewdqY6oXGBqtpvGf25Di4F48R2mMPrFm53Q_P7jaKvmOzGV8IwswNYrtH8DJJYWp9TPscwyDpjaCND_Y8w)

  
  
Заполняем обязательные поля  
- название состоит из KZ (страна) \_ RU (язык) \_ название препарата (после названия можно указать направление например: Farm, therapist)

- Дата загрузки, указываем текущую дату, чтобы получить презентацию на планшет

![](https://lh7-us.googleusercontent.com/_q9FIUbEoBNKZSFbAZrhNQ0rwxidYmvNRrp8k0_9pkb4tAYRuk0EMNFtLA22EMYOaa_ifN1jh9YUHlsBrK662koZFaQfFqXc00NcW_BHeSMw5gJy2k884lsAxwLvodeDH4LiWMt6nKmCLsIuOv-wFCc)