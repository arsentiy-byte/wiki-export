# Книги > RTE в Mi > Авторизация

# Авторизация

1. авторизоваться в системе под пользователем rocket-1

[![image-1649244064744.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244064744.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244064744.png)

2\. переходим в раздел управления e-mail шаблонами

[![image-1649244105842.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244105842.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244105842.png)

  
![](https://wiki.rocketfirm.com/images/image27.png)