# Книги > Caps Arena > Промокоды > Java-сервис promo

# Java-сервис promo

Схема: [https://drive.google.com/file/d/17h75-Vu0v9qyEI47TWNdX4ISFd5V-Zky/view?usp=sharing](https://drive.google.com/file/d/17h75-Vu0v9qyEI47TWNdX4ISFd5V-Zky/view?usp=sharing)

БД: [https://dbdiagram.io/d/64cb512202bd1c4a5e2af1c2](https://dbdiagram.io/d/64cb512202bd1c4a5e2af1c2)

##### Взаимодействие с CAPS

1. Создание промокодов: [https://drive.google.com/file/d/1WmuwI4gsQauuZPWwcEGcnUOYzk2mQR6Y/view?usp=sharing](https://drive.google.com/file/d/1WmuwI4gsQauuZPWwcEGcnUOYzk2mQR6Y/view?usp=sharing)
2. Получение списка промокодов [https://drive.google.com/file/d/1ExvPhwbF2Dc6k-ufKkRGGiQl9Xcrn3f-/view?usp=sharing](https://drive.google.com/file/d/1ExvPhwbF2Dc6k-ufKkRGGiQl9Xcrn3f-/view?usp=sharing)
3. Удаление промокодов: [https://drive.google.com/file/d/1ExvPhwbF2Dc6k-ufKkRGGiQl9Xcrn3f-/view?usp=sharing](https://drive.google.com/file/d/1ExvPhwbF2Dc6k-ufKkRGGiQl9Xcrn3f-/view?usp=sharing)
4. Редактирование промокодов: [https://drive.google.com/file/d/12pZXVxRd2QAM8liJZXcsGt2Y3O2NyDZd/view?usp=sharing](https://drive.google.com/file/d/12pZXVxRd2QAM8liJZXcsGt2Y3O2NyDZd/view?usp=sharing)
5. Активация промокодов: [https://drive.google.com/file/d/1xCe94562uc\_SSfUxfUyX9OZwE9DsPVLH/view?usp=sharing](https://drive.google.com/file/d/1xCe94562uc_SSfUxfUyX9OZwE9DsPVLH/view?usp=sharing)

##### Тестовый сервер:

1. **RabbitMQ** login: admin; password: aMxz4I3RbRZYBvHFrxfZ 
    1. API [http://promocodes.capsarena.kz:5672](http://158.160.55.74:5672)
    2. Management [http://](http://158.160.55.74:3000)[promocodes.capsarena.kz](http://158.160.55.74:5672)[:1](http://158.160.55.74:3000)5672
2. **Документация AsyncAPI**
    1. Управление промокодами http://[promocodes.capsarena.kz](http://158.160.55.74:5672):8090/springwolf/asyncapi-ui.html
    2. Активация промокодов http://[promocodes.capsarena.kz](http://158.160.55.74:5672):8095/springwolf/asyncapi-ui.html
3. **Grafana** [http://](http://158.160.55.74:3000)[promocodes.capsarena.kz](http://158.160.55.74:5672)[:3000](http://158.160.55.74:3000) login: admin; password: iLm)F7A92-#@
4. **БД** [promocodes.capsarena.kz](http://158.160.55.74:5672)[:5433](http://158.160.55.74:3000) **promo\_2** login: postgres; password: UuwcNntQA8JHWUvu5zhP

Заготовка таблицы по состояниями и текстам ошибок промокодов [https://docs.google.com/spreadsheets/d/1UTVpv2AXE0BkJ1M0ZK49q1qNkNeTGohGRv5sR1Hzfk8/edit?usp=sharing](https://docs.google.com/spreadsheets/d/1UTVpv2AXE0BkJ1M0ZK49q1qNkNeTGohGRv5sR1Hzfk8/edit?usp=sharing)