# Книги > Archived > Live чат на Firebase > Подключение IOS :: Установка firestore

# Подключение IOS :: Установка firestore

Детально про установку firestore в проект я описывал в [гайде по андроиду](https://wiki.rocketfirm.com/books/live-chat-na-firebase/page/ustanovka-firestore). Не думаю что сейчас есть смысл здесь повторять все тоже самое что было описано там. Все пункты остаются неизменными так как тут уже идет подключение не к конкретной платформе а к вашему проекту.

Так же более детально по подключению самого компонента gifted chat, добавлению сообщений и прочих хитростях можно почитать в [веб версии этого гайда](https://wiki.rocketfirm.com/books/live-chat-na-firebase/chapter/podklyuchenie-web).