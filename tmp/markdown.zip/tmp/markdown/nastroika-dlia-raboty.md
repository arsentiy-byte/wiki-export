# Книги > Mattermost > Начало работы с мм > Настройка для работы

# Настройка для работы

Все эти настройки находятся под иконкой [![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/Am2image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/Am2image.png) в правом верхнем углу. Что может быть полезно.

1. Отображать коллег по их именам  
    **Settings &gt; Display &gt; Teammate Name Display &gt; Show first and last name**
2. Установить формат времени 24-х часовой **Settings &gt; Display &gt; Teammate Name Display &gt; Clock Display**
3. Настроить персональную темы  
    Там огромнейший простор для воображения  
    **Settings &gt; Display &gt; Teammate Name Display &gt; Theme**
4. Временную зону   
    Если стоит +06, моэно вручную поменять на +05  
    **Settings &gt; Display &gt; Teammate Name Display &gt; Timezone**
5. Язык интерфейса  
    **Settings &gt; Display &gt; Teammate Name Display &gt; Language**