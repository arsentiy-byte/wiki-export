# Книги > Bazis-a: сервис продажи квартир > История изменений проекта

# История изменений проекта

##### Проект открыт 09.06.2021

Приложение 1 09.06.2021 - Функционал личного кабинета и система бронирования

[https://intra.rocketfirm.com/clients/adds/view-add/?id=1754](https://intra.rocketfirm.com/clients/adds/view-add/?id=1754)

Приложение 2 09.06.2021 - Функционал личного кабинета и система бронирования

[https://intra.rocketfirm.com/clients/adds/view-add/?id=1988](https://intra.rocketfirm.com/clients/adds/view-add/?id=1988)

Приложение 3 01.02.2022 - Функционал модального окна для подключения к sigex и подписанию эцп

[https://intra.rocketfirm.com/clients/adds/view-add/?id=2103](https://intra.rocketfirm.com/clients/adds/view-add/?id=2103)

Приложение 4 30.03.2022 - Функционал эквайринга халык банк

[https://intra.rocketfirm.com/clients/adds/view-add/?id=2189](https://intra.rocketfirm.com/clients/adds/view-add/?id=2189)

Приложение 5 17.05.2022 - Функционал оформления дду. Подключение системы для создания договора и обмена документами для покупки

[https://intra.rocketfirm.com/clients/adds/view-add/?id=2217](https://intra.rocketfirm.com/clients/adds/view-add/?id=2217)

Приложение 6 03.06.2022 - Функциональные доработки системы бронирования (небольшие обновления дизайна и рестов для дополнительных данных из срм)

[https://intra.rocketfirm.com/clients/adds/view-add/?id=2280](https://intra.rocketfirm.com/clients/adds/view-add/?id=2280)

Приложение 7 17.06.2022 - Функционал эквайринга каспи банк

[https://intra.rocketfirm.com/clients/adds/view-add/?id=2295](https://intra.rocketfirm.com/clients/adds/view-add/?id=2295)

Приложение 8 17.06.2022 - Функциональные доработки системы бронирования (небольшие обновления дизайна и рестов для дополнительных данных из срм)

[https://intra.rocketfirm.com/clients/adds/view-add/?id=2296](https://intra.rocketfirm.com/clients/adds/view-add/?id=2296)

Приложение 9 11.11.2022 - Функциональные доработки системы дду (убрали первый лист эцп, договор отображается в кабинете теперь после получения выписки из казреестра)

[https://intra.rocketfirm.com/clients/adds/view-add/?id=2509](https://intra.rocketfirm.com/clients/adds/view-add/?id=2509)

Приложение 10 15.11.2022 - Функциональные доработки системы дду (добавили рест для получения списка банков, отключение требования выписки за банка клиента, разработка справочника для выборочного включения дду у пятен жк)

 [https://intra.rocketfirm.com/clients/adds/view-add/?id=2519](https://intra.rocketfirm.com/clients/adds/view-add/?id=2519)