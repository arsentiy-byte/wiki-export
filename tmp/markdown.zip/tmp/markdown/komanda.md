# Книги > Методология > Домены > Команда

# Команда

[PMO 2.pdf](https://wiki.rocketfirm.com/attachments/133)