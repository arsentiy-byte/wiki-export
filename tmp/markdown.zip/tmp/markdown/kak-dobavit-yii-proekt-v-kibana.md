# Книги > PHP > Yii2 > Как добавить yii проект в kibana

# Как добавить yii проект в kibana

На примере настройки kibana в проекте intra.

1. Там как нашелся только один пакет, который нормально встал на наш проект и то с ошибкой, пришлось взять его за основу и немного переписать.  
      
    Сам пакет лежит тут [https://github.com/airani/yii2-elasticsearch-log](https://github.com/airani/yii2-elasticsearch-log). Но там ошибка при формировании url endpoint. поэтому мы берем код, немного переписываем и складываем куда-нибудь, например в компоненты. ```php
    
     * @since 2.0
     */
    class ElasticsearchTarget extends Target
    {
        /**
         * @var string Elasticsearch index name
         */
        public $index = 'yii';
    
        /**
         * @var Connection|array|string the elasticsearch connection object or the application component ID
         * of the elasticsearch connection
         */
        public $db = 'elasticsearch';
    
        public $options = [];
    
        /**
         * @inheritdoc
         */
        public function init()
        {
            parent::init();
            $this->db = Instance::ensure($this->db, Connection::className());
        }
    
        /**
         * @inheritdoc
         */
        public function export()
        {
            $messages = array_map([$this, 'prepareMessage'], $this->messages);
            $body = implode("\n", $messages) . "\n";
            $this->db->post([$this->index, '_bulk'], $this->options, $body);
        }
    
        /**
         * @inheritdoc
         */
        public function collect($messages, $final)
        {
            $this->messages = array_merge($this->messages, static::filterMessages($messages, $this->getLevels(), $this->categories, $this->except));
            $count = count($this->messages);
            if ($count > 0 && ($final || $this->exportInterval > 0 && $count >= $this->exportInterval)) {
                // set exportInterval to 0 to avoid triggering export again while exporting
                $oldExportInterval = $this->exportInterval;
                $this->exportInterval = 0;
                $this->export();
                $this->exportInterval = $oldExportInterval;
    
                $this->messages = [];
            }
        }
    
        /**
         * Prepares a log message
         * @param array $message The log message to be formatted
         * @return string
         */
        public function prepareMessage($message)
        {
            list($text, $level, $category, $timestamp) = $message;
    
            $result = [
                'category' => $category,
                'level' => Logger::getLevelName($level),
                '@timestamp' => date('c', $timestamp),
            ];
    
            if (isset($message[4])) {
                $result['trace'] = $message[4];
            }
    
            if ($text instanceof \Exception) {
                $result['message'] = $text->getMessage();
                $result['exception'] = [
                    'file' => $text->getFile(),
                    'line' => $text->getLine(),
                    'code' => $text->getCode(),
                    'trace' => $text->getTraceAsString(),
                ];
            } elseif (is_string($text)) {
                $result['message'] = $text;
            } else {
                $result['message'] = VarDumper::export($text);
            }
    
            $result = array_merge($result, $this->getExtraFields());
    
            $message = implode("\n", [
                Json::encode([
                    'index' => new \stdClass()
                ]),
                Json::encode($result)
            ]);
    
            return $message;
        }
    
        private $_extraFields = [];
    
        /**
         * Returns extra fields
         * @return array
         */
        public function getExtraFields()
        {
            return $this->_extraFields;
        }
    
        /**
         * Set extra fields
         * @param array $fields
         */
        public function setExtraFields(array $fields)
        {
            foreach ($fields as $name => $field) {
                if ($field instanceof \Closure || is_array($field) && is_callable($field)) {
                    $this->_extraFields[$name] = call_user_func($field, Yii::$app);
                } else {
                    $this->_extraFields[$name] = $field;
                }
            }
        }
    }
    
    ```
    
    из оригинала убрали переменную $type и всё, чт ос ней связано. Она нам всё портит.
2. В проекте должен быть установлен пакет [https://github.com/yiisoft/yii2-elasticsearch](https://github.com/yiisoft/yii2-elasticsearch)
3. Добавляем настройки в конфиг (какой-нибудь config/main.php)

```
'log' => [
    'traceLevel' => 3,
    'targets' => [
        ...
        [
            'class' => 'app\components\ElasticsearchTarget',
            'levels' => ['error', 'warning'],
            'index' => 'HERE_PUT_THE_KINABA_INDEX',
            'db' => 'elasticsearch',
            'extraFields' => [
                'ip' => function ($app) {
                    return $app->request->getUserIP();
                }
            ]
        ],
        ...
    ],
],
...
'elasticsearch' => [
    'class' => 'yii\elasticsearch\Connection',
    'nodes' => [
        ['http_address' => 'IP:PORT'],
        // configure more hosts if you have a cluster
    ],
    'defaultProtocol' => 'https',
    # данные для входа что мы создали ранее
    'auth' => ['username' => 'LOGIN', 'password' => 'PASSWORD'],
    'curlOptions' => array(CURLOPT_SSL_VERIFYPEER => false)
],
...
```

Тут нужно заполнить:  
HERE\_PUT\_THE\_KINABA\_INDEX - индекс в кибане  
IP:PORT - IP и порт базы данных  
LOGIN, PASSWORD - креды для подключения к базе данных