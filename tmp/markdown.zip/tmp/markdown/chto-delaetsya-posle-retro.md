# Книги > Ретроспектива: теория > Что делается после ретро?

# Что делается после ретро?

С ретроспективы вы вынесли список проблем и примерных решений (или хотя бы первых шагов для решения)

Что же дальше? Менеджер проекта по итогам встречи сохраняет её результаты:

1. Напишите отчёт в Вики [https://wiki.rocketfirm.com/books/arkhiv-retrospektiv](https://wiki.rocketfirm.com/books/arkhiv-retrospektiv)   
      
    В качестве шаблона используйте первый отчёт   
    [https://wiki.rocketfirm.com/books/arkhiv-retrospektiv/page/stada-stopgrip-ves-proekt-28122021](https://wiki.rocketfirm.com/books/arkhiv-retrospektiv/page/stada-stopgrip-ves-proekt-28122021)
2. Создайте истории на доске в Джире по каждой выделенной проблеме (которые возможно решить)  
    [https://jira.rocketfirm.com/secure/RapidBoard.jspa?projectKey=RBD](https://jira.rocketfirm.com/secure/RapidBoard.jspa?projectKey=RBD)
3. Добавьте в отчёт ссылки на истории