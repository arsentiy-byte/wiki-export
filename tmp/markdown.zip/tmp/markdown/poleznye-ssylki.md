# Книги > Frontend > ROCKETFRONT-HYBRID > Полезные ссылки

# Полезные ссылки

Список полезных ссылок на документации и туториалы в которых информация о используемых архитектурных решениях, принципах и шаблонах проектирования.

- [Документация Nuxt.js](https://nuxtjs.org/)
- [Документация Vue.js](https://vuejs.org/)
- [Документация Vue-Test-Utils](https://vue-test-utils.vuejs.org/)
- [Документация Jest](https://jestjs.io/ru/docs/getting-started)
- [Документация Capacitor.js](https://capacitorjs.com/docs)
- [Атомарный дизайн](https://atomicdesign.bradfrost.com/chapter-2/)
- [CDD (Component Driven Development) разработка](https://www.componentdriven.org/)
- [\[Воркшоп\] Андрей Мелихов — Теория и практика dependency injection](https://youtu.be/inJMee0Jl90)
- [Чистая Архитектура для веб-приложений](https://habr.com/ru/post/493430/)
- [Рефакторинг и Паттерны проектирования](https://refactoring.guru/ru)

---

Ссылки будут еще дополняться