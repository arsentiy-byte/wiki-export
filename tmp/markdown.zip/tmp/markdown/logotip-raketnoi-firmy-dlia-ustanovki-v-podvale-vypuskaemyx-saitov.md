# Книги > Archived > Логотип Ракетной фирмы (для установки в подвале выпускаемых сайтов)

# Логотип Ракетной фирмы (для установки в подвале выпускаемых сайтов)

SVG лого (пример на светлом фоне):

[![image-1626944772796.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/scaled-1680-/image-1626944772796.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/image-1626944772796.png)

SVG лого (пример на темном фоне):

[![image-1626944748157.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/scaled-1680-/image-1626944748157.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-07/image-1626944748157.png)

Шрифт, который необходимо подключить для корректного отображения года (архив можно скачать по ссылке): [RocketFont](https://markup.rocketfirm.net/rocket-logo/rocket-font.zip)

Стили, которые необходимо прописывать для каждого проекта. Если нет необходимости в адаптации стилей под палитру текущего проекта, можно использовать дефолтные стили:

```CSS
/***  стили родительской ссылки, в которой лежит наш svg ***/
.rocket-link {
  position: relative;
  display:inline-block;
  width: 120px;
  height: 17px;
  color: rgb(0,0,0);
  /**задать transition для букв лого можете здесь
  -webkit-transition: .3s;
  transition: .3s;**/
}
/*** состояние родительской ссылки при наведении - цвет на который будут ориентироваться детали в svg. ***/
.rocket-link:hover,
.bg--black .rocket-link:hover {
  color: #ef4423;
}
/***  стили для рамки с текущим годом ***/
.rocket-link .logo-year {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  display: inline-block;
  position: absolute;
  left:104%;
  top: 2px;
  padding: 1px 3.5px 0px;
  border: 1px solid rgb(0,0,0);
  border: 1px solid rgba(0,0,0,.6);
  color: rgb(0,0,0);
  color: rgba(0,0,0,.6);
  border-radius: 2px;
  font-family:'rocket-font';
  font-size: 10px;
  line-height: 10px;
  /* задать transition для рамки и текста года можно здесь */
  /* transition: border-color .3s, color .3s; */
}
.rocket-link:hover .logo-year,
.bg--black .rocket-link:hover .logo-year {
  border-color: rgb(239,68,35);
  border-color: rgba(239,68,35,.6);
  color: rgb(239,68,35);
  color: rgba(239,68,35,.6);
}
/***  состояния деталей svg элемента при наведении на родительскую ссылку. 
currentColor означает, что цвет будет всегда наследоваться от родительской ссылки,
будь то наведение, или статика ***/
.rocket-logo .logo-letter {
  fill: currentColor;
}
/***  цвет иконки с ракетой. задаем отдельно от всех остальных элементов ***/
.rocket-logo .logo-icon {
  fill: rgb(239,68,35);
}
```

Код (можно смело копировать и использовать в разметке любого проекта Ракетной фирмы). Год можно менять вручную, просто вводим требуемую цифру в элементе span с классом .logo-year:

```HTML

  
    Rocket Firm logo
    
    
    
    
    
    
    
    
    
    
    
    
  
  2016

```