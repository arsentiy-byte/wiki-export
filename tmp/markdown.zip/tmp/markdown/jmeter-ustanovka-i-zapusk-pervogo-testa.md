# Книги > QA > Нагрузочное тестирование (Perfomance testing) > JMeter - установка и запуск первого теста

# JMeter - установка и запуск первого теста

##### JMeter - инструмент для нагрузочного тестирования (аналог Locust)

1) Перед установкой программы необходимо проверить что на вашем пк установлена java:

```
java -version
```

если java не установлена - скачайте с [официального сайта](https://www.java.com/en/download/)

2) Затем скачайте Binaries архив с [официального сайта ](https://jmeter.apache.org/download_jmeter.cgi)и разархивируйте в удобное место 

3) Для запуска программы:

3.1) на WindowsOS дважды кликнуть на файл "jmeter.bat”

3.2) на MacOS через командную строку для директории jmeter/bin : 

```
./jmeter.sh
```

4) Порядок действий для запуска простейшего теста 

4.1. создаём тестовую группу Test Plan -&gt; Threds (Users) -&gt; Thread Group

![](https://lh7-us.googleusercontent.com/NkY6bQMf6eMHtiAEegjok5WwU6EAxHG1e3dC3ID9AT0NahjhBm1mUkpIiyKAEGIDKkU_96_C4SAsuglvkSFUotdQlTUeYtzBgjn7bmsi4jqWRyiyyBL4rcSZKQCLMqHWw_Ye316s61qGGm6whnMGyc4)

4.2. добавляем HTTP запрос: Add-&gt;Sampler-&gt;HTTP Request 

![](https://lh7-us.googleusercontent.com/NmilP_srlSMNa517xdq1F2J479EynqB6geRczMt7IEYdebHUCP8Es1DfVLY0YqJvRYh9Vd6H-iUT_SLahdH5Hljl4FstQvOreci4TXwGCiFXo7aeQytSyE_XHG0l3gBtscgoOc8M0POQxq9klzD6yKY)

4.3. добавляем отчёты двух видов:

Add-&gt;Listener-&gt;View Result Tree

Add-&gt;Listener-&gt;Summary Report

![](https://lh7-us.googleusercontent.com/Ej-okz3kiTFHvgeZaO64TBrWzULrOxsSSqCOF34X6onmbzgkm25Lrdr9BguDrsJng9Jqk00EVbhnC5kqlXbVVpMejfTV0E8rZKNcyDO365SqDUrfB3gnRxn1jpR-Lakk8muMJtuF8RBDvvBnuWO5j_0)

4.5. Указываем сайт для тестирования:

![](https://lh7-us.googleusercontent.com/2j1dhCmbx5-wYbErUE3IhnsAawRn8P_quImmPDvtInQ9EFOOHtfx9SQr93xBf3JBqnvC47Dc0mT0w0rjF8miPjmPhvbtlWR97JzjepYCfs5qDUX3M5c0tuQorFsXs5tbUIzTbP5eU5Bos4WCzE5PbuA)

- указываем протокол http / https
- указываем домен сайта 
- выбираем тип запроса GET / POST и т.п.
- поле Path не заполняем если обращаемся к главной странице сайта и заполняем если хотим обратиться к конкретному разделу сайта, например корзина "/cart" и т.п.

4.6. Настройка нагрузки в разделе Thread Group

![](https://lh7-us.googleusercontent.com/Su16U50NT8p-dM8sPRYzWIKxXJi8GgtZYMRzQ7tBVOh7Jg2PyGV8TtYxBbJx0XzCJZ9oY_2N8iiD385dJH7PpjPGl9BpEWdGurlPaqOW5SeXu_OiFy4mZx98GxV0BF3PELtN3JLAsSbsxofOnwbLdgI)

- Number of Threads: число “пользователей” которые выполняют наши запросы
- Ramp-up period: какую задержку перед запуском следующего пользователя нужно сделать. Например, если у нас 100 пользователей и период Ramp-Up 100 секунд, то задержка между запуском пользователей составит 1 секунду (100 секунд /100 пользователей).
- Loop Count: Число повторений цикла. (Есть опция чекбокса Infinite - это бесконечное выполнение теста)

5. Анализ результатов 

в Summary Report мы видим различные данные по числу запросов, времени их обработки и т.д.:

![](https://lh7-us.googleusercontent.com/1T8HU5bVkrp0z1sDjxn6tZMjup22i50g-g4Ya0Z60IpjIqIKOPzm9Wwym8IWynJHG6jXzuqbh3CGr8tkilDA7f3WYcnWkhpaYS2-wDqpmxQDZZ064B-5ebfBQtvyqe_lkr9WIugI7NPd7zQd2GOkGis)

в разделе View Result Tree мы можем увидеть статусы выполнения запроса (зелёный - ок, красный - ошибка), код запроса и данные ответа:

[![view result tree.PNG](https://wiki.rocketfirm.com/uploads/images/gallery/2024-01/scaled-1680-/view-result-tree.PNG)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-01/view-result-tree.PNG)

**6. Важные замечания:**

6.1. JMeter не считает RPS, но эту величину можно получить используя общее время выполнения теста в правом верхнем углу экрана программы.

6.2. JMeter не эмулирует поведения пользователя в браузере (как playwright), то есть если мы сделаем сценарий с последовательным обращаем на разные разделы сайта например “/item”, “/cart” и т.д. то фактически мы реализуем просто каждый раз новые запросы на разные разделы сайта. 