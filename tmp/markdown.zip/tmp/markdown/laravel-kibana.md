# Книги > PHP > Laravel cookbook > Laravel + Kibana

# Laravel + Kibana

Настраиваем логи проекта в kibana:  
  
1\. Если в проекте не установлен elastic, то устанавливаем пакет

```bash
composer require elasticsearch/elasticsearch
```

2\. В config/logging.php добавляем конструкцию:

```php
    'channels' => [
        ...

        'es-log' => [
            'driver' => 'monolog',
            'level' => 'debug',
            'handler' => \Monolog\Handler\ElasticsearchHandler::class,
            'formatter' => \Monolog\Formatter\ElasticsearchFormatter::class,
            'formatter_with' => [
                'index' => env('KIBANA_LOGS_INDEX'),
                'type' => '_doc',
            ],
            'handler_with' => [
                'client' => env('KIBANA_LOGS_INDEX') ?  \Elastic\Elasticsearch\ClientBuilder::create()->setHosts([env('KIBANA_HOST')])->setSSLVerification(false)->setBasicAuthentication(env('KIBANA_HOST_LOGIN'), env('KIBANA_HOST_PASSWORD'))->build() : null,
            ]
        ]
    ]
```

3\. Далее devOps на серверах прописывают в .env

```
KIBANA_HOST=
KIBANA_LOGS_INDEX=
KIBANA_HOST_LOGIN=
KIBANA_HOST_PASSWORD=
LOG_CHANNEL=
```

Правило именования KIBANA\_LOGS\_INDEX: Код\_проекта\_в\_jira-back/front-prod/dev.  
Например, для проекта фридом брокер для дева бэка код будет: **FREEDBRO-BACK-DEV**

> Источники:
> 
> [https://tasmidur.medium.com/laravel-log-management-using-elasticsearch-and-kibana-10f0af42fd60](https://tasmidur.medium.com/laravel-log-management-using-elasticsearch-and-kibana-10f0af42fd60)
> 
> [https://github.com/elastic/elasticsearch-php](https://github.com/elastic/elasticsearch-php)