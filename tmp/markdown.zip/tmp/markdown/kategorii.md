# Книги > Mattermost > Функциональность > Категории

# Категории

1\. Каналы можно делить по категориям. Чтобы создать новую категорию нужно жмакнуть по контекстному меню "CHANNELS" или лююбой другой категории.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/NVYimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/NVYimage.png)

2\. Добавить канал в категорию можно перетаскиванием.   
  
3\. Категорию можно свернуть. При этом новые сообщения в канале будут приводить к тому, что канал будет "вылазить" из свёрнутой категории.

4\. Все каналы в группе можно замьюьить. При этом если вас будут тэгать в замьюченом канале, то он будет также будет "вылазить" из свёрнутой категории и показывать новое сообщение.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/scaled-1680-/OA7image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-09/OA7image.png)