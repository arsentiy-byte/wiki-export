# Книги > Книги, блоги, лекции > Книги, блоги, лекции

# Книги, блоги, лекции

### Мастхэв

1. Ководство Лебедева: мастхэв для дизайнера из СНГ — [artlebedev.ru/kovodstvo/sections](http://www.artlebedev.ru/kovodstvo/sections/)
2. Дизайн привычных вещей, Дональд Норман — [lib.rus.ec/b/177471](https://lib.rus.ec/b/177471) (о том, для чего нужен дизайн)
3. Дизайн дизайнера. Лекция Людвига Быстроновского об усложнении дизайнера — [Плейлист из 17 частей](https://www.youtube.com/watch?v=J44KDrFzgRk&list=PLaT7oepoc8P6L0XMuohRTT9X8YMEo4Po6)
4. Лекция Людвига Быстроновского о том, «Как устроить свою работу, чтобы было интересно». [Смотреть на ютюбе](https://youtu.be/CsFJzkNG5EY).
5. Дизайн для реального мира. Виктор Папанек.
6. Чему вас не научат в дизайн-школе. Фил Кливер.

### На каждый день

Пусть станет привычкой читать пару постов с утра. Будет вырабатываться вкус и критический взгляд.

1. Бизнес-линч студии Лебедева — [artlebedev.ru/kovodstvo/business-lynch](http://www.artlebedev.ru/kovodstvo/business-lynch/)
2. Советы студии Горбунова — [artgorbunov.ru/bb/soviet](http://artgorbunov.ru/bb/soviet/)
3. Блог Ильи Бирмана — [ilyabirman.ru/meanwhile](http://ilyabirman.ru/meanwhile/)
4. Рассылка Антона Жиянова «Интерфейсы без шелухи» — [dangry.ru/sin](https://dangry.ru/sin/)

### Типографика

1. Настольная книга газетного дизайнера. Тим Харроуэр. Скачать PDF: [yadi.sk/i/aWxuJ-Ks3DZ6dY](https://yadi.sk/i/aWxuJ-Ks3DZ6dY)
2. Новая типографика. Руководство для современного дизайнера. Ян Чихольд.
3. Основы стиля в типографике. Роберт Брингхерст.
4. Блог Рассказова о типографике — [rasskazov.pro/blog](http://rasskazov.pro/blog/)
5. Журнал «Шрифт» — [typejournal.ru](http://typejournal.ru/)

### Верстка

1. «[Типографика и верстка](http://artgorbunov.ru/projects/book-typography/)», Артем Горбунов.
2. Облик книги. Ян Чихольд — [flibusta.net/b/268225](http://flibusta.net/b/268225)
3. Квадраты и сетки. На языке шаблона. Марк Хэмпшир, Кейт Стефенсон.
4. Вдохновляться:  
    [dimabarbanel.com](http://dimabarbanel.com/)  
    [butdoesitfloat.com/index/filter/typography](http://butdoesitfloat.com/index/filter/typography)
5. [Сборник статей](http://igorshtang.ru/articles/) о верстке Игоря Штанга.

### Интерфейсы

1. Психбольница в руках пациентов, Алан Купер — [flibusta.net/b/106825](http://flibusta.net/b/106825)
2. Интерфейс: новые направления в проектировании компьютерных систем, Джефф Раскин — [flibusta.is/b/129607](https://flibusta.is/b/129607)

