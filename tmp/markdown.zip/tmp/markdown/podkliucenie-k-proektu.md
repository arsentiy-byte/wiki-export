# Книги > Archived > Live чат на Firebase > Подключение к проекту

# Подключение к проекту

**4. Подключение конфига и инициализация в проекте**

Конфиг и база готовы, переходим к подключению. В проекте создаем файл обычно это firebase.js и вставляем в него наши данные. Файл firestore.js должен выглядеть так, (в данном случае мы не используем аутентификацию так как у нас уже есть реализованный вход в приложение, при необходимости можно добавить и ее).

- Наш конфиг который скопировали ранее
- Через if смотрим есть ли активная сессия firebase если нет то создаем ее, если есть используем
- Инициализируем доступ к базе firestore в переменной db используя активное подключени и экспортируем ее для дальнейшего использования

```javascript
import * as firebase from 'firebase';
import 'firebase/firestore';

var firebaseConfig = {
  apiKey: 'AIzaSyAvkwI3x8UtdRk3dAxHViTzRXUsEYxGqfs',
  authDomain: 'pnmts-chat-38065.firebaseapp.com',
  projectId: 'pnmts-chat-38065',
  storageBucket: 'pnmts-chat-38065.appspot.com',
  messagingSenderId: '185080440784',
  appId: '1:185080440784:web:4d4c6340e8281e5143fbd5',
};

let app;

if (firebase.apps.length === 0) {
  app = firebase.initializeApp(firebaseConfig);
} else {
  app = firebase.app();
}

const db = app.firestore();
export { db };
```

