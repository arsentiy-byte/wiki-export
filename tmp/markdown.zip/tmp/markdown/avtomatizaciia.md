# Книги > PHP > Swagger > Автоматизация

# Автоматизация

Если у вас в проекте настроен deployer, то для автоматизации процесса загрузки файла документации на [http://swagger.rocketfirm.net/](http://swagger.rocketfirm.net/) можно добавить в файл deploy.php:

- еще один путь (swagger\_path)

```PHP
host('rocketfirm.net')
  ->stage('stage')
  ->user($userStage)
  ->set('branch', 'develop')
  ->set('deploy_path', '/var/www/vhosts/rocketfirm.net/pinmates.rocketfirm.net')
  ->set('keep_releases', 3)
  ->set('swagger_path', '/var/www/vhosts/rocketfirm.net/swagger.rocketfirm.net');
```

- команду (swagger:update)

```PHP
desc('Update api docs on swagger.rocketfirm.net');

task('swagger:update', function () {
   $stage = get('stage');
   if ($stage != 'prod') {
       run('yes | cp {{release_path}}/swagger_api.yaml {{swagger_path}}/data/test_api.yaml');
   }
});

after('deploy:symlink', 'swagger:update');
```