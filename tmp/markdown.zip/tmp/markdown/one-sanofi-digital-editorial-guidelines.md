# Книги > Sitecore CMS > Guidelines_&_UserManual > ONE SANOFI DIGITAL EDITORIAL GUIDELINES

# ONE SANOFI DIGITAL EDITORIAL GUIDELINES

[![image-1642416913476.54.57.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642416913476-54-57.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642416913476-54-57.png)

**Ссылка на документ:** [ONE\_SANOFI\_DIGITAL\_EDITORIAL\_GUIDELINES\_V4\_LD.pdf](https://disk.yandex.kz/i/76k6ZTHy-2Uzuw)