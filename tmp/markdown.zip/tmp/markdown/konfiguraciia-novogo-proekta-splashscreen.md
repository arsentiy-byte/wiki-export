# Книги > Archived > ROCKETFRONT-REACTNATIVE (ЧЕРНОВИК) > Конфигурация нового проекта :: Splashscreen

# Конфигурация нового проекта :: Splashscreen

#### **Создаем PNG формат (2000 x 3000)**

[![image-1648664241235.17.15.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/scaled-1680-/image-1648664241235-17-15.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/image-1648664241235-17-15.png)

#### **Создаем ресурсы**

Сайт [AppIcon](https://appicon.co/#image-sets)

Импортируем картинку и называем launch\_screen

[![image-1648664442902.20.39.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/scaled-1680-/image-1648664442902-20-39.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-03/image-1648664442902-20-39.png)

#### **Android**

Открываем папку android -&gt; app -&gt; src -&gt; main -&gt; res

Сгенерированные ресурсы внутри папки android переносим

#### **IOS**

Открываем папку ios -&gt; \[project name\] -&gt; Images.xcassets -&gt; LaunchScreen.imageset

Сгенерированные ресурсы внутри папки ios переносим

Название картинок должно быть Launchscreen