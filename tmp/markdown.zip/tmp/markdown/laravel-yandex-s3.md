# Книги > PHP > Laravel cookbook > Laravel + Yandex S3

# Laravel + Yandex S3

1\. Устанавливаем пакет

```bash
composer require league/flysystem-aws-s3-v3
```

2\. Редактируем **.env**

```bash
AWS_ACCESS_KEY_ID=сюда_публичный_ключ
AWS_SECRET_ACCESS_KEY=сюда_приватный ключ
AWS_BUCKET=сюда_название бакета
AWS_ENDPOINT=https://storage.yandexcloud.net
AWS_USE_PATH_STYLE_ENDPOINT=false
AWS_DEFAULT_REGION=ru-central1

...

FILESYSTEM_DISK=s3
FILAMENT_FILESYSTEM_DRIVER=s3
```

3\. Настраиваем **config/filesystems.php**

```php
'disks' => [

    ...

    's3' => [
        'driver' => 's3',
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION'),
        'bucket' => env('AWS_BUCKET'),
        'url' => env('AWS_URL'),
        'endpoint' => env('AWS_ENDPOINT'),
        'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE_ENDPOINT', false),
        'throw' => false,
        'root' => 'public/',
    ],

    ...

],

...

'links' => [
    public_path('storage') => storage_path('app/public'),
],

```

4\. Чтобы завёлся filament, редактируем **config/livewire.php**

```php
...
'temporary_file_upload' => [
    'disk' => 's3',
    ...
]
...  
```

5\. Чтобы вернуть полный путь до изображения используем структуру

`return $this->avatar ? Storage::disk('s3')->url($this->avatar) : null;`

где `image` - поле модели

6\. Чтобы сохранить изображение

```php
$file = $request->file('avatar');
$path = Storage::disk('s3')->putFile(PATH, $file);
```

где `PATH` - это путь до нужной директории от *public/*

7\. Если используется библиотека **imagick** для изменения расширения изображения, то тогда используем такую конструкцию.

```php
$file = $request->file('avatar');
if($file->getMimeType() === 'image/heic') {
    $image = new \Imagick;
    $image->readImage($file);
    $image->setImageFormat('jpg');
    $image->setFormat('jpg');
    //создаём новый путь
    $path = PATH.Str::random(40).'.jpg';
    //записываем файл с новым именем
    try {
        Storage::disk('s3')->put($path, $image->getImageBlob());
    } catch (\Exception $ex) {
        Log::error($ex->getMessage());
    }
}

```

где `PATH` - это путь до нужной директории от *public/*