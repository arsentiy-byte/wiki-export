# Книги > DevOps > Настройки сервера (VPS, KVM, Виртуальные серверы) > Чеклист - обновленный

# Чеклист - обновленный

**В данной странице описаны все действия, необходимые для настройки новых серверов****— Обновить все пакеты Ubuntu или другой ОС, которая на сервере**— **Создать пользователя rocketman с домашней директорией**— **Добавить ssh ключ девопсов, Романа Н.** ключи

- ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCjRjbEUmYa6fDRSR12lGZT7shyh7+xdO475gPOj4dx3wnDmMi6LYypR9r0umdCwPZGUef/G88jVXfO+NG8OLEcO18RKYrCNjbFTSK9bsUlYArbvRkeCt8V/pQaHTUtQcVf9aeSj1CZLCm1TOPfM/Vyz/NpkqIAcRt3PILnZAho/bTzf0VUfa1I3a5Qp2yn0UpXgYqkhsZIXurVK0SmRXxsG+RClJsMiY2b/LQNHzK8LXR5CyZ2g2onF6ZPhwlBKSOe34GEV9CtMHJ0esl8eoDAFpq4OkdqqhzzI8hUZuLfuyHaqTwHNT5lou+yRJiNEL2Kn4cWv+kPYiTs7qBgs+93yg+x0Fet905J9FNysuakkBgVLUzuVnVO5vMMxQRvuj3wkYp7xgLoNN1r1/kXgAyfV6sauUgPOm3VgbCi0n0Udu1Z13Mx5BPCI/UrQY88voOZpWywXgT8sX7yG1aQC7AOrEomTcF4bRnklnBYm2EdlJjpqx+k7dqVyPwW31PypLU= 
- ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDSWdjZJ24F0WQUOAoL49fBu1NttfGUFpYWcURvzrP1+xB8koJ5Iy61f6M0z8B2EE49Ew+YWo8QF7aGoUYLFLNF66swNCHUlzMG+/VCTjgzR/4zY84PqLFYstG9EHmErwpDDwUFbD8+YZnz/idVKcfdKWIcAclM69IvAyLly0HoS4nk90HYCBs9zolIZXGOeTRmC0mG2Hswih0tFTJD4ttdbnf31/RT/tH8PGoLW8F/RTXmxN8TXLSRm45qlNyoY+3IhBOQXNHfS5H/FsZCLV79rMMC1uzxxKBkkMGoyDD0ONAuNQTJbjSydwLYGBxU1tjkMX4cRm/6rUaCbuAJyrC9 romannadein@Romans-MacBook-Pro.local
- ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDkQxOIs0wchFlsNnA5iJWtx6UBCkzyBcR4ieTxYVzJPBkQSdohRSb4G5Sn7UQK1f2spJw/TcmsG6+RtjauJqNWkd7DpHNIfZzupK/tAI1gh356TZhTIDqLX8LrLiP012RMIIxRucy4X4IhVL5kmLk9iFvX6rOCRW69lYuY1b96BUIaJ+IcIG8mtPhV7NBYgY97mXC+BFE34CN+Jkm0FQQ2FJBezt07RDINWGHbpZY/FV+1aEbx38p3jMPkcRJEmcn3LpR7c+aWA/f/9sVfLJwL1YAQ5Qu6BblCaHLSqQ9IPRbpWl6v7iOzedQP1F0R6YU1IVbnHMUwWaQkbVl2w/NR ILYAG

- **Сменить стандартный порт ssh на 9111** **- Открыть в firewall порт 9111** - **Сгенерировать ssh-rsa ключ и залить на сервер .pub часть**- З**акрыть ssh доступ к ВМ по паролю**(логинимся без пароля, только по ssh ключам)- **Увеличить ulimits** (подсказка - /etc/security/limits.conf)(вставлять без табуляции):Лимиты

* soft nofile 100000* hard nofile 100000* soft memlock unlimited* hard memlock unlimited* soft nproc 100000* hard nproc 100000* soft rss unlimited* hard rss unlimited* soft as unlimited* hard as unlimited- **Установить** (в зависимости от проекта):- редактор nano
- сервис htop
- git
- nginx + certbot
- php-fpm + composer
- mysql + phpmyadmin
- postgresql + adminer
- docker
- docker-compose

- **Настроить конфигурацию s3cmd для учетной записи rocketman(~/.s3cfg)(можно взять с тестовых серверов)**- **Настроить slowlog'и - фиксировать меденные запросы от трех секунд**- php-fpm
- mysql
- postgresql

- **Настроить ротацию логов:**- php-fpm
- mysql
- postgresql
- backend

- **Запустить все процессы проекта под другим пользователем** (кроме root):- nginx - default
- mysql - default
- docker - default
- postgresql - default
- php-fpm - rocketman

- **Добавляем учетную запись rocketman в группы docker, sudo, adm**- **Сгенерировать ssh-rsa ключ для учетной записи rocketman и добавить в gitlab .pub часть** ssh-keygen -m pem -t rsa  
- **Увеличить количество запросов к php-fpm** (подсказка - /etc/security/limits.conf)(вставлять без табуляции):pm = ondemand  
pm.max_children = 20Пример php 8.1 Dockerfile + cron + worker (supervisor)

FROM ubuntu:22.04

ARG APP\_ENV

RUN apt update &amp;&amp; \\  
 apt -y install apt-utils &amp;&amp; \\  
 echo 'debconf debconf/frontend select Noninteractive' | debconf-set-selections

RUN apt -y install tzdata &amp;&amp; \\  
 ln -sf /usr/share/zoneinfo/Asia/Almaty /etc/localtime &amp;&amp; \\  
 dpkg-reconfigure -f noninteractive tzdata

ENV TZ="Asia/Almaty"

RUN apt -y install software-properties-common &amp;&amp; \\  
 add-apt-repository ppa:ondrej/php &amp;&amp; \\  
 apt update

RUN apt -y install php8.1-fpm php8.1-curl php8.1-dom php8.1-gd php8.1-mysql php8.1-memcached git php8.1-zip php8.1-mbstring php8.1-intl php8.1-gmp libxrender1 nano supervisor php8.1-pgsql php8.1-redis php8.1-mongodb php8.1-opcache php8.1-bcmath php8.1-imagick imagemagick php8.1-stomp curl ghostscript php8.1-sqlite3 php8.1-http php8.1-raphf\\  
 &amp;&amp; php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');" \\  
 &amp;&amp; php composer-setup.php \\  
 &amp;&amp; mv composer.phar /usr/local/bin/composer \\  
 &amp;&amp; php -r "unlink('composer-setup.php');"

RUN sed -i -e "s/;daemonize\\s\*=\\s\*yes/daemonize = no/g" /etc/php/8.1/fpm/php-fpm.conf \\  
 &amp;&amp; sed -i -e "s/listen\\s\*=\\s\*127.0.0.1:9000/listen = \[::\]:9000/g" /etc/php/8.1/fpm/php-fpm.conf \\  
 &amp;&amp; sed -i -e "s/pid\\s\*=\\s\*\\/run\\/php\\/php8\\.1\\-fpm\\.pid/pid = \\/run\\/php8\\.1\\-fpm\\.pid/g" /etc/php/8.1/fpm/php-fpm.conf \\  
 &amp;&amp; sed -i -e "s/listen\\s\*=\\s\*\\/run\\/php\\/php8\\.1\\-fpm.sock/listen \\= \\\[\\:\\:\\\]\\:9000/g" /etc/php/8.1/fpm/pool.d/www.conf \\  
 &amp;&amp; sed -i -e "s/pm\\s\*=\\s\*dynamic/pm = ondemand/g" /etc/php/8.1/fpm/pool.d/www.conf \\  
 &amp;&amp; sed -i -e "s/pm\\.max\_children\\s\*=\\s\*5/pm\\.max\_children = 32/g" /etc/php/8.1/fpm/pool.d/www.conf \\  
 &amp;&amp; sed -i -e "s/upload\_max\_filesize\\s\*=\\s\*2M/upload\_max\_filesize = 500M/g" /etc/php/8.1/fpm/php.ini \\  
 &amp;&amp; sed -i -e "s/post\_max\_size\\s\*=\\s\*8M/post\_max\_size = 500M/g" /etc/php/8.1/fpm/php.ini \\  
 &amp;&amp; sed -i -e "s/max\_execution\_time\\s\*=\\s\*30/max\_execution\_time = 600/g" /etc/php/8.1/fpm/php.ini \\  
 &amp;&amp; sed -i -e "s/\\;date\\.timezone\\s\*=/date\\.timezone \\= Asia\\/Almaty/g" /etc/php/8.1/fpm/php.ini \\  
 &amp;&amp; sed -i -e "s/opcache\\.revalidate\\\_freq\\=2/opcache.revalidate\_freq=0/g" /etc/php/8.1/fpm/php.ini \\  
 &amp;&amp; sed -i -e "s/\\;max\\\_input\\\_vars\\s\*=\\s\*1000/max\_input\_vars = 10000/g" /etc/php/8.1/fpm/php.ini \\  
 &amp;&amp; sed -i -e "s/short\\\_open\\\_tag\\s\*=\\s\*Off/short\_open\_tag = On/g" /etc/php/8.1/fpm/php.ini \\  
 &amp;&amp; sed -i -e '/pattern\\=\\"PDF\\"/d' /etc/ImageMagick-6/policy.xml \\  
 &amp;&amp; sed -i -e "s/memory\_limit\\s\*=\\s\*128M/memory\_limit = 512M/g" /etc/php/8.1/fpm/php.ini

RUN apt -y install cron

COPY cron /etc/cron.d/cron

RUN chmod 0644 /etc/cron.d/cron \\  
 &amp;&amp; crontab /etc/cron.d/cron \\  
 &amp;&amp; ln -sf /proc/1/fd/1 /var/log/cron.log

RUN set -eux \\  
 &amp;&amp; apt-get autoremove \\  
 &amp;&amp; apt-get autoclean \\  
 &amp;&amp; apt-get clean \\  
 &amp;&amp; rm -rf /var/lib/apt/lists/\* /tmp/\* /var/tmp/\*

WORKDIR /var/www

ARG WORKER\_UID  
RUN echo $WORKER\_UID  
RUN usermod -u $WORKER\_UID www-data

EXPOSE 9000/tcp  
CMD \["/bin/bash", "-c", "/usr/bin/supervisord -c /etc/supervisor/supervisord.conf &amp; php-fpm8.1 &amp; cron -f"\]

pm.start\_servers = 10pm.min\_spare\_servers = 10pm.max\_spare\_servers = 15pm.max\_requests = 2000- **Выставить время на сервере и в настройках php.ini** по текущему часовому поясу +6 gmt- **Настроить nginx для phpmyadmin** на поддомен pma.домен.kz, закрыть basic auth- **Настроить nginx для adminer** на поддомен pma.домен.kz, закрыть basic auth- **Развернуть проект в директорий** /var/www/vhosts/домен- **Настроить конфигурацию nginx для проекта** в /etc/nginx/conf.d/домен.conf- **Сгенерировать сертификаты для доменов проекта и добавить автоматическое обновление сертификатов** (root crontab: 55 00 * * * certbot renew --post-hook "systemctl reload nginx")- **Проверить протокол http** - должен быть 2, а не 1 (nginx: в блоке server: listen 443 ssl http2)   
- **Подлкючить HSTS**(nginx: в блоке server: add_header Strict-Transport-Security "max-age=63072000; includeSubdomains;";)- **Задать X-Frame-Options** (nginx: в блоке server: add_header X-Frame-Options "SAMEORIGIN";)**- Открыть в firewall порты 80 и 443**- **Настроить бекапы БД на Yandex Cloud** (https://wiki.rocketfirm.com/books/bekapirovanie-bd-saitov/page/bekapirovanie-bd-s-pomoshhyu-bash-skripta)**- Настроить автодеплой для проекта**