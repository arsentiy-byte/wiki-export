# Книги > Qalam > Инструкция по ПА

# Инструкция по ПА

[Инструкция ПА Qalam.pdf](https://wiki.rocketfirm.com/attachments/5)