# Книги > Работа с HH > AnyConnect > AnyConnect подключение VPN в MacOS

# AnyConnect подключение VPN в MacOS

  
**Если вы никогда не работали по VPN, создайте заявку в Jira в проекте IT :: Help Desk, чтобы вам дали право его использовать!!!**  
  
Для работы VPN соединения, предварительно должен  
быть настроен второй фактор на телефоне по этой  
инструкции Подключение Microsoft Authenticator для  
двухфакторной аутентификации  
Соединение не будет устанавливаться, пока не нажмете  
на выскочившую на телефоне кнопку “Утвердить”.  
Процедура установки VPN соединения  
0\. Если настройка подключения происходит на личной технике, предварительно необходимо установить ПО  
AnyConnect по . инструкции  
1\. Откройте окно подключения AnyConnect. Для этого нажмите на иконку приложения в трее.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-06/scaled-1680-/koHimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-06/koHimage.png)

  
2\. Если иконки в трее нет, необходимо запустить программу из Launchpad.

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-06/scaled-1680-/g8Cimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-06/g8Cimage.png)

  
3\. В запущенной программе поверить, что в поле написано "HH VPN" и нажать кнопку "Connect". В случае если поле пустое, необходимо написать в нем connect.hhdev.ru:444 и так же нажать кнопку "Connect".

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-06/scaled-1680-/3Igimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-06/3Igimage.png)

  
4\. В открывшемся окне заполнить поля "Username" и "Password". Нажать кнопку "OK".

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-06/scaled-1680-/FbTimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-06/FbTimage.png)

  
Процедура подключения занимает некоторое непродолжительное время, по прошествии которого можно полноценно  
пользоваться внутренними ресурсами компании.  
Обратите внимание, что подключиться к VPN, находясь в офисе (будучи подключенными к корпоративному Wi-Fi  
или сети сетевых розеток) невозможно.