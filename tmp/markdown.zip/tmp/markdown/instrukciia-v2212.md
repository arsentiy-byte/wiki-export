# Книги > DevOps > Обновление приложения сайта wiki.rocketfirm.com > Инструкция v22.12

# Инструкция v22.12

1. Бэкап файлов через терминал сервера: 
    - открываем сервер : **ssh intra**
    - переходим в директорию: **cd /var/www/**
    - выполняем копирование файлов сайта: **cp -r wiki.rocketfirm.com wiki.rocketfirm.com\_YYYY-MM-DD** (вместо YYYY-MM-DD указать текущую дату )
2. С github скачиваем на локальный компьютер в Downloads последнее доступное обновление в tar.gz или zip [https://github.com/BookStackApp/BookStack/releases](https://github.com/BookStackApp/BookStack/releases)
    - копируем zip папку на сервер intra:
    - **scp -r ~/Downloads/zip\_folder SERVER\_ADDRESS:/tmp/**
    - затем разархивируем его: **unzip zip\_folder**
3. Открываем сервер : **ssh intra**
4. Переходим в директорию /var/www/: **cd /var/www/**
5. Копируем обновления в папку сайта : ***cp -r /tmp/BookStack-version/\* wiki.rocketfirm.com/** (BookStack-version/ - папка, которая была в скачанном архиве)*
6. Переходим в обновленную директорию wiki.rocketfirm.com: **cd wiki.rocketfirm.com**
7. Выполняем обновление зависимостей с помощью composer: ***composer install --ignore-platform-reqs***
8. Выполняем миграции в базу данных : ***php artisan migrate --force***
9. Чистим кэш : ***php artisan optimize:clear***