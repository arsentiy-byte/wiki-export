# Книги > RTE в Mi > Обновление содержимого письма

# Обновление содержимого письма

1. переходим в письмо и на вкладку содержимое  
    ![](https://wiki.rocketfirm.com/images/image3.png)[![image-1649244652922.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244652922.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244652922.png)
2. в новом окне жмем на текст - Загрузить новую версию  
    ![](https://wiki.rocketfirm.com/images/image29.png)[![image-1649244722534.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244722534.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244722534.png)
3. выбираем новый архив и загружаем содержимое  
    ![](https://wiki.rocketfirm.com/images/image22.png)[![image-1649244737869.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244737869.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244737869.png)
4. ждем загрузку и жмем импорт  
    ![](https://wiki.rocketfirm.com/images/image25.png)[![image-1649244749584.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244749584.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244749584.png)
5. После обновления содержимого в нижней части экрана появится сообщение о проекте, мы переходим в него  
    ![](https://wiki.rocketfirm.com/images/image31.png)[![image-1649244760583.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244760583.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244760583.png)
6. видим что у нас появилась новая версия мы подтверждаем изменения и письмо обновляется  
    [![image-1649244774633.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244774633.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244774633.png)