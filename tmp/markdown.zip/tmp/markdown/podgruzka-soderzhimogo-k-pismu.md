# Книги > RTE в Mi > Подгрузка содержимого к письму

# Подгрузка содержимого к письму

1. Переходим в вкладку содержание  
    ![](https://wiki.rocketfirm.com/images/image1.png)[![image-1649244461639.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244461639.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244461639.png)
2. Жмем редактировать  
    ![](https://wiki.rocketfirm.com/images/image7.png)[![image-1649244478309.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244478309.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244478309.png)
3. Жмем добавить  
    ![](https://wiki.rocketfirm.com/images/image9.png)[![image-1649244491250.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244491250.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244491250.png)
4. в новом окне указываем название нашего архива с содержимом, жмем поиск, в списке выбираем наше содержимое и жмем ОК  
    ![](https://wiki.rocketfirm.com/images/image15.png)[![image-1649244509456.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244509456.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244509456.png)
5. после подгрузки жмем  
    ![](https://wiki.rocketfirm.com/images/image6.png)[![image-1649244520143.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244520143.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244520143.png)
6. и подтверждаем наши действия  
    [![image-1649244531575.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/scaled-1680-/image-1649244531575.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-04/image-1649244531575.png)