# Книги > DevOps > Добавление проекта в SonarQube

# Добавление проекта в SonarQube

#### **Перед началом настройки:**

Склонируйте репозиторий с файлами для интеграции:

[https://gitlab.com/rocketfirm/sonar-rocketfirm-com/sonar-pipeline](https://gitlab.com/rocketfirm/sonar-rocketfirm-com/sonar-pipeline)

#### **Создание проекта в SonarQube**\***:**

\*требуются права администратора в SonarQube

Заходим на главную страницу [https://sonar.rocketfirm.com](https://sonar.rocketfirm.com) , выбираем "Создать проект" &gt; "Из Gitlab"

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/r3gimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/r3gimage.png)

Отобразится список проектов в Gitlab. В поиске находим нужный, нажимаем на "Импорт"

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/7Wmimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/7Wmimage.png)

Вас попросят выбрать тип настройки проекта. Выбираем "Использовать глобальную настройку"

Далее попросят выбрать метод анализа. Выбираем "Gitlab CI"

Далее развернётся простыня с инструкцией о подготовке проекта. На вопрос "С помощью чего собирается ваш проект?" отвечаем Other. Нам нужен этот раздел:

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/scaled-1680-/SR6image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-02/SR6image.png)

Скопируйте **полностью** значение **sonar.projectKey** в файлы **sonar-merge.properties** и **sonar-project.properties** склонированного в подготовительном шаге репозитория.

Создайте в вашем проекте ветку, в которую добавите интеграцию, и из которой будете мерджить в основные ветки, такие как **develop** и **master**

Скопируйте содержимое репозитория, а именно файлы:

- .gitlab-ci.yml
- .gitlab-ci-full.yml
- .gitlab-ci-merge.yml
- sonar-merge.properties (помним про то, что в нём уже должно быть актуальное значение **sonar.projectKey**)
- sonar-project.properties (помним про то, что в нём уже должно быть актуальное значение **sonar.projectKey**)

в корневую директорию свежесозданной ветки вашего проекта.

**Последний шаг** - подключение к проекту агента **gitlab-runner**, на котором вся эта красота будет выполняться. В гитлабе переходим в **Settings &gt; CI/CD &gt; Runners**

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-04/scaled-1680-/image.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-04/image.png)

Находим раннера с тэгами **global-jenkins** и **sonar-runner**, нажимаем "Enable for this project".

[![image.png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-04/scaled-1680-/Vsgimage.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-04/Vsgimage.png)

Сохраните изменения, запушьте их в гит. Сделайте МР в основные ветки проекта (**develop** и **master**). На этом настройка завершена.