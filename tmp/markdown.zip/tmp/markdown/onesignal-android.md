# Книги > Archived > OneSignal push уведомления > OneSignal Android

# OneSignal Android

##### **1. Регистрация в OneSignal**

**\*** Процесс[ регистрации](https://onesignal.com/) достаточно простой и незамысловатый, как и в любом другом сервисе вводим свои данные и регистрируем аккаунт. Тут, наверное, заранее нужно определить с заказчиком, будет ли он в дальнейшем сам вести учет или нет. Если да то регистрируем новый аккаунт для проекта если нет, то делаем проект в рамках аккаунта в компании. В любом случае в дальнейшем всегда можно создать новый и поменять настройки API под новый аккаунт.

**\*\*\*** Небольшая ремарка касательно тех, у кого macbook на M1 возможно на момент прочтения этого материала проблема будет поправлена, но на данный момент после установки пакета:

- - Yarn: 

```
yarn add react-native-onesignal
```

- - Npm

```
npm install –save react-native-onesignal
```

Нужно будет перейти в директорию ios

`cd ios`

и выполнить

`pod install` 

Если при установке pod install возникли проблемы или ошибки, вам нужно открыть терминал через Rosetta2, а не нативно и выполнить команду заново.

##### **2. Создание проекта в OneSignal и подключение к Firebase**

**\*** После создания аккаунта нам будет предложено сразу создать проект в OneSignal. Выбираем интересующую нас платформу, я выбрал андроид, вписываем название вашего приложения и жмем кнопку Next.

[![image-1633270050556.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270050556.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270050556.png)

**\*** Следующим пунктом нам нужно предоставить OneSignal наши данные от Firebase это Server Key и Sender ID.

[![image-1633270096671.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270096671.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270096671.png)

##### **Создаем проект в Firebase**

**\*** Для этого следующим шагом (если вы еще не генерировали проект в Firebase) нам нужно пройти в[ Firebase Console](https://console.firebase.google.com/) и создать проект под наши нужды, который даст нам необходимые для onesignal ключи.

[![image-1633270113387.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270113387.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270113387.png)

**\*** Вводим название вашего проекта

[![image-1633270176396.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270176396.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270176396.png)

**\*** Если не нужна google аналитика, то отключаем её

[![image-1633270207751.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270207751.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270207751.png)

**\*** Создание проекта займет какое-то время, после чего должен появиться экран с сообщением что наш проект создан, отлично жмем далее.

[![image-1633270275146.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270275146.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270275146.png)

**\*** После этого произойдет ридерект обратно в консоль с вашим проектом, слева вверху нужно будет нажать на шестерёнку и открыть настройки проекта.

[![image-1633270398639.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270398639.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270398639.png)

**\*** Здесь нас интересует вкладка Cloud Messaging

[![image-1633270458681.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270458681.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270458681.png)

**\*** Тут мы можем увидеть необходимые нам ключи, которые нужно скопировать и вставить в нах проект в OneSignal для корректной связи с firebase.

[![image-1633270492011.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270492011.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270492011.png)

##### **Продалжаем с OneSignal**

**\* Вставляем все в onesignal и жмем кнопку сохранить и продолжить.**

[![image-1633270554189.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270554189.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270554189.png)

**\*** На следующем экране выбераем тот язык или фреймворк на котором вы разрабатываете, я выбираю ReactNative и нажимаем кнопку далее.

[![image-1633270595007.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270595007.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270595007.png)

**\*** Последним пунктом в onesignal нам нужно произвести настройку вашего приложения исходя из выбранной нами версии android или ios. Так как в данном материале я выбирал андроид давайте пройдем установку и инициализацию андроид вместе. Кому интересно разобраться самому вот ссылка на [документацию](https://documentation.onesignal.com/docs/react-native-sdk-setup), так же эта ссылка есть на экране последнего шага, с которой нам еще понадобится взять App Id когда будем инициализировать onesignal в приложении.

[![image-1633270665247.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633270665247.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633270665247.png)

#####  

##### **3. Инициализация onesignal в коде вашего проекта.**

**\*** В первую очередь потребуется установить пакет onesignal в качестве зависимости в наше приложение одной из команд

- - Yarn

```
yarn add react-native-onesignal
```

- - Npm

```JavaScript
npm install –save react-native-onesignal
```

**\*** Далее нужно добавить код в файл по пути **app/build.gradle** в самый верх файла, первой строкой:

```JavaScript
buildscript {
	repositories {
    	gradlePluginPortal()
	}
	dependencies {
    	classpath 'gradle.plugin.com.onesignal:onesignal-gradle-plugin:[0.12.10, 0.99.99]'
	}
}
 
apply plugin: 'com.onesignal.androidsdk.onesignal-gradle-plugin'
```

[![image-1633271257121.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633271257121.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633271257121.png)

**\*** Следующим шагом в корневом файле нашего проекта в моем случае это app.js при помощи useEffect прописываем конфигурацию по инициализации onesignal. Для данного примера и инициализации нам понадобится лишь небольшая часть кода, более развернутый функционал и скопировать сам код[ можно здесь](https://documentation.onesignal.com/docs/react-native-sdk-setup#step-5-initialize-the-onesignal-sdk).

Так же здесь нам потребуется прописать наш App Id который мы получили из onesignal на последнем шаге и нужно прописать его в конфиг.

```JavaScript
import React, {useEffect} from "react"
import {View, Text} from 'react-native'
import OneSignal from "react-native-onesignal";

const App = () => {
  useEffect(() => {
    OneSignal.setLogLevel(6, 0);
    OneSignal.setAppId('05651bdd-06bc-4fb8-a8c3-1a62e4636130'); // APP ID
  }, [])
  return (
    
      Testing page
    
  )
};

export default App;

```

##### **4. Запуск проекта и тест push уведомлений через OneSignal.**

**\*** После того как прописали инициализацию для onesignal нужно запустить приложение на андроид, в данном случае. Вернуться назад в браузере к последнему шагу в oneSignal и нажать Show Subscribed Users и если все прошло правильно там появится наш пользователь, нажимаем далее. После чего вам будет представлена панель по работе с вашим новым приложением в onesignal. Отсюда можно вести статистику, рассылку и управлять подписками. Если все сделано правильно, то после запуска вашего проекта произойдёт подключение к сервису onesignal и на вкладке audience в браузере вы сможете увидеть активного подписчика на прослушивание уведомлений, то есть вас.

[![image-1633271686645.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633271686645.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633271686645.png)

**\*** На вкладке All users можно посмотреть более детальную информацию по каждому пользователю, в данный момент у нас только один. В том числе и посмотреть. Player id который нам нужно будет передавать на backend для того чтобы таргетировать конкретного пользователя или пользователей.

[![image-1633271850422.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633271850422.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633271850422.png)

##### **5. Создаем push уведомление и тестируем**

**\*** Давайте попробуем создать новое push уведомление через onesignal и посмотреть придет ли оно нам. Делается это просто для этого заходим на вкладку Messages и нажимаем на New Push.

[![image-1633271881529.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633271881529.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633271881529.png)

**\*** На экране создания уведомлений есть целая система настроек мы же в данном случае не будем вникать во все детали создания кастомных уведомлений, а просто сделаем самое простое заполнив 2 поля Title и message. Так же справа есть превью того как будет выглядеть ваше сообщение при его получении. Нажимаем Review and Send.

[![image-1633272031371.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633272031371.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633272031371.png)

**\*** Далее нам покажут экран краткого описания нашего уведомления можно почитать и нажимаем send.

[![image-1633272075056.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633272075056.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633272075056.png)

**\*** После этого нам покажут экран статистики а в приложение придет уведомление.

[![image-1633272107363.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633272107363.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633272107363.png)

[![image-1633272122006.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/scaled-1680-/image-1633272122006.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-10/image-1633272122006.png)

Поздравляю!!! Вы только что настроили и подключили уведомления для вашего приложения. Но это не означает конец! Далее еще много работы по кастомизации уведомлений, автоматической их рассылки нужным пользователям и выполнение нужных действий на экране при их открытии например. Это тема уже для отдельной статьи. Здесь же мы разобрали базовый функционал и подключение.