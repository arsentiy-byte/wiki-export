# Книги > PHP > Laravel cookbook > Laravel Websockets

# Laravel Websockets

Для реализации мгновенных сообщений используется пакет [Laravel WebSockets](https://github.com/beyondcode/laravel-websockets)

Пакет позволяет поднять на стороне сервера Self-Hosted Pusher Server и работать в нем через экосистему Laravel

Для локальной работы, через Docker, необходимо пробросить только порт 6001 или другой, который вы выберите.

**Важно! При изменении порта необходимо корректировать конфигурационный файл Supervisor (Рисунок 1).**

\[program:websockets\]  
process\_name=%(program\_name)s\_%(process\_num)02d  
command=php /var/www/artisan websockets:serve --port=&lt;Необходимый порт&gt;  
numprocs=1  
autostart=true  
autorestart=true  
user=www-data  
redirect\_stderr=true  
stdout\_logfile=/var/www/storage/logs/websockets.log  
stopwaitsecs=3600Рисунок 1. Конфигурация supervisor (внутри Docker)

При деплое на тестовый или продакшен серверы возникает проблема с тем, что WebSockets доступны только по протоколу WS, что исключает возможность взаимодействия с ним через браузер пользователя. Для работы пакета в режиме WSS необходимо следующее:

- Скопировать или сделать symlink ssl-ключей для домена, на котором будет работать данный пакет
- В .env-файл добавить пути к ключам (Рисунок 2)
- Добавить конфигурацию для проксирования в конфигурацию nginx (не в Docker, снаружи) (Рисунок 3)
- В .env-файд добавить внутреннее имя контейнера, код которым запущен supervisor (Рисунок 2)

\#LARAVEL_WEBSOCKETS_SSL_LOCAL_CERT=  
\#LARAVEL_WEBSOCKETS_SSL_LOCAL_PK=  
LARAVEL_WEBSOCKETS_PORT=443  
LARAVEL_WEBSOCKETS_HOST=адрес сайта  
Рисунок 2. Конфигурация .env-файла

location /app {  
 proxy\_pass http://127.0.0.1:6001;  
 proxy\_read\_timeout 60;  
 proxy\_connect\_timeout 60;  
 proxy\_redirect off;  
  
 \# Allow the use of websockets  
 proxy\_http\_version 1.1;  
 proxy\_set\_header Upgrade $http\_upgrade;  
 proxy\_set\_header Connection 'upgrade';  
 proxy\_set\_header Host $host;  
 proxy\_cache\_bypass $http\_upgrade;  
}Рисунок 3. Конфигурация nginx

Радуемся и наслаждаемся работой WebSockets. Более подробная информация [Тык](https://beyondco.de/docs/laravel-websockets/basic-usage/ssl#usage-with-a-reverse-proxy-like-nginx)