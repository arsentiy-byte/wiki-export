# Книги > PHP > ElasticSearch. Основы > Оптимизация поиска

# Оптимизация поиска

#### Boosting

В запросах можно прибавлять вес конкретным полям, для улучшения запросов. Например, есть 2 документа

```JSON
{
  "_index": "products",
  "_type": "_doc",
  "_id": "1",
  "_source": {
  	"title": "Красное яблоко", 
  	"description": "Большое красное яблоко" 
  }
},
{
  "_index": "products",
  "_type": "_doc",
  "_id": "2",
  "_source": {
  	"title": "Большое зеленое яблоко", 
  	"description": "Большое зеленое яблоко", 
  }
},

```

Нам необходимо найти товар, в котором есть слово «*Большое*». Если в результат добавить boot на title, то документ с id = 2 будет иметь больший вес, так как искомое слово есть в названии. В случае же если не указывать никакой boot, то документ с id = 1 будет иметь больший вес, так как искомое слово есть и в названии и в описании.  
Boost можно указывать при маппинге

```JSON
PUT my-index-000001
{
  "mappings": {
    "properties": {
      "title": {
        "type": "text",
        "boost": 2 
      },
      "content": {
        "type": "text"
      }
    }
  }
}
```

При поиске

```JSON
POST _search
{
  "query": {
    "match": {
      "title": {
        "query": "quick brown fox",
        "boost": 2
      }
    }
  }
}
```

При поиске по нескольким полям

```JSON
GET /_search
{
  "query": {
    "multi_match" : {
      "query":    "this is a test", 
      "fields": [ "subject^3", "message"],
      "type": "phrase_prefix" 
    }
  }
}
```

Так же можно присваивать boost не конкретному полю, а целому запросу при использовании bool

```JSON
POST _search
{
  "query": {
    "bool" : {
      "should" : [
        {
          "match" : } 
	      "content" : {
                "query" : "simple rest apis distributed nature"
             } 
	   }
        },
        {
          "match" : { 
	      "content" : {
                "query" : "simple rest apis distributed nature",
		  "operator" : "and",
             } 
	    }
        },
        {
         "match_phrase" : { 
	      "content" : {
                "query" : "simple rest apis distributed nature",
		  "boost" : 2
             } 
	   }
        }
      ]
    }
  }
}
```

 NOTE: желательно указывать boost в поиском запросе, так как при указании в маппинге он будет применяться на каждом запросе

#### Tokenizer

Токенизация используется на этапе индексации, она преобразовывает хранимые данные в Elasticsearch несколько вариантов. Есть несколько видов токенизации описанных в [документации](https://www.elastic.co/guide/en/elasticsearch/reference/current/analysis-tokenizers.html)  
Например, токенайзер whitespace преобразует название «Большое зеленое яблоко» в «Большое», «зеленое», «яблоко». А токенайзер Ngram бьет слова на части в зависимости от настроек

```JSON
PUT my-index-000001
{
  "settings": {
    "analysis": {
      "analyzer": {
        "my_analyzer": {
          "tokenizer": "my_tokenizer"
        }
      },
      "tokenizer": {
        "my_tokenizer": {
          "type": "ngram",
          "min_gram": 3,
          "max_gram": 3,
          "token_chars": [
            "letter",
            "digit"
          ]
        }
      }
    }
  }
}
```

В соответствиями с настройками выше название "Quick Fox", будет преобразовано в \[ Qui, uic, ick, Fox, oxe, xes \]

NOTE: токенизаторы относят к анализаторам текста, поэтому после изменения настроек необходимо производить индексацию