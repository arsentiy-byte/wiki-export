# Книги > QA > Postman > API

# API

Многие уже использовали **Postman**. Но как практика показывает, **большое количество разработчиков** не уделяют изучению полезного инструментария который предоставляет нам **Postman**. Статья покажет базовые инструменты для **работы с API**.

## Оглавление

- Заголовок API (название)
- Описание API
- Method и endpoint (методы и ссылки)
- Params (параметры)
- Authorization (авторизация)
- Headers (заголовки)
- Body (тело запроса)
- Pre-request Script (выполнение скрипта перед запросом)
- Examples (примеры поведения API)
- Comments (комментарии API)
- Cookies
- Code (вызов API в ЯП)

## Заголовок API (название)

Заголовки - это **информация об API** в двух слова.

[ ![](https://lh4.googleusercontent.com/IHCrRKqB7aNljnJKIBh1PNx757klgdGfbxKvpXNCeUCS77hHG2wOswjNbfkFxxjGEmknBSabwwJd-wQdeZ7ySNyxD9LAM6w8ef9VD26EsR95zPs3LcYubce07-_xFbZiTdC6Bf2E)](https://lh4.googleusercontent.com/IHCrRKqB7aNljnJKIBh1PNx757klgdGfbxKvpXNCeUCS77hHG2wOswjNbfkFxxjGEmknBSabwwJd-wQdeZ7ySNyxD9LAM6w8ef9VD26EsR95zPs3LcYubce07-_xFbZiTdC6Bf2E)

## Описание API

Описание помогает хранить подробную информацию об API. Все **описания** имеют поддержку [**markdown**](https://ru.wikipedia.org/wiki/Markdown).

[ ![](https://lh3.googleusercontent.com/lMYObz-yAsUxmyWGXxkG8p3VbBhrK_iCF53-yZYUWH5Im_SRTChWA5IN7IXO0NuZYVIEolgl3CNPMZxzlXK6mN0if6Rb5Ho5jnUt-aMl2HTTPgtDs4tlN87H82FxuPwHwxX0QQsi)](https://lh3.googleusercontent.com/lMYObz-yAsUxmyWGXxkG8p3VbBhrK_iCF53-yZYUWH5Im_SRTChWA5IN7IXO0NuZYVIEolgl3CNPMZxzlXK6mN0if6Rb5Ho5jnUt-aMl2HTTPgtDs4tlN87H82FxuPwHwxX0QQsi)

## Method и endpoint (методы и ссылки)

[**Методы**](https://developer.mozilla.org/ru/docs/Web/HTTP/Methods) **в Postman** есть и **популярные**, и **кастомные**.

[ ![](https://lh6.googleusercontent.com/bZ7GBIidoE43IyGPhRHr3A6W6KuYOz58fcKUu_yJiF9lQd9EnYjLvbobGKG7dets7ICUrculc8BKhbks6FL44bMDlNmkHQnc0uD90-0US4KI7kNWNQuKAA6EmOse-d1wh3BDkmvW)](https://lh6.googleusercontent.com/bZ7GBIidoE43IyGPhRHr3A6W6KuYOz58fcKUu_yJiF9lQd9EnYjLvbobGKG7dets7ICUrculc8BKhbks6FL44bMDlNmkHQnc0uD90-0US4KI7kNWNQuKAA6EmOse-d1wh3BDkmvW)

## Params (параметры)

Круто когда ты можешь прочитать **info/include?models=city&amp;data\_type=map**. Но какой смысл, если тут всё равно **ничего не понятно**?

- Как **временно убрать** параметр?
- Что означают эти параметры?
- Как **работать с 15-ю** такими же **параметрами** на одном endpoint?

[ ![](https://lh5.googleusercontent.com/HxymbyKWcUKqO-VVhyCXX9h8OEQo5DTjcLg_zexpxt3L28wT9Jy-by9h1ciRkS0jrrC9qISn16YCzWMVWq3d8DiSdNwViMItEKY-6TrojJWCvMdhHdht0RdXQ3EDdqn1O5Orc-FP)](https://lh5.googleusercontent.com/HxymbyKWcUKqO-VVhyCXX9h8OEQo5DTjcLg_zexpxt3L28wT9Jy-by9h1ciRkS0jrrC9qISn16YCzWMVWq3d8DiSdNwViMItEKY-6TrojJWCvMdhHdht0RdXQ3EDdqn1O5Orc-FP)

## Authorization (авторизация)

Какой проект имеет **API без авторизации**? Однажды было круто узнать про [**Headers**](https://developer.mozilla.org/ru/docs/Web/HTTP/%D0%97%D0%B0%D0%B3%D0%BE%D0%BB%D0%BE%D0%B2%D0%BA%D0%B8), но в них очень сложно проследить “Эта **API** **использует авторизацию**?”.

[ ![](https://lh6.googleusercontent.com/3tWqqo6EQkqKrlMqEm_7tGplSfTXcX0qPk9BVdW6oQAGrajrK4aaTd-gJoNzDe-8Up1HCZAo9VsQLkYMCRnTjk5pcVS1T0_WktVYWOMGZ1oL6uYCB8th4vLpnM08J7bAdfXbYzix)](https://lh6.googleusercontent.com/3tWqqo6EQkqKrlMqEm_7tGplSfTXcX0qPk9BVdW6oQAGrajrK4aaTd-gJoNzDe-8Up1HCZAo9VsQLkYMCRnTjk5pcVS1T0_WktVYWOMGZ1oL6uYCB8th4vLpnM08J7bAdfXbYzix)

## Headers (заголовки)

Авторизация вроде **автоматически** подставляется. Давайте изменим язык через Headers?

[ ![](https://lh4.googleusercontent.com/Cq3VLFgCg4hK6DMTF56DRQnXg8zRc6s5IB0M8SEBTQuEMFlJzsnbtc192wCVKHy7049Dy4L_Ma09_kaTo7kkt4n1K3vAPj9A_ePNatL9qcAG5dtjgffwe-dzZ1voAr9SoFwx569k)](https://lh4.googleusercontent.com/Cq3VLFgCg4hK6DMTF56DRQnXg8zRc6s5IB0M8SEBTQuEMFlJzsnbtc192wCVKHy7049Dy4L_Ma09_kaTo7kkt4n1K3vAPj9A_ePNatL9qcAG5dtjgffwe-dzZ1voAr9SoFwx569k)

## Body (тело запроса)

Когда вы используете **мутабельные методы в endpoint**, что вам предпочтительнее использовать в теле запроса? **application/form-data**? **application/json**? [**GraphQL**](https://en.wikipedia.org/wiki/GraphQL)? **Бинарники**?!

[ ![](https://lh5.googleusercontent.com/TKimyRTt4hAVCYnzHpo3-7OeucOFlht3a3_VxznkLtcild6UsspXavmu77dnlr_RHMQ_DBIk2yitqSamTcps5F2DGX0upZKGrEae0eFO0uMP0CtGzns2Z5V6GYULEV-2C7pgrd5N)](https://lh5.googleusercontent.com/TKimyRTt4hAVCYnzHpo3-7OeucOFlht3a3_VxznkLtcild6UsspXavmu77dnlr_RHMQ_DBIk2yitqSamTcps5F2DGX0upZKGrEae0eFO0uMP0CtGzns2Z5V6GYULEV-2C7pgrd5N)

## Pre-request Script (выполнение скрипта перед запросом)

Очень удобно делать **всё динамическое**. Вот **выполнение скрипта**, который в свою очередь **меняет значение переменной**.

[ ![](https://lh4.googleusercontent.com/Xyd-CVZPuXMIDUpxqU-dVYKPYW89dF0qfsPXBLOYbzWzmwuP67VGHwU4xClOG6vlgHbEawJHSyMWO1_nEyJqadq77FZN3hfHB8TJ1DZBlnufBASvDBB6iJZRi17yJyJBMXFZ1lbL)](https://lh4.googleusercontent.com/Xyd-CVZPuXMIDUpxqU-dVYKPYW89dF0qfsPXBLOYbzWzmwuP67VGHwU4xClOG6vlgHbEawJHSyMWO1_nEyJqadq77FZN3hfHB8TJ1DZBlnufBASvDBB6iJZRi17yJyJBMXFZ1lbL)

## Examples (примеры поведения API)

**Фронтендеры**, у вас были проблемы с **получением ответа** запроса по **API**? Делаете запрос, а получаете [**500-ю** **ошибку**](https://ru.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA_%D0%BA%D0%BE%D0%B4%D0%BE%D0%B2_%D1%81%D0%BE%D1%81%D1%82%D0%BE%D1%8F%D0%BD%D0%B8%D1%8F_HTTP). Позже **решается проблема**, вы получаете и **подключаете** тот самый **ответ**. И тут сообщение “**Ответ меняется** в зависимости от **типа пользователя**”. И на фоне всего этого тестировщик задается вопросом, что он чего-то в этой жизни не понимает.

Решается это все examples (примерами). **Примеры в Postman** позволяют убить несколько зайцев:

- **Не нужно делать запрос** для получения [JSON](https://ru.wikipedia.org/wiki/JSON)
- JSON может быть **задокументирован**
- **Всегда правильный JSON** для ответов по коду (200, 201, 422, 409...)

[ ![](https://lh6.googleusercontent.com/qcaqKfG_s9GJzxg8HsommBsozpAyJQ7AqOpVYGW41j5WZmzylq97cC-_4p2wdG1Xt1yqMlTPCMNSnPrKdHPKGCPFpwgmuSKhGAhgQDFV9WltqgZj2EKX4Wcc2wcOppor3eWmAgz5)](https://lh6.googleusercontent.com/qcaqKfG_s9GJzxg8HsommBsozpAyJQ7AqOpVYGW41j5WZmzylq97cC-_4p2wdG1Xt1yqMlTPCMNSnPrKdHPKGCPFpwgmuSKhGAhgQDFV9WltqgZj2EKX4Wcc2wcOppor3eWmAgz5)

## Comments (комментарии API)

А как часто вы **обсуждаете** свои любимые **API с тестировщиком**?)

[ ![](https://lh3.googleusercontent.com/bLGprlB7G8KqzmqDUw6_chZRSnGph_fxHF1Em4skwe_xV7idACUzeVBKobWbpl6ZowQ3h1dJQE10H4n9U06tHRYk6JBYgITIOScO3XJWMrNx-RUwDZTdroDPN3HuhzC4OJpreeZV)](https://lh3.googleusercontent.com/bLGprlB7G8KqzmqDUw6_chZRSnGph_fxHF1Em4skwe_xV7idACUzeVBKobWbpl6ZowQ3h1dJQE10H4n9U06tHRYk6JBYgITIOScO3XJWMrNx-RUwDZTdroDPN3HuhzC4OJpreeZV)

## Cookies

Если я напишу, что “куки, они и в **Postman** [**куки**](https://ru.wikipedia.org/wiki/Cookie)”4. Вы удивитесь?

[ ![](https://lh3.googleusercontent.com/w1x8EMDXFRkpDLeUulMHYLvAWxr7QibndjJQ1qYfNmuxhsASpg8OLyAr2GQPVorot2GGP8OPvGxRJc77NYYWJZ71hotJn7Fjjqt6SU1EOxLmeVNzcyz-as1Q1kUiH6JYif93DiNv)](https://lh3.googleusercontent.com/w1x8EMDXFRkpDLeUulMHYLvAWxr7QibndjJQ1qYfNmuxhsASpg8OLyAr2GQPVorot2GGP8OPvGxRJc77NYYWJZ71hotJn7Fjjqt6SU1EOxLmeVNzcyz-as1Q1kUiH6JYif93DiNv)

## Code (вызов API в ЯП)

А что если Postman за вас **сгенерирует код** для [ЯП](https://ru.wikipedia.org/wiki/%D0%AF%D0%B7%D1%8B%D0%BA_%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D1%8F)?

[ ![](https://lh6.googleusercontent.com/tNnS_DmKbQYCq7idErOys46V2lQTtL43nLD9tZNi5zf5BnqPs_EEVvnE-aDBLpml9Gqf9TPD_K4sfDRArDZR2YDSgwjlQHpn8sfBSimAJxWz8pxwfWYnGYx07xSkcJ6GokIOxFvk)](https://lh6.googleusercontent.com/tNnS_DmKbQYCq7idErOys46V2lQTtL43nLD9tZNi5zf5BnqPs_EEVvnE-aDBLpml9Gqf9TPD_K4sfDRArDZR2YDSgwjlQHpn8sfBSimAJxWz8pxwfWYnGYx07xSkcJ6GokIOxFvk)

## Заключение

С этими знаниями можно приступать писать и описывать свои API. Но стоит помнить, что эта статья была только про API, а не про весь Postman с его замечательными тестами, рабочими областями и документированием. :)