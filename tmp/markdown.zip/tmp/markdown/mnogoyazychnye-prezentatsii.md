# Книги > Многоязычные презентации > Многоязычные презентации

# Многоязычные презентации

Все чаще и чаще мы получаем CLM проекты с разным языковым наполнением. Хотел бы обратить внимание на то, что в шаблоне есть такая возможность, как верстка многоязычных презентаций. Далее — как это реализовать.

[Ссылка на template](https://gitlab.com/rocketfirm/presentations/presentation-template.git)

---

## Первый шаг

Указать какие языки в **header.html:**

```

```

---

## Сценарий и названия слайдов

Называем flow и slides файлы в соответствии с языком:

flow.**kz**.js

```
'use strict';cegedim.flow.initSequence(false, [    'SACAWDRT16070257_0_0_KZ_MAIN_SLIDE',    'SACAWDRT16070257_0_1_KZ_MAIN_SLIDE'  ],  false); 
```

flow.**ru**.js

```
'use strict';

cegedim.flow.initSequence(false, [
    'SACAWDRT16070257_0_0_MAIN_SLIDE',
    'SACAWDRT16070257_0_1_MAIN_SLIDE'
  ],
  false
);
```

slides.**kz**.json

{ "slide-00": \["SACAWDRT16070257\_0\_0\_KZ\_MAIN\_SLIDE"\], "slide-01": \["SACAWDRT16070257\_0\_1\_KZ\_MAIN\_SLIDE"\] } ```
{
    "slide-00": ["SACAWDRT16070257_0_0_KZ_MAIN_SLIDE"],
    "slide-01": ["SACAWDRT16070257_0_1_KZ_MAIN_SLIDE"]
}
```

slides.**ru**.json

```
{
    "slide-00": ["SACAWDRT16070257_0_0_MAIN_SLIDE"],
    "slide-01": ["SACAWDRT16070257_0_1_MAIN_SLIDE"]
}
```

{ "slide-00": \["SACAWDRT16070257\_0\_0\_MAIN\_SLIDE"\], "slide-01": \["SACAWDRT16070257\_0\_1\_MAIN\_SLIDE"\] } Тут следует обратить внимание что цинк код для двух презентации может быть как один так и разный, так же как и сценарий может отличаться или быть одинаковым для обеих версий

---

## Отличия в верстке

Для каждого текстового элемента мы указываем класс с языком

**slide-00.html**

@@include('header.html', {"slide-id": "slide-00"}) &lt;span class="title ru"&gt;Русский&lt;/span&gt; &lt;span class="title kz"&gt;Казахский&lt;/span&gt; @@include('footer.html', {"slide-id": "slide-00"}) ```
@@include('header.html', {"slide-id": "slide-00"})	Русский	Казахский@@include('footer.html', {"slide-id": "slide-00"})
```

---

## Не забудьте про скриншоты

Для каждой версии презентации нужны свои скриншоты:

[![](https://intra.rocketfirm.com/media/posts/1566/142857411360b0d2efc286a.jpg)](https://intra.rocketfirm.com/media/posts/1566/142857411360b0d2efc286a.jpg)

---

## Запустить проект и собрать build

**Для запуска:**

$ gulp --lang=ru //Запуск презентации с русским языком $ gulp //Запуск презентации с языком который указан последним в data-alllangs="ru,kz" ```
$ gulp --lang=ru  //Запуск презентации с русским языком$ gulp            //Запуск презентации с языком который указан последним в data-alllangs="ru,kz"
```

**Переклюклечение между языками**

```
$ gulp --lang=kz  //Запуск презентации c казахским языком
```

Не перезапуская перезентацию можно переключиться в панели выбора языка:

[![](https://intra.rocketfirm.com/media/posts/1566/83505096860b0d2efc49b9.jpg)](https://intra.rocketfirm.com/media/posts/1566/83505096860b0d2efc49b9.jpg)

**Сборка слайдов и билд:**

```
$ gulp make:thumbs --lang=ru          //создание превью из скриншотов с русским языком
$ gulp make:export --lang=ru          //создание export.pdf из скриншотов с русским языком
$ gulp build:all --lang=ru            //сборка всех слайдов с русским языком

$ gulp make:thumbs --lang=kz          //создание превью из скриншотов с казахским языком
$ gulp make:export --lang=kz          //создание export.pdf из скриншотов с казахским языком
$ gulp build:all --lang=kz            //сборка всех слайдов с казахским языком
```

---

## Результат 

[![](https://intra.rocketfirm.com/media/posts/1566/170397989260b0d2efc740f.jpg)](https://intra.rocketfirm.com/media/posts/1566/170397989260b0d2efc740f.jpg)

---

Автор: Ярослав Камбаров