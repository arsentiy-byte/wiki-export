# Книги > Archived > Live чат на Firebase > Подключение Android :: Пошаговое создание конфигурации

# Подключение Android :: Пошаговое создание конфигурации

**1.** После клика и выбора версии клиента в нашем случае android попадаем на экран создания конфигов для проекта.

Здесь нам нужно найти наш package name иными словами то как называется и идетифицируется наш проект в экосистеме андроид.

[![Screen Shot 2021-08-31 at 11.07.43 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/hiyscreen-shot-2021-08-31-at-11-07-43-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/hiyscreen-shot-2021-08-31-at-11-07-43-pm.png)

**2.** Найти его можно по нескольким адресам первый - **android/app/build.gradle **ищем в этом файле android =&gt; defaultConfig =&gt; applicationId

[![Screen Shot 2021-08-31 at 11.06.22 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-06-22-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-06-22-pm.png)

Второй - **android/app/src/main/java/com/&lt;your\_project\_name&gt;/MainApplicationJava **либо второй файл в этой директории они оба содержат название проекта

[![Screen Shot 2021-08-31 at 11.07.03 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-07-03-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-07-03-pm.png)

Ну и третий вариант если с остальными не повезло это **android/app/src/main/AndroidManifest.xml** 

**[![Screen Shot 2021-08-31 at 11.22.13 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-22-13-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-22-13-pm.png)**

После того как нашли свой id и вписали название проекта можно нажимать Register app.

**3.** После генерации проекта вам будет предоставлен json файл который нужно будет скачать и скопировать в ваш проект по пути: **android/app/** В этом файле содержатся все конфигурационные файлы и настройки необходимые для инициализации firebase у вас в приложении. Ни какие манипуляции по настройки и прописыванию init конфигов как это делается в ВЕБ версии делать не нужно.

**[![Screen Shot 2021-08-31 at 11.08.02 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-08-02-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-08-02-pm.png)**

**[![Screen Shot 2021-08-31 at 11.09.00 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-09-00-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-09-00-pm.png)**

**4.** Четвертым пунктом нам нужно прописать в настройках нашего проекта нужные SDK. Находим по пути **android/build.gradle** и вносим необходимые дополнения

```
buildscript {
  repositories {
    // Check that you have the following line (if not, add it):
    google()  // Google's Maven repository

  }
  dependencies {
    ...
    // Add this line
    classpath 'com.google.gms:google-services:4.3.10'

  }
}

allprojects {
  ...
  repositories {
    // Check that you have the following line (if not, add it):
    google()  // Google's Maven repository

    ...
  }
}
```

[![Screen Shot 2021-09-01 at 1.12.43 AM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-09-01-at-1-12-43-am.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-09-01-at-1-12-43-am.png)

А так же по пути **android/app/build.gradle** вносим соответствующие изменения

```
apply plugin: 'com.android.application'

// Add this line
apply plugin: 'com.google.gms.google-services'


dependencies {
  // Import the Firebase BoM
  implementation platform('com.google.firebase:firebase-bom:28.4.0')


  // Add the dependencies for the desired Firebase products
  // https://firebase.google.com/docs/android/setup#available-libraries
}
```

[![Screen Shot 2021-08-31 at 11.11.15 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-11-15-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-11-15-pm.png)

[![Screen Shot 2021-08-31 at 11.20.23 PM.png](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/scaled-1680-/screen-shot-2021-08-31-at-11-20-23-pm.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2021-08/screen-shot-2021-08-31-at-11-20-23-pm.png)

На этой ноте можно считать что с инициализацией и установкой зависимостей для подключения firebase покончено. Теперь все что нам нужно сделать это обратиться к firebase в нашем проекте.