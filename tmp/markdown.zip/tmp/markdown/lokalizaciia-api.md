# Книги > PHP > Laravel cookbook > Локализация API

# Локализация API

При использовании пакета [Spatie Laravel Translatable](https://spatie.be/docs/laravel-translatable/v6/introduction):

1\. Создаём **LocalizationMiddleware**

```php
headers->get('Accept-Language'), ['en', 'ru', 'kk'])) {
            app()->setLocale($locale);
        } else {
            app()->setLocale(config('app.locale'));
        }

        return $next($request);
    }
}
```

2\. Подключаем в **app/Http/Kernel.php**

```php
	protected $middlewareGroups = [
	...
        'api' => [
			...
            LocalizationMiddleware::class
        ],
    ];

    protected $routeMiddleware = [
		...
        'localization' => LocalizationMiddleware::class,
    ];
```

3\. В API локализацию получаем в заголовке **Accept-Language**

4\. **При использовании локализации в поле** ***slug*** (URL) запрос на поиск в модель отправляется по полю JSON ([Querying translations](https://spatie.be/docs/laravel-translatable/v6/basic-usage/querying-translations)).

```php
->where('slug->'.app()->getLocale(), $slug)
```