# Книги > Frontend > Расширения для VSCode > Обязательные расширения для VSCode

# Обязательные расширения для VSCode

Тут расписаны обязательные расширения для VSCode, для комфортной индивидуальной работы или в команде.

## Code format

В данной категории список расширении, которые отвечают за формат кода. Это важно, чтоб при командной работе формат кода был одинаковый, и помимо этого было комфортно читать и свой и чужой код:

- [Prettier Formatter](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode) – основной форматер кода, конфиг которого интегрирован в наши проекты
- [EditorConfig](https://marketplace.visualstudio.com/items?itemName=EditorConfig.EditorConfig) – плагин позволяющий настраивать Workspace IDE или текстового редактора по общему конфигу проекта
- [Bracket Pair Colorizer 2](https://marketplace.visualstudio.com/items?itemName=CoenraadS.bracket-pair-colorizer-2) – подсвечивает пару скобок, для отличия нужного блока в коде
- [Highlight Matching Tag](https://marketplace.visualstudio.com/items?itemName=vincaslt.highlight-matching-tag) – подсвечивает пару тегов, для понимания где закрывающий тег
- [Indent-Rainbow](https://marketplace.visualstudio.com/items?itemName=oderwat.indent-rainbow) – подсвечивает индентацию, за счет чего можно легко понимать, на каком уровне индентации должен находиться тот или иной блок кода
- [Vetur](https://marketplace.visualstudio.com/items?itemName=octref.vetur) – пакет расширении для работы и форматирования Vue.js кода

## Linters &amp; code checkers

В данной категории, расширении, которые предназначены для линтеривания кода, проверки кода.

- [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint) – основной линтер JS кода, который стандартизирует правописание кода, конфиг которого интегрирован в наши проекты
- [Code Spell Checker](https://marketplace.visualstudio.com/items?itemName=streetsidesoftware.code-spell-checker) – расширение, которое проверяет правописание названии функции, перемен, классов и прочее. Полезно, чтоб не писать нейминги с ошибками и проверять орфографию
- [stylelint](https://marketplace.visualstudio.com/items?itemName=stylelint.vscode-stylelint) – линтер стилей, который стандартизирует правописание стилей, конфиг которого интегрирован в наши проекты

## GIT

- [GitLens](https://marketplace.visualstudio.com/items?itemName=eamodio.gitlens) – расширение, которое улучшает взаимодействие разработчика с Git, и позволяет работать с Git в рамках VSCode
- [GitLab Workflow](https://marketplace.visualstudio.com/items?itemName=GitLab.gitlab-workflow) – добавляет возможность взаимодействовать с GitLab в рамках VSCode, для примера создания MR с рабочей ветки нажатием одной кнопки в VSCode

## Utilities

Тут расписаны расширения, которые помогают в разработке и добавляют дополнительные фишки для VSCode

- [Error Lens](https://marketplace.visualstudio.com/items?itemName=usernamehw.errorlens) – явно подсвечивает ошибки в коде, которые легче читать
- [Import Cost](https://marketplace.visualstudio.com/items?itemName=wix.vscode-import-cost) – показывает сколько весит модуль в импорте, для контроля размера бандла
- [Turbo Console Log](https://marketplace.visualstudio.com/items?itemName=ChakrounAnas.turbo-console-log) – позволяет добавлять console.log выделенной переменной или метода при помощи горячих клавиш

Данные расширения увеличивают комфорт в работе с текстовым редактором VSCode и решает вопрос линтинга и форматинга кода, согласно настроенным конфигам в проектах.