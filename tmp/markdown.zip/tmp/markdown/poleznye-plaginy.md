# Книги > PHP > Laravel > Полезные плагины

# Полезные плагины

- [Laravel Pint](https://laravel.com/docs/9.x/pint "Расчёска для PHP code style") - расчёска для PHP code style
- [Laravel IDE Helper Generator](https://github.com/barryvdh/laravel-ide-helper) - генератор нотаций, чтобы в IDE всё подсвечивалось и автозаполнялось