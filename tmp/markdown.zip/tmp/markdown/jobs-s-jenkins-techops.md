# Книги > WALL-E bot > Job's с Jenkins [TechOps]

# Job's с Jenkins [TechOps]

Для оповещений работ нужно добавить проект по команде `/add_project [KEY_PROJECT]`.  
После ввести команду `/jenkins_webhook` и полученную ссылку добавить в конфигурацию деплоя.

[![image-1645817451897.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645817451897.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645817451897.png)

Вывод работ будет таким

[![image-1645817502034.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/image-1645817502034.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/image-1645817502034.png)