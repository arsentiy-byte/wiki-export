# Книги > Magnolia crm > User manual > Magnolia Accreditation Beginner Level 101

# Magnolia Accreditation Beginner Level 101

[![Снимок экрана 2022-02-25 в 11.39.35.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/snimok-ekrana-2022-02-25-v-11-39-35.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/snimok-ekrana-2022-02-25-v-11-39-35.png)

[Pdf Magnolia Accreditation Beginner Level 101](https://disk.yandex.kz/i/cAtdTWUY1ivMTA "Pdf Magnolia Accreditation Beginner Level 101")