# Книги > Onboarding. Добро пожаловать на борт! > Экскурсия по офису

# Экскурсия по офису

Если ты удаленно, то мы рады тебе показать наш уютный офис.

Видео-экскурсия по ссылке :)

https://drive.google.com/file/d/18f8Di1v2Qf7K8cl5Ghv3ppJYKl8QaKwD/view?usp=sharing