# Книги > Правила продаж > SMM > Бриф на SMM

# Бриф на SMM

**[Бриф на SMM](https://docs.google.com/forms/d/e/1FAIpQLScr5x-Xz5tJwQ1XpA1EqL6otdLQLyGCDHUX8bUdf3fhDJqFNg/viewform?usp=sf_link)**

[https://www.notion.so/990952fd234d407694b1cb619eefc448#56b8164bb3bd44feab1755fd6669f2a4](https://www.notion.so/990952fd234d407694b1cb619eefc448#56b8164bb3bd44feab1755fd6669f2a4)

**[Презентация по SMM](https://yadi.sk/i/CcQJ3cJ-0UI9ow)**

[https://www.notion.so/990952fd234d407694b1cb619eefc448#8108a86def0945c799d03393a4ee721b](https://www.notion.so/990952fd234d407694b1cb619eefc448#8108a86def0945c799d03393a4ee721b)

**[Ссылки на проекты](https://www.notion.so/6c73010d68e94b2288781480ec35c579)**

[https://www.notion.so/6c73010d68e94b2288781480ec35c579#bd4cc31291104d3aa6285d94b3ffb800](https://www.notion.so/6c73010d68e94b2288781480ec35c579#bd4cc31291104d3aa6285d94b3ffb800)

[https://www.notion.so/6c73010d68e94b2288781480ec35c579#0319fcfdf7144a68bb3b932150661dbd](https://www.notion.so/6c73010d68e94b2288781480ec35c579#0319fcfdf7144a68bb3b932150661dbd)

[https://www.notion.so/6c73010d68e94b2288781480ec35c579#f7c02e3dcf134c2fb605a3b75002f90d](https://www.notion.so/6c73010d68e94b2288781480ec35c579#f7c02e3dcf134c2fb605a3b75002f90d)

[https://www.notion.so/6c73010d68e94b2288781480ec35c579#35f979e844f042bfa10524520878765a](https://www.notion.so/6c73010d68e94b2288781480ec35c579#35f979e844f042bfa10524520878765a)

[https://www.notion.so/6c73010d68e94b2288781480ec35c579#bb27ba4f779d4866b9e0efa72bd491a7](https://www.notion.so/6c73010d68e94b2288781480ec35c579#bb27ba4f779d4866b9e0efa72bd491a7)

[https://www.notion.so/6c73010d68e94b2288781480ec35c579#4fcd0ac6d1d844bfa14bef12c69ef5cf](https://www.notion.so/6c73010d68e94b2288781480ec35c579#4fcd0ac6d1d844bfa14bef12c69ef5cf)