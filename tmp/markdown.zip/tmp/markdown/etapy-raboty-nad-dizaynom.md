# Книги > Правила продаж > Инструментарий > Этапы работы над дизайном

# Этапы работы над дизайном

# Этапы разработки дизайн проекта:

— разработка дизайн-концепта

После получения брифа дизайнер и арт директор готовят на примере 1-2 страниц дизайн концепцию будущего сайта. На встрече мы защищаем сам дизайн концепт, получаем обратную связь и дорабатываем его.

Ниже примеры презентаций по защите дизайн-концепта.

• Интернет-магазин казахстанских производителей - [sonda.kz](http://sonda.kz) - [yadi.sk/i/Ss2YZ4-0IkRMPw](https://yadi.sk/i/Ss2YZ4-0IkRMPw)

• Туристический портал - [kazakhstan.travel](https://kazakhstan.travel/) - [yadi.sk/i/o6xRWDi78cNa2w](https://yadi.sk/i/o6xRWDi78cNa2w)

• Лендинг для Highvill Gold Ishim - [yadi.sk/i/6BV7ICTjSMezOw](https://yadi.sk/i/6BV7ICTjSMezOw)

• Сайт для Назарбаев Университета - [https://yadi.sk/i/MmoCLnMXMCAGKw](https://yadi.sk/i/MmoCLnMXMCAGKw)

• Сервис по заказу дизайна интерьера - [seenus.org](https://seenus.org/) - [yadi.sk/i/dYY4\_rX-3ht4Xw](https://yadi.sk/i/dYY4_rX-3ht4Xw)

— разработка прототипа

Далее готовим прототип для того, чтобы была ясна навигация. Пример прототипа под проект «E-кск» - [invis.io/TZDF7RBD7#/252464049\_------------1](https://invis.io/TZDF7RBD7#/252464049_------------1)

— разработка UI кита

Пример разработанного UI кита для проекта «Kaztube» - [yadi.sk/i/C698foTX7LE6hA](https://yadi.sk/i/C698foTX7LE6hA)

— разработка всех остальных макетов.

Резюме арт-директора и художественного руководителя доступны по ссылке [https://yadi.sk/d/E7yNivRNAYEEbQ](https://yadi.sk/d/E7yNivRNAYEEbQ)