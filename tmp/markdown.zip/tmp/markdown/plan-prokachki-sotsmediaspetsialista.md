# Книги > План прокачки соцмедиаспециалиста > План прокачки соцмедиаспециалиста

# План прокачки соцмедиаспециалиста

Соцмедиаменеджер принимает участие в создании и реализации смм-стратегии. Размещает рекламу в соцсетях, отвечает на вопросы подписчиков, организует работу над контент-планом: заказывает текст у копирайтера, картинки — у дизайнера и фотографа. Умеет ставить задачи и контролировать их исполнение; знает разницу между «делать» и «сделать».

SMM-специалист может быть опытным, а может быть и начинающим. Вся база материалов рассчитана на разный уровень/опыт и разбита по ступеням: джуниор, специалист, ведущий специалист.

###   
Что нужно изучить, независимо от опыта и уровня

**Введение**

- [Что такое Интра?](https://wiki.rocketfirm.com/books/ob-intre)
- [Кодекс ракетчика](https://wiki.rocketfirm.com/books/kodeks-raketchika)
- [Регламент работы смм-специалиста](https://wiki.rocketfirm.com/books/reglament-raboty-smm-spetsialista)
- [Рост смм-специалиста](https://wiki.rocketfirm.com/books/rost-sotsmediaspetsialista)
- [Профессиональный чек-лист](https://wiki.rocketfirm.com/books/professionalnyy-chek-list)
- [Отпуск, отгул, пропуск и опоздание](https://wiki.rocketfirm.com/books/otpusk-otgul-propusk-i-opozdanie)

**Письма**

- [Тема в электронном письме](https://intra.rocketfirm.com/library/management/237-tema-v-elektronnyh-pismah/)
- [Стоп фразы](https://intra.rocketfirm.com/library/management/254-stop-frazy/)
- [Обработка обратной связи от клиента](https://intra.rocketfirm.com/library/management/551-obrabotka-obratnoj-svazi/)
- [Подпись в письме](https://intra.rocketfirm.com/library/rocket-firm/409-firmennaa-podpis/)

**Менеджмент**

- [Работа с замечаниями клиента](https://intra.rocketfirm.com/library/management/457-rabota-s-zamecaniami-klienta/)
- [Постановка задач фрилансерам](https://intra.rocketfirm.com/library/management/490-principy-raboty-s-vnestatnymi-podradcikami/)
- [Постановка задач в команде](https://intra.rocketfirm.com/library/management/kak-stavit-zadacu-icpolnitelam-primer-brifa/)
- [Принципы коммуникации в команде ](https://intra.rocketfirm.com/library/rocket-firm/447-principy-kommunikacii-v-komande-i-pravila-perepiski/)
- [Правила переписки через мессенджеры внутри команды](https://intra.rocketfirm.com/library/rocket-firm/srazu-k-delu/)
- [Что делать, когда все плохо](https://wiki.rocketfirm.com/books/chto-delat-kogda-vse-plokho)

**Креатив**

- [Стратегия и ее создание](https://wiki.rocketfirm.com/books/struktura-strategii-i-poleznye-materialy-dlya-oblegcheniya-ee-sozdaniya)
- [Шаблон описания креативной концепции](https://wiki.rocketfirm.com/books/shablon-kreativnogo-brifa)
- [Инструменты для копирайтинга](https://wiki.rocketfirm.com/books/instrumenty-kopiraytera)
- [Как победить открытую задачу методом перебора](https://intra.rocketfirm.com/library/designers/kak-pobedit-otkrytuu-zadacu-metodom-perebora/)

**Полезные инструменты в соцмедиа**

- [Сервис для сбора статистики по группам](https://popsters.ru/#/vk)
- [Планировщик](https://smmplanner.com/)
- [@text4instabot](https://wiki.rocketfirm.com/t.me/text4instabot) — бот, разбивающий текст на абзацы
- [@SaveAsBot](https://wiki.rocketfirm.com/t.me/SaveAsBot) — бот, качающий видео с инсты
- [Главред — сервис, проверяющий текст](https://glvrd.ru/)
- [Сервис для скачивания видео с ютуба](https://ru.savefrom.net/)
- [Сервис для редакции фото и видео](https://inshot-editor.ru.uptodown.com/android)
- [Livedune — сервис для сбора статистика в соцсетях](https://livedune.ru/)
- [Создание гифок](http://toolson.net/)

###   
Что должен знать джуниор

**Что такое страницы на Facebook, как с ними взаимодействовать**

- [Как создать страницу и управлять](https://www.facebook.com/help/135275340210354/?helpref=hc_fnav)
- [Имя, имена пользователей, проверка](https://www.facebook.com/help/1644118259243888/?helpref=hc_fnav)
- [Роли страниц](https://www.facebook.com/help/1206330326045914/?helpref=hc_fnav)
- [Размещение публикаций](https://www.facebook.com/help/182487968815949/?helpref=hc_fnav)
- [Настройка страницы](https://www.facebook.com/help/1602483780062090/?helpref=hc_fnav)
- [Статистика страницы](https://www.facebook.com/help/794890670645072/?helpref=hc_fnav)
- [Модерация](https://www.facebook.com/help/248844142141117/?helpref=hc_fnav)
- [Часто встречающиеся проблемы](https://www.facebook.com/help/1020132651404616/?helpref=hc_fnav)
- [Что такое «глобальная страница»](https://www.facebook.com/business/help/905034079579176/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Creating%20Ads%20from%20your%20Page)
- [ВСЁ, что нужно знать о странице БРЕНДА](https://www.facebook.com/business/help/169423786945057/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Creating%20Ads%20from%20your%20Page)

**Как вести страницу в Instagram**

- [Публикации](https://help.instagram.com/488619974671134/?helpref=hc_fnav&bc%5B0%5D=%D0%A1%D0%BF%D1%80%D0%B0%D0%B2%D0%BE%D1%87%D0%BD%D1%8B%D0%B9%20%D1%86%D0%B5%D0%BD%D1%82%D1%80%20Instagram&bc%5B1%5D=%D0%98%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5%20Instagram&bc%5B2%5D=%D0%9F%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0%D1%86%D0%B8%D1%8F%20%D1%84%D0%BE%D1%82%D0%BE%20%D0%B8%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BE)
- [Как связать аккаунт на Instagram к Странице Facebook, которой я управляю?](https://help.instagram.com/356902681064399?helpref=hc_fnav)
- [Как устроена лента Instagram](https://help.instagram.com/1986234648360433)
- [Что такое значок подтверждения?](https://help.instagram.com/733907830039577?helpref=hc_fnav)
- [Что можно сделать, если у меня больше нет доступа к электронному адресу, который использовался при регистрации?](https://help.instagram.com/358911864194456?helpref=related&ref=related)
- [IGTV](https://help.instagram.com/381435875695118)
- [Как поделиться чьей-либо публикацией из ленты в моей истории?](https://help.instagram.com/1013375002134043)
- [Использование наклеек в Instagram](https://help.instagram.com/151273688993748)
- [Как загружать, записывать и редактировать фото и видео в истории?](https://help.instagram.com/314684928883274?helpref=faq_content)
- [Привязка аккаунтов](https://help.instagram.com/1094643983940381/?helpref=hc_fnav&bc%5B0%5D=%D0%A1%D0%BF%D1%80%D0%B0%D0%B2%D0%BE%D1%87%D0%BD%D1%8B%D0%B9%20%D1%86%D0%B5%D0%BD%D1%82%D1%80%20Instagram&bc%5B1%5D=Instagram%20%D0%B4%D0%BB%D1%8F%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D0%B9)
- [Общие сведения о бизнес-профилях в Instagram](https://help.instagram.com/307876842935851/?helpref=hc_fnav&bc%5B0%5D=%D0%A1%D0%BF%D1%80%D0%B0%D0%B2%D0%BE%D1%87%D0%BD%D1%8B%D0%B9%20%D1%86%D0%B5%D0%BD%D1%82%D1%80%20Instagram&bc%5B1%5D=Instagram%20%D0%B4%D0%BB%D1%8F%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D0%B9)

###   
Что должен знать соцмедиаспециалист

**Реклама на Facebook, общие сведения**

- [Как работает реклама на Facebook?](https://www.facebook.com/help/516147308587266/?helpref=hc_fnav)
- [Правила размещения рекламы на Facebook](https://www.facebook.com/policies/ads)
- [Подготовка к запуску рекламы на Facebook](https://www.facebook.com/business/help/714656935225188/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Advertising%20Basics&bc%5B3%5D=About%20Facebook%20Advertising)
- [Структура рекламной кампании](https://www.facebook.com/business/help/613846972027099/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Advertising%20Basics&bc%5B3%5D=About%20Facebook%20Advertising)
- [Продвижение промоакций на странице бренда](https://www.facebook.com/business/help/547448218658012?helpref=page_content)
- [Создание публикаций страницы в Ads Managare](https://www.facebook.com/business/help/164280010440375/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Creating%20Ads%20from%20your%20Page)
- [Разница между поднимаемы публикациями и рекламой постов](https://www.facebook.com/business/help/317083072148603?helpref=page_content)
- [Как поднять публикации на Facebook ](https://www.facebook.com/business/help/240208966080581?helpref=page_content)
- [О бюджете в рекламных кампаниях](https://www.facebook.com/business/help/214319341922580?helpref=topq)
- [Реклама мероприятий](https://www.facebook.com/business/help/1344120142294231/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Creating%20Ads%20from%20your%20Page)
- [Общее руководство по рекламе на Facebook для начинающих](https://www.facebook.com/business/help/337584869654348/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Guides%20for%20Advertisers)
- [Общее руководство по рекламе на Facebook для специалистов с опытом](https://www.facebook.com/business/help/1145298662186672/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Guides%20for%20Advertisers)

**Реклама на Facebook, как создавать кампанию**

- [Инструменты для создания рекламы](https://www.facebook.com/business/help/638274812874211/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads)
- [Ads Manager: основы](https://www.facebook.com/business/help/415745401805534/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Creating%20Ads%20in%20Ads%20Manager)
- [Подробное руководство по Ads Manager](https://www.facebook.com/business/help/1138410786211427/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Creating%20Ads%20in%20Ads%20Manager)
- [Основные настройки таргетинга](https://www.facebook.com/business/help/633474486707199/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Ad%20Audiences)
- [Бюджет, ставки, планирование и списания](https://www.facebook.com/business/help/527780867299597/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads)
- [Реклама в видеороликами](https://www.facebook.com/business/help/830194837058589/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Ad%20Creative)

**Рекламные креативы (фото, видео-контент)**

- [Вижуалы](https://www.facebook.com/business/help/515700171838091/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Ad%20Creative)
- [Видео](https://www.facebook.com/business/help/830194837058589/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Ad%20Creative)
- [Галерея](https://www.facebook.com/business/help/515741471908766/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Ad%20Creative)
- [Руководство по рекламе, требования к креативам и технические](https://www.facebook.com/business/help/1659484897658040/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Creating%20Ads&bc%5B3%5D=Ad%20Creative)

**Реклама в Инстаграм**

- [Инструменты для кампаний в instagram](https://www.facebook.com/business/help/897631030335607/)
- [Пошаговое руководство по бизнес Instagram на английском языке](https://scontent.fala4-1.fna.fbcdn.net/v/t39.2365-6/10000000_149860582102362_375661352_n.pdf?_nc_cat=0&oh=bd1ba001655ba87d9bd2e2c52382e2b7&oe=5BCC9161)
- [Полный раздел о рекламе в Instagram в справке Facebook](https://www.facebook.com/business/help/976240832426180/)
- [Отчеты и статистика в Instagram](https://www.facebook.com/business/support/topic/reporting-and-insights)

###   
Что должен знать ведущий соцмедиаспециалист

**Соцсети**

1. [Советы по рекламе на Faceebook для опытных рекламодателей (медийка)](https://www.facebook.com/business/help/312078865836404/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Guides%20for%20Advertisers)
2. [Blue Print](https://www.facebook.com/business/help/408880929309046/?helpref=hc_fnav&bc%5B0%5D=AHCv1&bc%5B1%5D=Ads%20Help&bc%5B2%5D=Additional%20Resources%20for%20Advertisers)
3. [Брендированные материалы в Instagram](https://help.instagram.com/116947042301556/?helpref=hc_fnav&bc%5B0%5D=%D0%A1%D0%BF%D1%80%D0%B0%D0%B2%D0%BE%D1%87%D0%BD%D1%8B%D0%B9%20%D1%86%D0%B5%D0%BD%D1%82%D1%80%20Instagram&bc%5B1%5D=Instagram%20%D0%B4%D0%BB%D1%8F%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D0%B9)
4. [Полный раздел о рекламе в Instagram](https://www.facebook.com/business/support/topic/instagram)

**Управление проектами**

1. Яндекс школа для менеджеров ([YouTube](https://www.youtube.com/channel/UCQmAuu6V3kSzdIfrszr5iKg))
2. SMART, [правила постановки задач](http://powerbranding.ru/marketing-strategy/smart-celi/)
3. Книга Джозеф Хигни «Основы управления проектами» ([скачать, epub](https://yadi.sk/i/SEPRnq8M3WaZEX))
4. Том ДеМарко «Deadline: роман об управлении проектами» ([скачать, fb2](https://yadi.sk/i/tBY7JSEF3WaZRo))
5. Дэн Кеннеди «Жесткий менеджмент» ([скачать, epub](https://yadi.sk/i/Who4oBvL3Waawo))
6. [Взаимоотношения с клиентами](http://artgorbunov.ru/bb/soviet/found/%D0%B2%D0%B7%D0%B0%D0%B8%D0%BC%D0%BE%D0%BE%D1%82%D0%BD%D0%BE%D1%88%D0%B5%D0%BD%D0%B8%D1%8F+%D1%81+%D0%BA%D0%BB%D0%B8%D0%B5%D0%BD%D1%82%D0%BE%D0%BC) в «Советах» Бюро
7. Рассылка Ильяхова о работе с клиентами ([статья](https://intra.rocketfirm.com/books/post/829-platnyj-kurs-ilahova-o-rabote-s-klientami/) в Интре)
8. Максим Батырев «45 татуировок менеджера» ([скачать, epub](https://yadi.sk/i/VmjmETaS3WabY7))

**SEO и медийка**

1. Что такое GTM ([статья](https://intra.rocketfirm.com/seomedia/post/podklucenie-google-tag-manager/) в Интре)
2. Что такое программатики ([статья](https://intra.rocketfirm.com/tech/post/706-wtf-programmatic-the-programmatic-advertising-survival-guide/) в Интре)
3. Обучающий [курс по Google Analytics](https://support.google.com/analytics/answer/4553001?hl=ru)
4. Обучающий [курс по Метрике](https://www.youtube.com/playlist?list=PLjEKjSpX1kHXiwpHpR_j44YFxXaq7GYrh)
5. Курсы на [ppc.world](https://ppc.world/courses/)
6. Чек-лист по SEO перед запуском проекта ([статья](https://intra.rocketfirm.com/seomedia/post/435-cek-list-po-seo-pered-zapuskom-proekta/) в Интре)