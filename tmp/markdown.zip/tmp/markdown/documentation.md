# Книги > QA > Postman > Documentation

# Documentation

## Оглавление

- Markdown
- Название коллекций
- Описание коллекций
- Название директорий
- Описание директорий
- Название API
- Описание API
- Deprecated
- HTML-doc

## Markdown

[**Markdown**](https://ru.wikipedia.org/wiki/Markdown) — облегчённый язык разметки, созданный с целью написания наиболее читаемого и удобного для правки текста, но пригодного для преобразования в языки для продвинутых публикаций.

Все описания (a.k.a **description**) имеют поддержку markdown. Этот тот самый markdown который мы используем в [**README.md**](https://ru.wikipedia.org/wiki/README-%D1%84%D0%B0%D0%B9%D0%BB).

[ ![](https://lh3.googleusercontent.com/ZDg79iegNlBTB-udS6ZNr02ydP-US8rpXoTpeoS0iqC9VaMI2pH8gfWWSjzljBTccIxoD26ACpEvnlVixylx1EPg9fdvO1NjnMNeQ4kJg6hcwPCnOViWCINJfWq31Ov_5tCUu3-I)](https://lh3.googleusercontent.com/ZDg79iegNlBTB-udS6ZNr02ydP-US8rpXoTpeoS0iqC9VaMI2pH8gfWWSjzljBTccIxoD26ACpEvnlVixylx1EPg9fdvO1NjnMNeQ4kJg6hcwPCnOViWCINJfWq31Ov_5tCUu3-I)

## Название коллекций

Коллекциям можно писать **названия с понятным контекстом**, а можно просто ввести **DNS** или **название проекта** с флагом [STAGE|PROD](https://ru.wikipedia.org/wiki/%D0%9E%D0%BA%D1%80%D1%83%D0%B6%D0%B5%D0%BD%D0%B8%D1%8F_%D1%80%D0%B0%D0%B7%D0%B2%D1%91%D1%80%D1%82%D1%8B%D0%B2%D0%B0%D0%BD%D0%B8%D1%8F_%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC%D0%BD%D0%BE%D0%B3%D0%BE_%D0%BE%D0%B1%D0%B5%D1%81%D0%BF%D0%B5%D1%87%D0%B5%D0%BD%D0%B8%D1%8F).

[ ![](https://lh6.googleusercontent.com/1ycOUFDCW20ufWFtOnLUZWvOF2vrPtYIzil0-gympdyPkSxc_DHwdcdD0XK0sfTXja6ZxnIA4YLHfMp6-TJQF2MSrqTZozpalnE9kEGc3uR63ssqaeQilWvIUTIIMhxwT3EdwILT)](https://lh6.googleusercontent.com/1ycOUFDCW20ufWFtOnLUZWvOF2vrPtYIzil0-gympdyPkSxc_DHwdcdD0XK0sfTXja6ZxnIA4YLHfMp6-TJQF2MSrqTZozpalnE9kEGc3uR63ssqaeQilWvIUTIIMhxwT3EdwILT)

## Описание коллекций

В **описание коллекции** можно записать **общую информацию по API**, то как с ними работать и какой нибудь мотивирующий текст.

[ ![](https://lh6.googleusercontent.com/5Nk_GLXi54VfcHadB9bcRykaMO9fD6FoIloBdGsRXFVVBi_JSQ7gQyNvg_g7C5CDJcYw0A2y4-A7cTaO6Sb_sJuqYKaOWFyVOxMsIZrCDx3OAAMlQOQ8pr3Umpf1ac7OOIA0QEYE)](https://lh6.googleusercontent.com/5Nk_GLXi54VfcHadB9bcRykaMO9fD6FoIloBdGsRXFVVBi_JSQ7gQyNvg_g7C5CDJcYw0A2y4-A7cTaO6Sb_sJuqYKaOWFyVOxMsIZrCDx3OAAMlQOQ8pr3Umpf1ac7OOIA0QEYE)

## Название директорий

Директории должны **сортировать**. Названия в директориях могут быть **разными**. Захотели назвали вложенности так, как построен endpoint. Захотели написали только отображение контекста. Захотели выделили только версию для API и его [deprecated](https://ru.wikipedia.org/wiki/Deprecation).

[ ![](https://lh4.googleusercontent.com/Cm2ZTWF5t5uI-jMmXkfR5FrHIw2pSzoweFCqaK-Bndo9z4VE_IBkD4oDQ4HwoEHf71rQaWHYUESS1nfIEK1WuoSa5yAZXv8mDTfDRWsHLomatexipLBhI9TkHnVipQUpOT5bZNYU)](https://lh4.googleusercontent.com/Cm2ZTWF5t5uI-jMmXkfR5FrHIw2pSzoweFCqaK-Bndo9z4VE_IBkD4oDQ4HwoEHf71rQaWHYUESS1nfIEK1WuoSa5yAZXv8mDTfDRWsHLomatexipLBhI9TkHnVipQUpOT5bZNYU)

## Описание директорий

Директории описывают свою **вложенность**. Информация в ней обычно обобщенная, которая дает **понять разработчику** о чем эта директория.

[ ![](https://lh5.googleusercontent.com/QbiF9C_YyktwORSxw4Le8mVNb6hYeACxOobprp355yWwB6_oCvEhfHVysA8UwnBTTv-Or7AWZLklJpawumQQSEKtV8KjWyDVfcgfAe9QC7ZUk2UFok8aP1LDX7Rf8UnegA3NF1tX)](https://lh5.googleusercontent.com/QbiF9C_YyktwORSxw4Le8mVNb6hYeACxOobprp355yWwB6_oCvEhfHVysA8UwnBTTv-Or7AWZLklJpawumQQSEKtV8KjWyDVfcgfAe9QC7ZUk2UFok8aP1LDX7Rf8UnegA3NF1tX)

## Название API

Описываем в **двух словах** про API и добавляем endpoint для того, чтобы мы могли **использовать** **обычный поиск**, а не глобальный.

[ ![](https://lh6.googleusercontent.com/MXK9kbSnS9Eezg9rdFd7_aksik6FfRuZAW6fIhp9YqW24amNkQQCXO4JTGGw88WnJA-1g0uDUTPMGPxh-U2W-FsjSSs16vEmX93d_FCOffTi35VjD3WcHB7ao3fRZckRHB_rTdDt)](https://lh6.googleusercontent.com/MXK9kbSnS9Eezg9rdFd7_aksik6FfRuZAW6fIhp9YqW24amNkQQCXO4JTGGw88WnJA-1g0uDUTPMGPxh-U2W-FsjSSs16vEmX93d_FCOffTi35VjD3WcHB7ao3fRZckRHB_rTdDt)

## Описание API

Желательно писать:

- **Что делает** API
- **Пример** **вызова** API
- Что **подставлять** в **переменную**
- Какие **API** могут быть **взаимосвязаны** друг с другом (API для чтения, удаления..)
- **Примеры вычисления** поля по if/else

[ ![](https://lh6.googleusercontent.com/3HSV8PQh_9qVN5rNm3DBT5yZqze-LNhushibf67uSRlZ6c7jBOHqRz35w3ePQU8TPhAukVDsoj7mEBbydlE-Kt693AciW9FjDnfLT3G3ghGavUSZBzamzp-q8JydpNA6CJfXVIz8)](https://lh6.googleusercontent.com/3HSV8PQh_9qVN5rNm3DBT5yZqze-LNhushibf67uSRlZ6c7jBOHqRz35w3ePQU8TPhAukVDsoj7mEBbydlE-Kt693AciW9FjDnfLT3G3ghGavUSZBzamzp-q8JydpNA6CJfXVIz8)

## Deprecated

**Устаревшие API** тоже нужно **документировать**, но слегка по другому. Делаем описание таким образом, чтобы разработчики смогли найти **альтернативный API**.

[ ![](https://lh3.googleusercontent.com/jv7F0nu9uEX4PM1Cg-elJ5OjK41Pl-tLe52mRVbOrpU6cN7y_ziDtHB5qkqvUvc5msarkwGn1YaoRO4SsqkNo2cyS7f2QpAaNrecla06ympNYeRJjhlfLot2Egsj6bdt5UFZWlEN)](https://lh3.googleusercontent.com/jv7F0nu9uEX4PM1Cg-elJ5OjK41Pl-tLe52mRVbOrpU6cN7y_ziDtHB5qkqvUvc5msarkwGn1YaoRO4SsqkNo2cyS7f2QpAaNrecla06ympNYeRJjhlfLot2Egsj6bdt5UFZWlEN)

## HTML-doc

Команда всегда может посмотреть **документацию в браузере**. И для этого даже **не придется скачивать** Postman, т.к. Postman сам на своей стороне генерирует и позволяет делится ссылкой на HTML-doc (зависит от приватности и настроек).

[ ![](https://lh3.googleusercontent.com/o1tOvKThJrYo8QhfErfbkToNRboYO5pNff_b9rZJmLgQUEQdoB2yTzYFsiwpz243JDx4AC68lZnRFcZL9gM-dSvttZrlzkDceNlKzyfOxXhOwlKkytsEJf9zPfFyq3S-8MdQr5kh)](https://lh3.googleusercontent.com/o1tOvKThJrYo8QhfErfbkToNRboYO5pNff_b9rZJmLgQUEQdoB2yTzYFsiwpz243JDx4AC68lZnRFcZL9gM-dSvttZrlzkDceNlKzyfOxXhOwlKkytsEJf9zPfFyq3S-8MdQr5kh)

[ ![](https://lh5.googleusercontent.com/pOdanJDyYVKcmrjedUSXRpxsEz1yAD3w5PG2zhvChWZVqeVJPnnknquThSZIvB5nnYPgfBfbwMZdcjDBPZqY0jvgA367kKvgoL1AlxOVwdhaoh4vBUJACKGnktBOKri6vGKnJHLo)](https://lh5.googleusercontent.com/pOdanJDyYVKcmrjedUSXRpxsEz1yAD3w5PG2zhvChWZVqeVJPnnknquThSZIvB5nnYPgfBfbwMZdcjDBPZqY0jvgA367kKvgoL1AlxOVwdhaoh4vBUJACKGnktBOKri6vGKnJHLo)

[ ![](https://lh4.googleusercontent.com/1hfA6W0Eh1ffZbRFaAJwPA6HM3ucx9UyqgRRJw9binaUuEKG_twEQwGH4v3zFoA9Uq51677GUM2AFLs9JZOLdLdPNpvCSTZ3RhMLCCYwtEL-R0N9wQjCa-2-mLXEhuvOqBFVA_Nl)](https://lh4.googleusercontent.com/1hfA6W0Eh1ffZbRFaAJwPA6HM3ucx9UyqgRRJw9binaUuEKG_twEQwGH4v3zFoA9Uq51677GUM2AFLs9JZOLdLdPNpvCSTZ3RhMLCCYwtEL-R0N9wQjCa-2-mLXEhuvOqBFVA_Nl)

[ ![](https://lh6.googleusercontent.com/fIPaOs-mjzIBtAJd7LshgsItZtXNUhKrx4aBoyug7fL5jV5Zf-jtfnUybsGfyeE1tAuIYHsUjdbZK5vSMNwNeUAIU1JeJpWbRYD2wLnUj2qHooieLZ6Uy4cPITysyYNkvRsLpORR)](https://lh6.googleusercontent.com/fIPaOs-mjzIBtAJd7LshgsItZtXNUhKrx4aBoyug7fL5jV5Zf-jtfnUybsGfyeE1tAuIYHsUjdbZK5vSMNwNeUAIU1JeJpWbRYD2wLnUj2qHooieLZ6Uy4cPITysyYNkvRsLpORR)

## Заключение

Документация это не всегда “правильное описание”. Оно зависит и от тестов, примеров и даже переменных. Круто когда проектный код весь расписан, а еще круче когда расписаны и внешние составляющие.