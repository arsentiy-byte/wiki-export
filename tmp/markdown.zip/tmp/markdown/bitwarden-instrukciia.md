# Книги > DevOps > Bitwarden Инструкция

# Bitwarden Инструкция

#### **1. Нужно создать проект**

Пример названий:

[![image-1642759368306.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642759368306.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642759368306.png)

В квадратных скобках ключ проекта взятый с **jira.rocketfirm.com**. После скобок название самого проекта (на свое усмотрение).

#### **2. Создание пустых данных**

Есть шаблон рекомендуемых значений:

1\) \[PROJECT\] \[DEV|PROD\] Админка сайта (extra)  
Username | Password | URI 1 **&lt;- Это поля внутри карточек данных (ниже примеры)**

2\) \[PROJECT\] \[DEV|PROD\] База данных (extra)  
Username | Password | DB\_DATABASE | DB\_TYPE | DB\_HOST | DB\_PORT

3\) \[PROJECT\] \[DEV|PROD\] SSH (extra)  
Username | Password | URI 1

4\) \[PROJECT\] \[DEV|PROD\] Хостинг и домен (extra)  
Username | Password | Сайт | Админка

Пример пустых значений:

[![image-1642759537829.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642759537829.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642759537829.png)

\[QBIK\] - ключ проекта с jira.rocketfirm.com

\[PROD\] - окружение продакшен

SSH - Данные по SSH доступам

(???) - Username, но карточка пустая и мы видим пустое обозначение. Вопросительные знаки обозначают пустоту внутри данных и их следует в будущем заполнить.

Пример готовых данных:

[![image-1642760079609.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642760079609.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642760079609.png)

В этом списке понятно, что данные заполнены и можно не боятся за будущее проекта.

#### **3. Что внутри \[PROJECT\] \[DEV|PROD\] Админка сайта (extra)**

[![image-1642760183420.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642760183420.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642760183420.png)

#### **4. Что внутри \[PROJECT\] \[DEV|PROD\] База данных (extra)**

[![image-1642760277103.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642760277103.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642760277103.png)

#### **5. Что внутри \[PROJECT\] \[DEV|PROD\] SSH (extra)**

[![image-1642760344029.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642760344029.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642760344029.png)

#### **6. Что внутри \[PROJECT\] \[DEV|PROD\] Хостинг и домен (extra)**

[![image-1642760401478.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1642760401478.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1642760401478.png)

#### **7. Добавить ПМ**

ПМ должен предоставить свою почту и название проекта. ПМ в роли **Менеджер**

#### **8. При создании item из главной страницы** 

Нужно указывать группу RocketFirm и нужную коллекцию. Чтобы не сохранялось в личных кабинет и многие могли увидеть item в группе RocketFirm.

[![image-1643015610540.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/scaled-1680-/image-1643015610540.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-01/image-1643015610540.png)