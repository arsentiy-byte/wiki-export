# Книги > Magnolia crm > Video > Аттестация 2021 года

# Аттестация 2021 года

[![Снимок экрана 2022-02-25 в 10.33.07.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/scaled-1680-/snimok-ekrana-2022-02-25-v-10-33-07.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-02/snimok-ekrana-2022-02-25-v-10-33-07.png)

Первая встреча: [https://disk.yandex.kz/i/OKUgEWZZ0HgyEw](https://disk.yandex.kz/i/PQKqFQvzdIF5qw "https://disk.yandex.kz/i/PQKqFQvzdIF5qw")  
Вторая встреча: [https://disk.yandex.kz/i/ezUEH9brP8sejw](https://disk.yandex.kz/i/ki3JQkczmytjdQ "https://disk.yandex.kz/i/ki3JQkczmytjdQ")