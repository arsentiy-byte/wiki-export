# Книги > Правила продаж > Полезное > Курс по продажам от ClassCentral

# Курс по продажам от ClassCentral

### Курсы

[https://www.classcentral.com/subject/sales](https://www.classcentral.com/subject/sales)

### Блоги

Блог про продажи от Pipedrive

[https://www.pipedrive.com/en/blog](https://www.pipedrive.com/en/blog)

Блог про продажи от Sales Hacker

[https://www.saleshacker.com](https://www.saleshacker.com)

Блог HelpScout

[https://www.helpscout.com/blog/all-posts/](https://www.helpscout.com/blog/all-posts/)

Блог про продажи от Chargify

[https://www.chargify.com/blog/](https://www.chargify.com/blog/)

SalesPortal — Портал про продажи

[http://salesportal.ru](http://salesportal.ru)

35 лучших англоязычных ресурсов про продажи от HubSpot

[https://blog.hubspot.com/sales/best-sales-blogs](https://blog.hubspot.com/sales/best-sales-blogs)

[Close.io](http://close.io/) — блог о ведении бизнеса

[https://blog.close.com](https://blog.close.com)

### Телеграм каналы

Инсайды продаж

[https://t.me/salesinsides](https://t.me/salesinsides)