# Книги > Памятка > Инфографика по партнерам, платформам, дизайну и странам

# Инфографика по партнерам, платформам, дизайну и странам

[![Group 4 (1).png](https://wiki.rocketfirm.com/uploads/images/gallery/2024-10/scaled-1680-/group-4-1.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2024-10/group-4-1.png)

[Ссылка на figma вариант](https://www.figma.com/design/Z7zZ0aeiV5wYICFOsgeHjA/Untitled?node-id=0-1&node-type=canvas&t=OcDbiVagdqebg8Gs-0)