# Книги > Полезные материалы для HR > Полезные материалы для HR

# Полезные материалы для HR

**Распространение файлов запрещено**

**Курсы:**

[Курс IT-рекрутер от Laba](https://disk.yandex.kz/d/YFvi207CAkl92Q)  
[Курс HR-маркетинг](https://www.youtube.com/watch?v=uWDGSRRBN1U&list=PL4f9tHx_Bj_n2xgwgj_mv14mdIuobrdHb)  
Курс [Управление командой](https://disk.yandex.kz/d/dYXK6TWgK-tdcw)

**Полезные каналы:**

Открытые курсы от Майка Притулы на [youtube](https://www.youtube.com/c/MikePritulaAcademy/videos)  
[Канал о системном бизнесе ](https://www.youtube.com/channel/UCZlFmJ-8aj_wch2T2CWoe8w)Александра Высоцкого

**В работе пригодится:**

[Вопросы-помощники для статусов/чекпоинтов](https://talenttech.ru/blog/hr-howto/15_questions_for_employees/)  
[Как увольнять сотрудников](https://www.youtube.com/watch?v=KD0SGrCt4Qg)  
[Как увольнять сотрудников 2](https://www.youtube.com/watch?v=oBYPdiIx4AA&t=4s)  
Как оставлять у кандидатов только хорошее впечатление от подбора [PDF](https://drive.google.com/file/d/1BEb5TkC3XH99ZzlAAzhhoj0pKp4-Eq2H/view?usp=sharing)  
46 идей для поощрения сотрудников в рамках реферальной программы [PDF](https://drive.google.com/file/d/1ygghOoXJsdH9zPQE6jIfmSXaNCYmoV9v/view?usp=sharing)  
Ликбез для IT-рекрутеров: основы [видео](https://www.youtube.com/watch?v=1Za6ghKSJWY)

[Оценка 360 — что такое, для чего нужна](https://www.youtube.com/watch?v=J82SgQThBsY)  
[Статья об оценке 360](https://hurma.work/rf/blog/oczenka-metodom-360-kak-pravilno-provodit-i-primer-sostavleniya-oprosnika-2/) и как расшифровывать ответы

[О методологии eNPS и как делать подсчеты](https://hurma.work/rf/blog/metodologiya-enps-gajd-po-rabote-2/)

**Книги**

О типах сотрудников и как найти подход к каждому  
Максим Батырев   
[Сложные подчиненные‎](https://disk.yandex.kz/i/c3N9DTkjGyCaAg)

Вырезки из книг-бестселлеров о бизнесе  
«[Всё о найме: как создать команду мечты](https://disk.yandex.kz/i/jFlmO9-RTotUVQ)»‎

Как работать с деструктивными сотрудниками   
Роберт Саттон   
[Не работайте с мудаками](https://disk.yandex.kz/d/DWwOhl6SCFpZuA)  
  
Мишель Джой и Джоди Фостер  
[Мудаки под контролем](https://drive.google.com/file/d/1Dglb4_gq_V6pCJwWceWzlaI4DE3HhtqH/view?usp=sharing)  
  
Как руководить группой профессионалов  
Дэвид Майстер и Патрик Маккена  
[Первый среди равных](https://drive.google.com/file/d/1Pkct6dMeRZX4f-C5dObzAkETO4BeD6zx/view?usp=sharing)  
  
О важности корпоративной культуры и её построении  
Патрик Ленсиони   
[Сердце компании](https://disk.yandex.kz/d/2TUEuMQRL_jhuA)

Как правильно нанимать сотрудников и избавить организацию от лишних затрат  
Джефф Смарт и Рэнди Стрит   
[КТО. Решите вашу проблему №1](https://disk.yandex.kz/i/mMNtKjHHPFlTEQ)

Для HR-копирайтинга   
[Пиши, сокращай](https://drive.google.com/file/d/1LVmGMKkeRl_o2PGSNbPsXztyxHz1Yb6-/view?usp=sharing)

Адель Линн  
[Сила эмоционального интеллекта](https://drive.google.com/file/d/1Pkct6dMeRZX4f-C5dObzAkETO4BeD6zx/view?usp=sharing)