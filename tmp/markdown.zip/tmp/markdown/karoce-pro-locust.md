# Книги > QA > Нагрузочное тестирование (Perfomance testing) > Кароче про Locust

# Кароче про Locust

Открываем доку   
[https://docs.locust.io/en/stable/installation.html](https://docs.locust.io/en/stable/installation.html)  
Ставим себе python и locust

Вот тут забираем пример скрипта  
[https://docs.locust.io/en/stable/quickstart.html](https://docs.locust.io/en/stable/quickstart.html)  
Меняем целевой урл, сохраняем в .*py* файл. Например, *locustfile.py*

Запускаем locust в консоли  
`locust -f locustfile.py`

Открываем web-интерфейс [http://localhost:8089/](http://localhost:8089/)  
Там указываем количество юзеров, сколько стартует в секунду и хост. Запускаем.  
ИЛИ  
Запускаем консольно.

```
locust -f locustfile.py -u 1 -r 10 -t 3600 --headless
```

Где,

- -r - rate
- -u - количество пользователей
- -t - время теста в секундах
- The –headless flag

Смотрим результат и радуемся.   
Если что, то в правом верхнем углу RPS - это requests per second