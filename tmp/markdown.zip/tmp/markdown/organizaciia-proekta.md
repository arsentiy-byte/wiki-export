# Книги > Frontend > Frontend developer grades > Организация проекта

# Организация проекта

Каждый разработчик должен знать данные технологии, минимум, на базовом уровне(редактирование конфигов), для соблюдения санитарии кода:

- Prettier – форматирование html, css, js кода, согласовывать правила с командой
- ESLint – линтирование JS кода, согласовывать какие правила нужны или нет в команде и соблюдать правила, для написания лаконичного кода
- JSDoc – надо уметь документировать свой JS код, и уметь генерировать документацию по написанному приложению
- stylelint – линтирование scss кода
- editorconfig – настраивать, если в команде разработчики пользуются разными редакторами кода или IDE, для соблюдения единого форматирования кода.

### Ресурсы

1. Комментарии в коде – [https://intra.rocketfirm.com/library/techies/kommentarii-v-kode/](https://intra.rocketfirm.com/library/techies/kommentarii-v-kode/)
2. Про JSDoc – [https://intra.rocketfirm.com/tech/post/1361-jsdoc-vse-skazet-o-tvoej-funkcii-ili-metode/](https://intra.rocketfirm.com/tech/post/1361-jsdoc-vse-skazet-o-tvoej-funkcii-ili-metode/)
3. Гайдлайн Фронтенд разработчика – [https://intra.rocketfirm.com/library/techies/406-gajdlajn-dla-frontend-razrabotcika/](https://intra.rocketfirm.com/library/techies/406-gajdlajn-dla-frontend-razrabotcika/)
4. ESLint &amp; Prettier – [https://intra.rocketfirm.com/tech/post/1277-sledim-za-kacestvom-koda-fronta-v-proekte/](https://intra.rocketfirm.com/tech/post/1277-sledim-za-kacestvom-koda-fronta-v-proekte/)