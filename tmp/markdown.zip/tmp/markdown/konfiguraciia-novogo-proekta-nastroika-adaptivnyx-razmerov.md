# Книги > Archived > ROCKETFRONT-REACTNATIVE (ЧЕРНОВИК) > Конфигурация нового проекта :: Настройка адаптивных размеров

# Конфигурация нового проекта :: Настройка адаптивных размеров

через .env файл

```shell
SIZE_MATTERS_BASE_WIDTH=Ширина экрана
SIZE_MATTERS_BASE_HEIGHT=Высота экрана
```