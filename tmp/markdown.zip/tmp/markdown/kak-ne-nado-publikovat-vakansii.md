# Книги > Рекрутинг > Как не надо публиковать вакансии

# Как не надо публиковать вакансии

Часто HR’ы и рекрутеры находят картинки на стоках по разным тэгам вроде «вакансия», «поиск кадров». В итоге группы с вакансиями на linkedin перегружены абсолютно одинаковыми изображениями. Которые в большинстве случаев вообще никакого отношения к рекрутменту не имеют и выглядят ужасно (ну правда). Тут собраны иллюстрации, которые в здравом уме никак нельзя отнести к процессу найма.

**«Смотрите, как мы выбираем кандидатов»** Многие компании стремятся продемонстрировать свою инновационность и технологичность, поэтому прикрепляют к постам иллюстрации, на которых кто-то пальцем кликает на несуществующую сенсорную панель с иконками кандидатов. Информативность такого рода изображения равна нулю, как и его эстетика. Не говоря уже о том, что уже 2016 год, а не 1998. [  ](http://hr-mag.ru/wp-content/uploads/2016/12/stock-photo-recruitment-technology-communication-touchscreen-futuristic-concept-412486210-e1480678753415.jpg)

[![talent-recruit-page-header](https://talenttech.ru/wp-content/uploads/2016/12/talent-recruit-page-header.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/talent-recruit-page-header.jpg) [![e-recruitment-e1468825023603-1](https://talenttech.ru/wp-content/uploads/2016/12/e-recruitment-e1468825023603-1.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/e-recruitment-e1468825023603-1.jpg) [![aaeaaqaaaaaaaazdaaaajdg4ztaznzvhltiymdytngq3yy05n2e4lwq0nmexzdkynzezmw](https://talenttech.ru/wp-content/uploads/2016/12/aaeaaqaaaaaaaazdaaaajdg4ztaznzvhltiymdytngq3yy05n2e4lwq0nmexzdkynzezmw.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/aaeaaqaaaaaaaazdaaaajdg4ztaznzvhltiymdytngq3yy05n2e4lwq0nmexzdkynzezmw.jpg)

**«Ты как айсберг в океане»**

Прекрасно, с невиданными технологиями в рекрутменте разобрались. Теперь перейдём к изображениям, которые каким-то невероятным путем попадают в стоки по тэгу «рекрутмент» и затем становятся иллюстрациями к вакансиям.

Картинка, на которой команда вроде бы спасает утопающего в мире возможностей кандидата, а может пытается протянуть руку помощи сотруднику, которого только что уволили. При этом сами они стоят на кусочке пазла в океане. В общем, мы сами запутались.

[![Jigsaw puzzle recruiting new staff at sunrise on water.](https://talenttech.ru/wp-content/uploads/2016/12/510674870.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/510674870.jpg)

**«Большой брат найдёт и заберёт тебя»**

Далее следует огромное количество иллюстраций, на которых рука большого брата = компании вдруг выбирает из маленьких человечков одного. И вроде бы даже неплохая история, но не возникает ли у вас ассоциации с теми автоматами с огромной железной лапой, которые в детстве всегда обманывали?

Посмотрите, как расстроился мужчина в белом галстуке. Жаль.

[![pravilnyy_podbor_personala_za_6_shagov](https://talenttech.ru/wp-content/uploads/2016/12/pravilnyy_podbor_personala_za_6_shagov.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/pravilnyy_podbor_personala_za_6_shagov.jpg)

Да, такого рода изображения бывают даже довольно симпатичными, красиво отрисованными и приятными взгляду. Но всё же если вы хотите продемонстрировать демократичность вашей корпоративной культуры, то это точно не лучший способ.

[![hiring-the-culture-fit](https://talenttech.ru/wp-content/uploads/2016/12/hiring-the-culture-fit.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/hiring-the-culture-fit.jpg)

**«Ну, договорились»**

Ещё одна совершенно особенная категория иллюстраций — «пожимание рук». Подходит для любого рода публикации. И вариантов — тысячи. Например, с облаками.

[![88171911-1](https://talenttech.ru/wp-content/uploads/2016/12/88171911-1.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/88171911-1.jpg)

Или вот с людьми на фоне, которые тянутся или чешут голову.

[![recruitment1](https://talenttech.ru/wp-content/uploads/2016/12/recruitment1.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/recruitment1.jpg)

А этот двусмысленный взгляд?

[![snimok-ekrana-2016-12-02-v-15-55-27](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.55.27.png)](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.55.27.png)

**«Сыграй с нами в игру»**

Иногда иллюстрации просто приводят к немому вопросу «почему?», «за что?» и «как?». Например, вот эта:

![](https://talenttech.ru/wp-content/uploads/2022/05/24073502-e1480681339144.jpeg)

Какое отношение это имеет к рекрутменту? В какую загадочную игру играли эти люди? Кто виноват? Что делать?

Убегающие по дротику от чего-то очевидно страшного люди тоже относятся к поисковому запросу «рекрутмент»:

![](https://talenttech.ru/wp-content/uploads/2022/05/stock-photo-human-resources-target-as-a-group-of-people-running-across-a-giant-dart-supporting-as-a-bridge-to-521652514-e1480682770980.jpeg)

Или такой вот нестандартный подход. Выживет только сильнейший, говорите?

[![the-right-candidates-10044537-freedigitalphotos-net_](https://talenttech.ru/wp-content/uploads/2016/12/the-right-candidates-10044537-freedigitalphotos.net_.jpg)](https://talenttech.ru/wp-content/uploads/2016/12/the-right-candidates-10044537-freedigitalphotos.net_.jpg)

Как насчет рекрутерской машины-пылесоса? Подпись особенно порадует любителей бытовой техники.

[![snimok-ekrana-2016-12-02-v-15-51-24](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.51.24.png)](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.51.24.png)

Некоторые совершенно особенно представляют себе «воронку» страдающих кандидатов:

[![snimok-ekrana-2016-12-02-v-15-56-02](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.56.02.png)](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.56.02.png)

**Немного реалистичных кадров (или нет)**

Кандидаты (хотя сток говорит, что это всё же «бизнесмены»), которые стоят в очереди к чему-то?..

[![snimok-ekrana-2016-12-02-v-15-45-25](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.45.25.png)](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.45.25.png)

Оказывается, привлекать кандидатов можно ещё и вот таким образом. Со всего мира едут, как показывает сей чудная иллюстрация:

[![snimok-ekrana-2016-12-02-v-17-03-57](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-17.03.57.png)](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-17.03.57.png)

**«Ожидающие собеседования стрессовые люди»**

Очень часто на стоках попадаются фото людей, которые якобы ожидают собеседования в коридоре или холле. Выглядит это всегда одинаково и, наверное, это иллюстрация возникшего вокруг вакансии ажиотажа. Но чаще всего почему-то встречаются фото ног, которые ждут приглашения на собеседование.

С точки зрения HR-бренда это, конечно, не очень привлекательная иллюстрация.

[![snimok-ekrana-2016-12-02-v-17-05-26](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-17.05.26.png)](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-17.05.26.png)[![snimok-ekrana-2016-12-02-v-17-10-06](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-17.10.06.png)](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-17.10.06.png)

**Чудеса Paint**

Завершим это иллюстрацией к «вакансии мечты». От лысой 3D женщины, встречающей закат.

[![snimok-ekrana-2016-12-02-v-15-57-26](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.57.26.png)](https://talenttech.ru/wp-content/uploads/2016/12/snimok-ekrana-2016-12-02-v-15.57.26.png)

Статья взята с https://talenttech.ru/blog/hr-review/bad\_pics/