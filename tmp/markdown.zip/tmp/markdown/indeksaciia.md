# Книги > PHP > ElasticSearch. Основы > Индексация

# Индексация

Процесс заполнения Elasticsearch данными называется индексацией. Но перед индексацией желательно настроить маппинг. Elasticsearch умеет сам определять тип данных в документе, но для улучшения точности поиска желательно настроить маппинг.   
Ссылка на официальную [документацию](https://www.elastic.co/guide/en/elasticsearch/reference/current/indices-put-mapping.html)  
Пример настройки маппинга

```JSON
PUT / my-index-000001/_mapping
{
  "properties": {
    "title":  { "type": "text"}
  }
}

```

После настройки маппинга можно запускать индексацию. Индексация – это обычно крон команда которая добавляет документы в индекс, но для проверки можно добавить 1 документ через API.   
Для этого создается индекс с маппингом. Ссылка на официальную [документацию](https://www.elastic.co/guide/en/elasticsearch/reference/current/indices-create-index.html)

```JSON
PUT / my-index-000001
{
  "mappings": {
    "properties": {
      "field1": { "type": "text" }
    }
  }
}
```

После добавляется новый документ. Ссылка на официальную [документацию](https://www.elastic.co/guide/en/elasticsearch/reference/current/docs-index_.html)

```JSON
PUT my-index-000001/_doc/1
{
  "@timestamp": "2099-11-15T13:12:00",
  "message": "GET /search HTTP/1.1 200 1070000",
  "user": {
    "id": "kimchy"
  }
}
```

После добавления индекса и документа можно проверить их запросив все индексы  
`GET /_cat/indices`