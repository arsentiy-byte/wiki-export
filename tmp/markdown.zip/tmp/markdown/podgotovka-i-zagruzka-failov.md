# Книги > Загрузка в систему Stada :: CT Mobile > Подготовка и загрузка файлов

# Подготовка и загрузка файлов

Загрузка файлов

![](https://lh7-us.googleusercontent.com/oV91r5xUcAIcaNtprNLqRsEXuGJD7kLgxDr-OZrgd4uw35D7pxJoAUnz8hR-wsuBowgDvvhRh5GieMC9a80JU4_fMd_bDibpHkWW-OWO_AOFwOxtkBBQLZ60KESkmt3dkVUzBwgF9Ykcgu8t4K0mdZk)

Все файлу упаковываем в архив под названием sources но есть ограничение, архив не должен быть больше 25 МБ или сжимаем все в один для изображений я использую ([https://tinypng.com/](https://tinypng.com/)) или делим архив на несколько частей, документация рекомендует [https://www.7-zip.org/download.html](https://www.7-zip.org/download.html) для разделения архиа, но стоит отнестись внимательно к наименоваю архивов   
  
![](https://lh7-us.googleusercontent.com/LW43MhOOjgA2aBa7S5bQTH3e-0coD1COgJCb5g10F9qlD1dc6VxdZbv14MgpHR3eI10HiC4jcgUOeCgJqodGNmTcVKjUL28QozXMShL_ZFNjlUb_YM9zyY9hqracyP68z7MxC6RwroqdcVnn3NKh1JI)

Как правило система не пропускает больше двух архивов из за сообщения что исчерпан лимит, поэтому я стараюсь сжать все в один архив не более 25 мб, можно сжать картинки убрать дубли как упаковки, bg одинаковые и тд так как мы грузим не отдельно каждый слайд, можно использовать одну картинку для любого слайда.  
  
Архив подгружаем в систему  
![](https://lh7-us.googleusercontent.com/kUdBvu_QoccVbh3_xkVDw_vYWdpVhX77s05kKEL3yx1yDo9km2TfDVdfwrKqv_vXYUFoOtsgWpxbbhZSQmz4bwqh1yPnPmYRor7J5sv9zzQT1pczWUquE-wRTC2kPRf-9yAeRtjNx51oMl8wvhVoh5I)