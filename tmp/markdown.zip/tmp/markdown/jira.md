# Книги > Сервисы, за которые несут ответственность HR-менеджеры > Jira

# Jira

**Инструкция по добавлению новичков в Jira:**

Заходим на главную страницу, в правом углу находим шестеренку, нажимаем на **"управление пользователями"** →

[![image-1663654421107.13.38.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663654421107-13-38.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663654421107-13-38.png)

Попадаем в администрирование Jira и находим там **"создать пользователя"** в правом углу страницы

[![image-1663662052154.23.12.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663662052154-23-12.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663662052154-23-12.png)

Вводим данные пользователя в порядке ИМЯ ФАМИЛИЯ.   
Полное имя и имя пользователя должно быть одинаковыми.

Нажимаем **"создать пользователя"** →

[![image-1663662155197.22.31.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663662155197-22-31.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663662155197-22-31.png)

После создания пользователя Jira перенесет вас на главную страницу **управления пользователями →** в поле поиск вводим данные созданного пользователя →

[![image-1663662401191.26.36.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663662401191-26-36.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663662401191-26-36.png)

Чтобы новичка могли видеть менеджеры проектов нужно добавить его в соответствующие группы.  
Нажимаем на троеточие под словом "редактировать" в правом углу → изменить группы пользователей → введите полное название группы, куда нужно добавить (можно уточнить у руководителя команды менеджеров, куда добавить специалиста) → присоединиться к выбранным группам.

[![image-1663662536338.28.52.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663662536338-28-52.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663662536338-28-52.png)

**Важно:** у вас появится название группы только введения полного названия группы.

**При увольнении сотрудника**

Заходим в управление пользователями → вводим в поиске имя фамилию сотрудника → редактировать → [![image-1663662401191.26.36.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663662401191-26-36.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663662401191-26-36.png)

Убираем галочку "активный" → обновить

[![image-1663662854443.34.09.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663662854443-34-09.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663662854443-34-09.png)

Если деактивировать предстоит менеджера проектов или руководителя, нужно будет передать его проекты другому сотруднику, который остается в компании. В идеале, передать человеку, который перенял его проекты.

Если такой информации у вас нет или проект старый/на поддержке, передавайте проекты руководителю отдела.

[![image-1663662910369.35.06.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663662910369-35-06.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663662910369-35-06.png)

Чтобы "попасть" в проект, где нужно поменять роли, нажимаем на его аббревиатуру в всплывшем окне.

[![image-1663663129528.38.45.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663663129528-38-45.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663663129528-38-45.png)

Попадаем в администрирование проектом → нажимаем **"изменить значения по умолчанию"** →

[![image-1663663208087.40.02.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663663208087-40-02.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663663208087-40-02.png)

Вводим имя фамилию руководителя проекта → нажимаем **обновить.**

[![image-1663663322136.41.57.png](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/scaled-1680-/image-1663663322136-41-57.png)](https://wiki.rocketfirm.com/uploads/images/gallery/2022-09/image-1663663322136-41-57.png)

Со всеми остальными проектами, где сотрудник является руководителем проекта — совершаем те же действия. После передачи всех проектов можно будет деактивировать сотрудника.